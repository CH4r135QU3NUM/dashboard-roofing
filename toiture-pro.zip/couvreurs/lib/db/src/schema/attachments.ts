import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";
import { missionsTable } from "./missions";

export const missionAttachmentsTable = pgTable("mission_attachments", {
  id: serial("id").primaryKey(),
  missionId: integer("mission_id").notNull().references(() => missionsTable.id, { onDelete: "cascade" }),
  objectPath: text("object_path").notNull(),
  originalName: text("original_name").notNull(),
  mimeType: text("mime_type").notNull(),
  fileSize: integer("file_size").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
