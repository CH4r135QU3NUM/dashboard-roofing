import { pgTable, serial, text, integer, real, boolean, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { providersTable } from "./providers";

// Types de travaux de couverture
export const interventionTypeEnum = pgEnum("intervention_type", [
  "reparation_fuite",
  "remplacement_tuiles",
  "renovation_complete",
  "nettoyage_toiture",
  "pose_velux",
  "isolation_combles",
  "autre",
]);

export const missionStatusEnum = pgEnum("mission_status", [
  "pending",
  "confirmed",
  "in_progress",
  "completed",
  "cancelled",
]);

export const missionPriorityEnum = pgEnum("mission_priority", [
  "low",
  "normal",
  "high",
  "urgent",
]);

// Types de toiture (remplace types de véhicules)
export const roofTypeEnum = pgEnum("roof_type", [
  "tuiles_terre_cuite",
  "tuiles_beton",
  "ardoise",
  "zinc",
  "bac_acier",
  "bitume",
  "chaume",
  "autre",
]);

export const clientPaymentMethodEnum = pgEnum("client_payment_method", [
  "especes",
  "virement",
  "carte_bancaire",
  "cheque",
  "acompte",
]);

export const missionsTable = pgTable("missions", {
  id: serial("id").primaryKey(),
  providerId: integer("provider_id").references(() => providersTable.id, { onDelete: "set null" }),
  clientName: text("client_name").notNull(),
  clientPhone: text("client_phone").notNull(),

  // Champs toiture (remplacent make/model/plate/vehicleType)
  roofType: roofTypeEnum("roof_type"),
  roofTypeOther: text("roof_type_other"),
  roofSurface: real("roof_surface"),        // surface en m²
  roofAge: integer("roof_age"),             // âge de la toiture en années

  interventionType: interventionTypeEnum("intervention_type").notNull(),
  description: text("description").notNull(),
  locationAddress: text("location_address").notNull(),
  locationLat: real("location_lat"),
  locationLng: real("location_lng"),

  status: missionStatusEnum("status").notNull().default("pending"),
  priority: missionPriorityEnum("priority").notNull().default("normal"),
  estimatedDuration: integer("estimated_duration").notNull().default(480), // en minutes (1 journée = 480min)
  scheduledAt: timestamp("scheduled_at").notNull(),
  completedAt: timestamp("completed_at"),
  amount: real("amount"),
  clientPaymentMethod: clientPaymentMethodEnum("client_payment_method"),
  photos: text("photos").array().notNull().default([]),
  notes: text("notes"),

  // GPS prestataire (pour suivi sur chantier)
  providerLat: real("provider_lat"),
  providerLng: real("provider_lng"),
  isTracking: boolean("is_tracking").notNull().default(false),

  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertMissionSchema = createInsertSchema(missionsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertMission = z.infer<typeof insertMissionSchema>;
export type Mission = typeof missionsTable.$inferSelect;
