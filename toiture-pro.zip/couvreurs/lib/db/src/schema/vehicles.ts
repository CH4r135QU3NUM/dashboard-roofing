import { pgTable, serial, text, integer, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { clientsTable } from "./clients";

// Biens immobiliers / toitures référencées (anciennement "vehicles")
export const vehiclesTable = pgTable("vehicles", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").references(() => clientsTable.id, { onDelete: "set null" }),
  // Les champs make/model/plate sont réinterprétés pour une toiture
  make: text("make").notNull(),    // Type de bien (maison individuelle, immeuble, hangar…)
  model: text("model").notNull(),  // Type de toiture (2 pans, 4 pans, mansardée, terrasse…)
  year: integer("year"),           // Année de construction
  plate: text("plate").notNull(),  // Référence interne / numéro de parcelle cadastrale
  color: text("color"),            // Matériau dominant (tuile, ardoise, zinc…)
  vin: text("vin"),                // Notes complémentaires (surface m², particularités)
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertVehicleSchema = createInsertSchema(vehiclesTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertVehicle = z.infer<typeof insertVehicleSchema>;
export type Vehicle = typeof vehiclesTable.$inferSelect;
