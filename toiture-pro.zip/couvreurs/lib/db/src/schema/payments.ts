import { pgTable, serial, text, real, integer, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const paymentStatusEnum = pgEnum("payment_status", [
  "pending",
  "paid",
  "failed",
  "refunded",
]);

export const paymentMethodEnum = pgEnum("payment_method", [
  "cash",
  "card",
  "transfer",
  "stripe",
  "paypal",
  "especes",
  "virement",
  "carte_bancaire",
  "cheque",
  "compensation",
]);

export const commissionStatusEnum = pgEnum("commission_status", [
  "pending",
  "paid",
  "validated",
]);

export const paymentsTable = pgTable("payments", {
  id: serial("id").primaryKey(),
  missionId: integer("mission_id"),
  amount: real("amount").notNull(),
  currency: text("currency").notNull().default("EUR"),
  status: paymentStatusEnum("status").notNull().default("pending"),
  method: paymentMethodEnum("method").notNull(),
  reference: text("reference"),
  description: text("description"),
  commissionAmount: real("commission_amount"),
  commissionStatus: commissionStatusEnum("commission_status").default("pending"),
  commissionProof: text("commission_proof"),
  paidAt: timestamp("paid_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertPaymentSchema = createInsertSchema(paymentsTable).omit({
  id: true,
  createdAt: true,
});

export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof paymentsTable.$inferSelect;
