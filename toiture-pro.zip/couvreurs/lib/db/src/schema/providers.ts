import { pgTable, serial, text, real, boolean, timestamp, pgEnum, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const providerStatusEnum = pgEnum("provider_status", [
  "active",
  "inactive",
  "suspended",
]);

export const providersTable = pgTable("providers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  address: text("address"),
  zone: text("zone"),                          // Zone géographique d'intervention
  specialties: text("specialties").array().notNull().default([]),  // Types de travaux maîtrisés
  // Dépôt de matériaux (remplace stockage véhicules)
  storageType: text("storage_type"),           // "couvert" | "exterieur" | "les_deux"
  storageCapacity: integer("storage_capacity"),
  storagePricePerDay: real("storage_price_per_day"),
  storageAddress: text("storage_address"),
  siret: text("siret"),
  companyName: text("company_name"),
  tvaNumber: text("tva_number"),
  isSubjectToTva: boolean("is_subject_to_tva").notNull().default(false),
  status: providerStatusEnum("status").notNull().default("active"),
  rating: real("rating"),
  isAvailable: boolean("is_available").notNull().default(true),
  refusalCount: integer("refusal_count").notNull().default(0),
  acceptedPaymentMethods: text("accepted_payment_methods").array().notNull().default([]),
  // Documents spécifiques couvreur (remplace photo dépanneuse)
  equipmentPhoto: text("equipment_photo"),     // Photo du matériel / camion couvreur
  insuranceDocument: text("insurance_document"),
  qualificationDocument: text("qualification_document"), // Certifications (RGE, Qualibat…)
  passwordHash: text("password_hash"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertProviderSchema = createInsertSchema(providersTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertProvider = z.infer<typeof insertProviderSchema>;
export type Provider = typeof providersTable.$inferSelect;
