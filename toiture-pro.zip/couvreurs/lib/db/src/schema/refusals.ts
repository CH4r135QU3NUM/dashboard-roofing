import { pgTable, serial, integer, text, timestamp } from "drizzle-orm/pg-core";
import { providersTable } from "./providers";
import { missionsTable } from "./missions";

export const missionRefusalsTable = pgTable("mission_refusals", {
  id: serial("id").primaryKey(),
  missionId: integer("mission_id").notNull().references(() => missionsTable.id, { onDelete: "cascade" }),
  providerId: integer("provider_id").notNull().references(() => providersTable.id, { onDelete: "cascade" }),
  reason: text("reason"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type MissionRefusal = typeof missionRefusalsTable.$inferSelect;
