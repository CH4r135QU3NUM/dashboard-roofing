import { pgTable, serial, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const availabilityTable = pgTable("availability", {
  id: serial("id").primaryKey(),
  isAvailable: boolean("is_available").notNull().default(true),
  workingHoursStart: text("working_hours_start").notNull().default("08:00"),
  workingHoursEnd: text("working_hours_end").notNull().default("20:00"),
  workingDays: integer("working_days").array().notNull().default([1, 2, 3, 4, 5, 6]),
  maxDailyMissions: integer("max_daily_missions").notNull().default(8),
  interventionRadius: integer("intervention_radius").notNull().default(50),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const availabilitySlotsTable = pgTable("availability_slots", {
  id: serial("id").primaryKey(),
  startAt: timestamp("start_at").notNull(),
  endAt: timestamp("end_at").notNull(),
  reason: text("reason"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertAvailabilitySlotSchema = createInsertSchema(availabilitySlotsTable).omit({
  id: true,
  createdAt: true,
});

export type InsertAvailabilitySlot = z.infer<typeof insertAvailabilitySlotSchema>;
export type AvailabilitySlot = typeof availabilitySlotsTable.$inferSelect;
export type Availability = typeof availabilityTable.$inferSelect;
