import { db } from "@workspace/db";
import {
  missionsTable,
  paymentsTable,
  notificationsTable,
  availabilityTable,
  providersTable,
  clientsTable,
  vehiclesTable,
} from "@workspace/db/schema";

async function seed() {
  console.log("Seeding database...");

  await db.delete(notificationsTable);
  await db.delete(paymentsTable);
  await db.delete(missionsTable);
  await db.delete(availabilityTable);
  await db.delete(vehiclesTable);
  await db.delete(clientsTable);
  await db.delete(providersTable);

  const [avail] = await db.insert(availabilityTable).values({
    isAvailable: true,
    workingHoursStart: "07:00",
    workingHoursEnd: "21:00",
    workingDays: [1, 2, 3, 4, 5, 6],
    maxDailyMissions: 10,
    interventionRadius: 75,
  }).returning();
  console.log("Created availability:", avail.id);

  const providers = await db.insert(providersTable).values([
    {
      name: "Auto Dépannage Express",
      email: "contact@auto-express.fr",
      phone: "01 23 45 67 89",
      address: "12 Rue du Garage, 75010 Paris",
      zone: "Paris Nord",
      specialties: ["depannage", "panne_batterie", "crevaison"],
      status: "active" as const,
      rating: 4.8,
      isAvailable: true,
    },
    {
      name: "Remorquage Pro Île-de-France",
      email: "pro@remorquage-idf.fr",
      phone: "01 34 56 78 90",
      address: "8 Zone Industrielle, 93100 Montreuil",
      zone: "Paris Est",
      specialties: ["remorquage", "accident"],
      status: "active" as const,
      rating: 4.5,
      isAvailable: true,
    },
    {
      name: "Assistance 24h Leblanc",
      email: "info@assistance-leblanc.fr",
      phone: "06 87 65 43 21",
      address: "25 Allée des Mécaniciens, 92200 Neuilly",
      zone: "Paris Ouest",
      specialties: ["depannage", "remorquage", "panne_batterie", "crevaison", "accident"],
      status: "active" as const,
      rating: 4.9,
      isAvailable: false,
    },
    {
      name: "Dépann'Sud",
      email: "contact@depannsud.fr",
      phone: "01 45 67 89 01",
      address: "5 Rue de la Mécanique, 94200 Ivry",
      zone: "Paris Sud",
      specialties: ["depannage", "crevaison"],
      status: "inactive" as const,
      rating: 3.9,
      isAvailable: false,
    },
    {
      name: "Touraine Auto Secours",
      email: "touraine@autosecours.fr",
      phone: "02 47 12 34 56",
      address: "18 Avenue de la Loire, 37000 Tours",
      zone: "Région Centre",
      specialties: ["remorquage", "accident", "autre"],
      status: "suspended" as const,
      rating: 2.5,
      isAvailable: false,
    },
  ]).returning();
  console.log(`Created ${providers.length} providers`);

  const clients = await db.insert(clientsTable).values([
    {
      firstName: "Jean",
      lastName: "Dupont",
      email: "jean.dupont@email.fr",
      phone: "06 12 34 56 78",
      address: "15 Rue de la Paix, 75001 Paris",
    },
    {
      firstName: "Marie",
      lastName: "Martin",
      email: "marie.martin@email.fr",
      phone: "07 98 76 54 32",
      address: "32 Avenue Foch, 75016 Paris",
    },
    {
      firstName: "Pierre",
      lastName: "Bernard",
      email: "p.bernard@email.fr",
      phone: "06 55 44 33 22",
      address: "42 Avenue Victor Hugo, 92100 Boulogne",
    },
    {
      firstName: "Sophie",
      lastName: "Leclerc",
      email: null,
      phone: "06 11 22 33 44",
      address: "Carrefour des Nations, 94000 Créteil",
    },
    {
      firstName: "François",
      lastName: "Petit",
      email: "francois.petit@gmail.com",
      phone: "07 22 33 44 55",
      address: "10 Rue de Rivoli, 75004 Paris",
    },
    {
      firstName: "Isabelle",
      lastName: "Durand",
      email: "i.durand@yahoo.fr",
      phone: "06 77 88 99 00",
      address: "55 Boulevard Haussmann, 75008 Paris",
    },
  ]).returning();
  console.log(`Created ${clients.length} clients`);

  const vehicles = await db.insert(vehiclesTable).values([
    { clientId: clients[0].id, make: "Renault", model: "Clio", year: 2019, plate: "AB-123-CD", color: "Gris" },
    { clientId: clients[1].id, make: "Peugeot", model: "308", year: 2021, plate: "EF-456-GH", color: "Blanc" },
    { clientId: clients[2].id, make: "Citroën", model: "C3", year: 2020, plate: "IJ-789-KL", color: "Bleu" },
    { clientId: clients[3].id, make: "Volkswagen", model: "Golf", year: 2018, plate: "MN-012-OP", color: "Noir" },
    { clientId: clients[4].id, make: "Toyota", model: "Yaris", year: 2022, plate: "QR-345-ST", color: "Rouge" },
    { clientId: clients[5].id, make: "Ford", model: "Focus", year: 2017, plate: "UV-678-WX", color: "Argent" },
    { clientId: clients[0].id, make: "BMW", model: "Série 3", year: 2020, plate: "YZ-901-AB", color: "Noir" },
    { clientId: null, make: "Mercedes", model: "Classe C", year: 2019, plate: "CD-234-EF", color: "Blanc", vin: "WDD2050421R123456" },
  ]).returning();
  console.log(`Created ${vehicles.length} vehicles`);

  const now = new Date();
  const missions = await db.insert(missionsTable).values([
    {
      providerId: providers[0].id,
      clientName: "Jean Dupont",
      clientPhone: "06 12 34 56 78",
      vehicleMake: "Renault",
      vehicleModel: "Clio",
      vehiclePlate: "AB-123-CD",
      interventionType: "panne_batterie",
      description: "Batterie déchargée, véhicule ne démarre plus",
      locationAddress: "15 Rue de la Paix, 75001 Paris",
      locationLat: 48.8698,
      locationLng: 2.3311,
      status: "pending",
      priority: "urgent",
      estimatedDuration: 45,
      scheduledAt: new Date(now.getTime() + 30 * 60000),
      amount: null,
      photos: [],
    },
    {
      providerId: providers[1].id,
      clientName: "Marie Martin",
      clientPhone: "07 98 76 54 32",
      vehicleMake: "Peugeot",
      vehicleModel: "308",
      vehiclePlate: "EF-456-GH",
      interventionType: "crevaison",
      description: "Pneu arrière gauche à plat sur l'autoroute",
      locationAddress: "A6 - Sortie 23, 91000 Évry",
      locationLat: 48.6301,
      locationLng: 2.4404,
      status: "confirmed",
      priority: "high",
      estimatedDuration: 30,
      scheduledAt: new Date(now.getTime() + 60 * 60000),
      amount: null,
      photos: [],
    },
    {
      providerId: providers[2].id,
      clientName: "Pierre Bernard",
      clientPhone: "06 55 44 33 22",
      vehicleMake: "Citroën",
      vehicleModel: "C3",
      vehiclePlate: "IJ-789-KL",
      interventionType: "depannage",
      description: "Panne moteur, voyant allumé",
      locationAddress: "42 Avenue Victor Hugo, 92100 Boulogne",
      locationLat: 48.8344,
      locationLng: 2.2437,
      status: "in_progress",
      priority: "normal",
      estimatedDuration: 90,
      scheduledAt: new Date(now.getTime() - 45 * 60000),
      amount: null,
      photos: [],
    },
    {
      providerId: providers[0].id,
      clientName: "Sophie Leclerc",
      clientPhone: "06 11 22 33 44",
      vehicleMake: "Volkswagen",
      vehicleModel: "Golf",
      vehiclePlate: "MN-012-OP",
      interventionType: "remorquage",
      description: "Accident mineur, véhicule doit être remorqué",
      locationAddress: "Carrefour des Nations, 94000 Créteil",
      locationLat: 48.7757,
      locationLng: 2.4604,
      status: "completed",
      priority: "high",
      estimatedDuration: 60,
      scheduledAt: new Date(now.getTime() - 3 * 3600000),
      completedAt: new Date(now.getTime() - 2 * 3600000),
      amount: 180,
      photos: [],
      notes: "Remorquage effectué sans problème",
    },
    {
      providerId: providers[1].id,
      clientName: "François Petit",
      clientPhone: "07 22 33 44 55",
      vehicleMake: "Toyota",
      vehicleModel: "Yaris",
      vehiclePlate: "QR-345-ST",
      interventionType: "accident",
      description: "Choc arrière, véhicule immobilisé",
      locationAddress: "10 Rue de Rivoli, 75004 Paris",
      locationLat: 48.8558,
      locationLng: 2.3518,
      status: "completed",
      priority: "urgent",
      estimatedDuration: 120,
      scheduledAt: new Date(now.getTime() - 24 * 3600000),
      completedAt: new Date(now.getTime() - 22 * 3600000),
      amount: 320,
      photos: [],
      notes: "Intervention complexe, coordination avec les assurances",
    },
    {
      providerId: null,
      clientName: "Isabelle Durand",
      clientPhone: "06 77 88 99 00",
      vehicleMake: "Ford",
      vehicleModel: "Focus",
      vehiclePlate: "UV-678-WX",
      interventionType: "depannage",
      description: "Problème de démarrage",
      locationAddress: "55 Boulevard Haussmann, 75008 Paris",
      locationLat: 48.8744,
      locationLng: 2.3378,
      status: "cancelled",
      priority: "normal",
      estimatedDuration: 60,
      scheduledAt: new Date(now.getTime() - 48 * 3600000),
      amount: null,
      photos: [],
      notes: "Client annulé - problème résolu seul",
    },
    {
      providerId: providers[0].id,
      clientName: "Alain Rousseau",
      clientPhone: "06 33 44 55 66",
      vehicleMake: "BMW",
      vehicleModel: "Série 3",
      vehiclePlate: "YZ-901-AB",
      interventionType: "panne_batterie",
      description: "Batterie HS, remplacement nécessaire",
      locationAddress: "3 Place de la République, 75011 Paris",
      locationLat: 48.8670,
      locationLng: 2.3630,
      status: "completed",
      priority: "normal",
      estimatedDuration: 45,
      scheduledAt: new Date(now.getTime() - 72 * 3600000),
      completedAt: new Date(now.getTime() - 71 * 3600000),
      amount: 145,
      photos: [],
    },
    {
      providerId: providers[2].id,
      clientName: "Lucie Moreau",
      clientPhone: "06 44 55 66 77",
      vehicleMake: "Mercedes",
      vehicleModel: "Classe C",
      vehiclePlate: "CD-234-EF",
      interventionType: "accident",
      description: "Choc frontal, carrosserie endommagée",
      locationAddress: "Boulevard Périphérique, 75015 Paris",
      locationLat: 48.8347,
      locationLng: 2.2965,
      status: "completed",
      priority: "urgent",
      estimatedDuration: 150,
      scheduledAt: new Date(now.getTime() - 5 * 24 * 3600000),
      completedAt: new Date(now.getTime() - 5 * 24 * 3600000 + 2 * 3600000),
      amount: 450,
      photos: [],
      notes: "Coordination avec gendarmerie et assurance",
    },
  ]).returning();

  console.log(`Created ${missions.length} missions`);

  const completedMissions = missions.filter(m => m.status === "completed");
  if (completedMissions.length > 0) {
    const payments = await db.insert(paymentsTable).values(
      completedMissions.map((m, i) => ({
        missionId: m.id,
        amount: m.amount || 100,
        currency: "EUR",
        status: "paid" as const,
        method: ["cash", "card", "stripe", "paypal"][i % 4] as any,
        reference: `REF-${Date.now()}-${i}`,
        description: `Paiement mission #${m.id} - ${m.interventionType}`,
        paidAt: m.completedAt || new Date(),
      }))
    ).returning();
    console.log(`Created ${payments.length} payments`);
  }

  const notifications = await db.insert(notificationsTable).values([
    {
      type: "new_mission",
      title: "Nouvelle mission assignée",
      message: "Mission urgente de dépannage batterie pour Jean Dupont à Paris 1er",
      missionId: missions[0].id,
      isRead: false,
    },
    {
      type: "mission_update",
      title: "Mission confirmée",
      message: "La mission pour Marie Martin a été confirmée",
      missionId: missions[1].id,
      isRead: false,
    },
    {
      type: "payment_received",
      title: "Paiement reçu",
      message: "Paiement de 320€ reçu pour la mission de François Petit",
      missionId: missions[4].id,
      isRead: true,
    },
    {
      type: "system",
      title: "Bienvenue sur DepanneAuto Pro",
      message: "Votre compte est configuré et prêt à l'emploi",
      missionId: null,
      isRead: true,
    },
  ]).returning();

  console.log(`Created ${notifications.length} notifications`);
  console.log("Seeding complete!");
}

seed().catch(console.error).finally(() => process.exit());
