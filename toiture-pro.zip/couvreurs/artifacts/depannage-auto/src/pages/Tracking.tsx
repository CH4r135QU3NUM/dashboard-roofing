import { useEffect, useState, useRef } from "react";
import { useParams } from "wouter";
import { MapPin, Navigation, Car, User, Loader2, WifiOff, CheckCircle2 } from "lucide-react";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

interface TrackingData {
  id: number;
  providerLat: number | null;
  providerLng: number | null;
  isTracking: boolean;
  locationAddress: string;
  deliveryAddress: string | null;
  vehicleMake: string;
  vehicleModel: string;
  clientName: string;
  providerName: string | null;
  status: string;
}

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") || "";

const providerIcon = L.divIcon({
  className: "",
  html: `<div style="background:#f97316;border:3px solid white;border-radius:50%;width:20px;height:20px;box-shadow:0 2px 8px rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;">
    <div style="background:white;border-radius:50%;width:8px;height:8px;"></div>
  </div>`,
  iconSize: [20, 20],
  iconAnchor: [10, 10],
});

const destinationIcon = L.divIcon({
  className: "",
  html: `<div style="background:#ef4444;border:3px solid white;border-radius:4px 4px 0 4px;width:22px;height:22px;box-shadow:0 2px 8px rgba(0,0,0,0.3);transform:rotate(45deg);"></div>`,
  iconSize: [22, 22],
  iconAnchor: [11, 22],
});

export default function Tracking() {
  const { id } = useParams<{ id: string }>();
  const [data, setData] = useState<TrackingData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const providerMarkerRef = useRef<L.Marker | null>(null);

  const fetchLocation = async () => {
    try {
      const res = await fetch(`${BASE}/api/missions/${id}/provider-location`);
      if (!res.ok) throw new Error("Mission introuvable");
      const json: TrackingData = await res.json();
      setData(json);
      setLastUpdate(new Date());
      setError(null);
      return json;
    } catch {
      setError("Impossible de charger le suivi.");
      return null;
    }
  };

  useEffect(() => {
    fetchLocation();
    const interval = setInterval(fetchLocation, 5000);
    return () => clearInterval(interval);
  }, [id]);

  useEffect(() => {
    if (!mapContainerRef.current || mapRef.current) return;

    const map = L.map(mapContainerRef.current, {
      zoomControl: true,
      attributionControl: false,
    }).setView([48.8566, 2.3522], 13);

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
    }).addTo(map);

    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!mapRef.current || !data) return;

    if (data.providerLat && data.providerLng) {
      const pos: L.LatLngExpression = [data.providerLat, data.providerLng];

      if (providerMarkerRef.current) {
        providerMarkerRef.current.setLatLng(pos);
      } else {
        providerMarkerRef.current = L.marker(pos, { icon: providerIcon })
          .addTo(mapRef.current)
          .bindPopup(`<b>${data.providerName || "Couvreur"}</b><br>En route vers le chantier`);
      }

      mapRef.current.setView(pos, 15, { animate: true });
    }
  }, [data?.providerLat, data?.providerLng]);

  const statusLabel: Record<string, string> = {
    pending: "En attente",
    confirmed: "Confirmée",
    in_progress: "En cours",
    completed: "Terminée",
    cancelled: "Annulée",
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3 shadow-sm">
        <div className="w-9 h-9 rounded-xl bg-orange-500 flex items-center justify-center">
          <Navigation className="w-5 h-5 text-white" />
        </div>
        <div>
          <h1 className="font-bold text-gray-900 text-sm">Suivi en direct</h1>
          <p className="text-xs text-gray-500">Votre dépanneur arrive</p>
        </div>
        {data?.isTracking ? (
          <span className="ml-auto flex items-center gap-1.5 bg-green-50 text-green-700 text-xs font-medium px-2.5 py-1 rounded-full border border-green-200">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            En direct
          </span>
        ) : (
          <span className="ml-auto flex items-center gap-1.5 bg-gray-100 text-gray-500 text-xs font-medium px-2.5 py-1 rounded-full">
            <WifiOff className="w-3 h-3" />
            Hors ligne
          </span>
        )}
      </header>

      {/* Mission info */}
      {data && (
        <div className="bg-white border-b border-gray-100 px-4 py-3 flex items-center gap-4 text-sm">
          <div className="flex items-center gap-2 text-gray-700">
            <Car className="w-4 h-4 text-orange-500" />
            <span className="font-medium">{data.vehicleMake} {data.vehicleModel}</span>
          </div>
          <div className="flex items-center gap-2 text-gray-700">
            <User className="w-4 h-4 text-blue-500" />
            <span>{data.clientName}</span>
          </div>
          <div className="ml-auto">
            <span className="bg-blue-50 text-blue-700 text-xs font-medium px-2 py-0.5 rounded-full border border-blue-100">
              {statusLabel[data.status] || data.status}
            </span>
          </div>
        </div>
      )}

      {/* Map */}
      <div className="flex-1 relative" style={{ minHeight: "60vh" }}>
        {error ? (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
            <div className="text-center text-gray-500">
              <WifiOff className="w-10 h-10 mx-auto mb-2 opacity-40" />
              <p className="text-sm">{error}</p>
            </div>
          </div>
        ) : !data ? (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
            <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
          </div>
        ) : !data.providerLat || !data.providerLng ? (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-100 z-10">
            <div className="text-center text-gray-500 bg-white rounded-2xl p-6 shadow-md mx-4">
              <Loader2 className="w-10 h-10 mx-auto mb-3 text-orange-400 animate-spin" />
              <p className="font-medium text-gray-700">En attente du dépanneur…</p>
              <p className="text-xs mt-1 text-gray-400">La position sera affichée dès qu'il démarre</p>
            </div>
          </div>
        ) : null}
        <div ref={mapContainerRef} className="w-full h-full" style={{ minHeight: "60vh" }} />
      </div>

      {/* Footer */}
      <div className="bg-white border-t border-gray-100 px-4 py-3 space-y-2">
        {data?.locationAddress && (
          <div className="flex items-start gap-2 text-sm text-gray-600">
            <MapPin className="w-4 h-4 text-red-500 mt-0.5 shrink-0" />
            <span>{data.locationAddress}</span>
          </div>
        )}
        {lastUpdate && (
          <p className="text-xs text-gray-400 text-center">
            Dernière mise à jour : {lastUpdate.toLocaleTimeString("fr-FR")}
          </p>
        )}
        {data?.status === "completed" && (
          <div className="flex items-center justify-center gap-2 text-green-600 text-sm font-medium py-1">
            <CheckCircle2 className="w-4 h-4" />
            Mission terminée
          </div>
        )}
      </div>
    </div>
  );
}
