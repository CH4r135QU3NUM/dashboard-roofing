import { useState, useRef, useEffect, useCallback } from "react";
import { Layout } from "@/components/Layout";
import { useAuth } from "@/lib/auth";
import { 
  useGetMissions, 
  useConfirmMission, 
  useCompleteMission, 
  Mission, 
  GetMissionsStatus 
} from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { formatDateTime, getStatusLabel } from "@/lib/format";
import { MapPin, User, Car, Clock, Phone, FileText, CheckCircle2, Navigation, KeyRound, Radio, StopCircle, Copy, Check, AlertTriangle, XCircle, MessageCircle, Truck } from "lucide-react";
import { FileUploadZone, type FileUploadZoneRef } from "@/components/FileUploadZone";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") || "";

const VEHICLE_TYPE_LABELS: Record<string, string> = {
  tuiles_terre_cuite: "Tuiles terre cuite",
  tuiles_beton: "Tuiles béton",
  ardoise: "Ardoise",
  zinc: "Zinc",
  bac_acier: "Bac acier",
  bitume: "Bitume",
  autre: "Autre",
};

const CLIENT_PAYMENT_METHODS = [
  { value: "especes", label: "Espèces" },
  { value: "virement", label: "Virement" },
  { value: "carte_bancaire", label: "Carte bancaire" },
  { value: "cheque", label: "Chèque" },
  { value: "compensation", label: "Compensation" },
];

function isNonFrenchPhone(phone: string): boolean {
  const cleaned = phone.replace(/\s+/g, "").replace(/-/g, "");
  if (cleaned.startsWith("+33") || cleaned.startsWith("0033")) return false;
  if (cleaned.startsWith("+") || cleaned.startsWith("00")) return true;
  return false;
}

function getWhatsAppUrl(phone: string): string {
  let cleaned = phone.replace(/\s+/g, "").replace(/-/g, "");
  if (cleaned.startsWith("+")) cleaned = cleaned.slice(1);
  if (cleaned.startsWith("00")) cleaned = cleaned.slice(2);
  return `https://wa.me/${cleaned}`;
}

const completeSchema = z.object({
  amount: z.coerce.number().min(1, "Le montant est obligatoire"),
  notes: z.string().optional(),
  clientPaymentMethod: z.string().min(1, "Méthode de paiement requise"),
});

type CompleteFormValues = z.infer<typeof completeSchema>;

export default function Missions() {
  const { user } = useAuth();
  const [filter, setFilter] = useState<GetMissionsStatus | undefined>(undefined);
  const { data, isLoading } = useGetMissions({ status: filter, providerId: user?.id }, {
    query: { refetchInterval: 20_000, refetchOnWindowFocus: true, staleTime: 0 },
  });
  const missions = data?.missions || [];

  return (
    <Layout>
      <div className="flex flex-col gap-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <<h1 className="text-3xl font-display font-bold">Chantiers</h1>>
            <p className="text-muted-foreground mt-1">Gérez vos chantiers et mettez à jour leur statut.</p>
          </div>
          
          <div className="flex flex-wrap gap-2 bg-muted/50 p-1.5 rounded-xl border border-border/50 shadow-inner">
            <FilterButton active={filter === undefined} onClick={() => setFilter(undefined)}>Toutes</FilterButton>
            <FilterButton active={filter === "pending"} onClick={() => setFilter("pending")}>En attente</FilterButton>
            <FilterButton active={filter === "in_progress"} onClick={() => setFilter("in_progress")}>En cours</FilterButton>
            <FilterButton active={filter === "completed"} onClick={() => setFilter("completed")}>Terminées</FilterButton>
          </div>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <Card key={i} className="h-48 bg-muted/20 animate-pulse border-none rounded-2xl"></Card>
            ))}
          </div>
        ) : missions.length === 0 ? (
           <Card className="border-dashed border-2 bg-transparent shadow-none py-16 flex flex-col items-center justify-center text-center">
            <div className="w-24 h-24 mb-6 opacity-40">
              <img src={`${import.meta.env.BASE_URL}images/empty-state.png`} alt="Empty" className="w-full h-full object-contain" />
            </div>
            <h3 className="text-xl font-semibold text-foreground">Aucun chantier trouvée</h3>
            <p className="text-muted-foreground mt-2 max-w-sm">Il n'y a aucune mission correspondant à ce filtre actuellement.</p>
          </Card>
        ) : (
          <div className="grid grid-cols-1 gap-6">
            {missions.map(mission => (
              <MissionDetailCard key={mission.id} mission={mission} />
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}

function FilterButton({ active, onClick, children }: { active: boolean, onClick: () => void, children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 text-sm font-medium rounded-lg transition-all ${
        active 
          ? "bg-background text-foreground shadow-sm border border-border/50" 
          : "text-muted-foreground hover:text-foreground hover:bg-muted"
      }`}
    >
      {children}
    </button>
  );
}

function MissionDetailCard({ mission }: { mission: Mission }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const confirmMutation = useConfirmMission();
  const completeMutation = useCompleteMission();
  const fileUploadRef = useRef<FileUploadZoneRef>(null);
  
  const [completeDialogOpen, setCompleteDialogOpen] = useState(false);
  const [refuseDialogOpen, setRefuseDialogOpen] = useState(false);
  const [refuseReason, setRefuseReason] = useState("");
  const [isRefusing, setIsRefusing] = useState(false);
  const [isTracking, setIsTracking] = useState(false);

  const m = mission as any;

  const form = useForm<CompleteFormValues>({
    resolver: zodResolver(completeSchema),
    defaultValues: {
      amount: mission.amount || 0,
      notes: "",
      clientPaymentMethod: m.clientPaymentMethod || "",
    }
  });
  const [geoError, setGeoError] = useState<string | null>(null);
  const [linkCopied, setLinkCopied] = useState(false);
  const watchIdRef = useRef<number | null>(null);
  const sendTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const trackingUrl = `${window.location.origin}${BASE}/tracking/${mission.id}`;

  const sendLocation = useCallback(async (lat: number, lng: number, tracking: boolean) => {
    try {
      await fetch(`${BASE}/api/missions/${mission.id}/provider-location`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ lat, lng, isTracking: tracking }),
      });
    } catch {
    }
  }, [mission.id]);

  const stopTracking = useCallback(async () => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    if (sendTimeoutRef.current) {
      clearTimeout(sendTimeoutRef.current);
      sendTimeoutRef.current = null;
    }
    setIsTracking(false);
    setGeoError(null);
    try {
      await fetch(`${BASE}/api/missions/${mission.id}/provider-location`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ lat: null, lng: null, isTracking: false }),
      });
    } catch {}
  }, [mission.id]);

  const startTracking = useCallback(() => {
    if (!navigator.geolocation) {
      setGeoError("La géolocalisation n'est pas supportée par ce navigateur.");
      return;
    }
    setGeoError(null);
    setIsTracking(true);

    watchIdRef.current = navigator.geolocation.watchPosition(
      (pos) => {
        const { latitude: lat, longitude: lng } = pos.coords;
        sendLocation(lat, lng, true);
      },
      (err) => {
        let msg = "Impossible d'obtenir la position GPS.";
        if (err.code === 1) msg = "Accès à la position refusé. Veuillez autoriser la géolocalisation.";
        else if (err.code === 2) msg = "Position indisponible. Vérifiez votre GPS.";
        else if (err.code === 3) msg = "Délai dépassé pour obtenir la position.";
        setGeoError(msg);
        setIsTracking(false);
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 5000 }
    );
  }, [sendLocation]);

  useEffect(() => {
    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
      if (sendTimeoutRef.current) clearTimeout(sendTimeoutRef.current);
    };
  }, []);

  const handleAddressClick = (address: string, startGps = false) => {
    window.open(`https://maps.google.com/maps?q=${encodeURIComponent(address)}`, "_blank");
    if (startGps && !isTracking) {
      startTracking();
    }
  };

  const copyTrackingLink = async () => {
    try {
      await navigator.clipboard.writeText(trackingUrl);
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 2500);
      toast({ title: "Lien copié !", description: "Envoyez ce lien au client pour qu'il suive votre arrivée." });
    } catch {
      toast({ title: "Erreur", description: "Impossible de copier le lien.", variant: "destructive" });
    }
  };

  const handleConfirm = async () => {
    try {
      await confirmMutation.mutateAsync({ id: mission.id });
      toast({ title: "Mission confirmée", description: "Le client a été notifié." });
      queryClient.invalidateQueries({ queryKey: ["/api/missions"] });
    } catch (e) {
      toast({ title: "Erreur", description: "Impossible de confirmer la mission.", variant: "destructive" });
    }
  };

  const handleRefuse = async () => {
    if (!user?.id) return;
    setIsRefusing(true);
    try {
      const res = await fetch(`${BASE}/api/missions/${mission.id}/refuse`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ providerId: user.id, reason: refuseReason || undefined }),
      });
      if (!res.ok) throw new Error();
      toast({ title: "Mission refusée", description: "La mission a été remise en attente." });
      setRefuseDialogOpen(false);
      setRefuseReason("");
      queryClient.invalidateQueries({ queryKey: ["/api/missions"] });
    } catch {
      toast({ title: "Erreur", description: "Impossible de refuser la mission.", variant: "destructive" });
    } finally {
      setIsRefusing(false);
    }
  };

  const handleComplete = async (data: CompleteFormValues) => {
    if (isTracking) await stopTracking();
    try {
      await completeMutation.mutateAsync({ 
        id: mission.id, 
        data: { amount: data.amount, notes: data.notes, clientPaymentMethod: data.clientPaymentMethod } as any
      });
      if (fileUploadRef.current?.hasPendingFiles()) {
        try {
          const uploaded = await fileUploadRef.current.uploadStagedFiles();
          await Promise.all(uploaded.map(f =>
            fetch(`${BASE}/api/missions/${mission.id}/attachments`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(f),
            })
          ));
        } catch {
          toast({ title: "Pièces jointes", description: "Mission terminée, mais certaines pièces jointes n'ont pas pu être envoyées.", variant: "destructive" });
        }
      }
      setCompleteDialogOpen(false);
      toast({ title: "Mission terminée", description: "La mission a été marquée comme complétée." });
      queryClient.invalidateQueries({ queryKey: ["/api/missions"] });
    } catch (e) {
      toast({ title: "Erreur", description: "Impossible de terminer la mission.", variant: "destructive" });
    }
  };

  const canTrack = mission.status === "confirmed" || mission.status === "in_progress";
  const vehicleTypeLabel = m.vehicleType ? (VEHICLE_TYPE_LABELS[m.vehicleType] || m.vehicleType) : null;

  return (
    <Card className="rounded-2xl border border-border/60 shadow-lg shadow-black/5 overflow-hidden">
      <div className="flex flex-col lg:flex-row">
        <div className="flex-1 p-6 lg:border-r border-border/50">
          <div className="flex justify-between items-start mb-6">
            <div>
              <Badge className="mb-2" variant={mission.status === 'completed' ? 'secondary' : 'default'}>
                {getStatusLabel(mission.status)}
              </Badge>
              <h2 className="text-2xl font-bold font-display uppercase tracking-tight">
                {mission.vehicleMake} {mission.vehicleModel}
              </h2>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-muted-foreground font-mono bg-muted inline-block px-2 py-0.5 rounded">
                  {mission.vehiclePlate}
                </span>
                {vehicleTypeLabel && (
                  <Badge variant="outline" className="text-xs">
                    <Truck className="w-3 h-3 mr-1" />
                    {vehicleTypeLabel}{m.vehicleType === "autre" && m.vehicleTypeOther ? ` (${m.vehicleTypeOther})` : ""}
                  </Badge>
                )}
              </div>
            </div>
            <div className="text-right">
              <span className="block text-sm text-muted-foreground">Prévu le</span>
              <span className="font-semibold text-foreground">{formatDateTime(mission.scheduledAt)}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <button
                type="button"
                onClick={() => handleAddressClick(mission.locationAddress, canTrack)}
                className="w-full text-left flex items-start gap-3 bg-primary/5 border border-primary/20 rounded-xl px-3 py-2.5 hover:bg-primary/10 active:scale-[0.98] transition-all cursor-pointer"
              >
                <MapPin className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-primary">Lieu d'intervention</p>
                  <p className="text-foreground text-sm">{mission.locationAddress}</p>
                  {canTrack && !isTracking && (
                    <p className="text-xs text-primary/60 mt-0.5 flex items-center gap-1">
                      <Radio className="w-3 h-3" /> Appuyez pour démarrer le suivi GPS
                    </p>
                  )}
                </div>
                <Navigation className="w-4 h-4 text-primary/60 mt-0.5 flex-shrink-0" />
              </button>

              {mission.keyPickupAddress && (
                <button
                  type="button"
                  onClick={() => handleAddressClick(mission.keyPickupAddress!, canTrack)}
                  className="w-full text-left flex items-start gap-3 bg-amber-500/10 border border-amber-500/20 rounded-xl px-3 py-2.5 hover:bg-amber-500/20 active:scale-[0.98] transition-all cursor-pointer"
                >
                  <KeyRound className="w-5 h-5 text-amber-500 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-amber-600 dark:text-amber-400">Récupération clés / client</p>
                    <p className="text-foreground text-sm">{mission.keyPickupAddress}</p>
                  </div>
                  <Navigation className="w-4 h-4 text-amber-400 mt-0.5 flex-shrink-0" />
                </button>
              )}

              {mission.deliveryAddress && (
                <button
                  type="button"
                  onClick={() => handleAddressClick(mission.deliveryAddress!, canTrack)}
                  className="w-full text-left flex items-start gap-3 bg-blue-500/10 border border-blue-500/20 rounded-xl px-3 py-2.5 hover:bg-blue-500/20 active:scale-[0.98] transition-all cursor-pointer"
                >
                  <Navigation className="w-5 h-5 text-blue-500 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-blue-600 dark:text-blue-400">Adresse de livraison</p>
                    <p className="text-foreground text-sm">{mission.deliveryAddress}</p>
                  </div>
                  <Navigation className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
                </button>
              )}

              <div className="flex items-start gap-3">
                <FileText className="w-5 h-5 text-primary mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Description</p>
                  <p className="text-foreground text-sm">{mission.description}</p>
                </div>
              </div>

              <MissionAttachments missionId={mission.id} />
            </div>

            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <User className="w-5 h-5 text-primary mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Client</p>
                  <p className="text-foreground">{mission.clientName}</p>
                </div>
              </div>
              
              <div className="flex items-stretch gap-2">
                <a
                  href={`tel:${mission.clientPhone}`}
                  className="flex-1 flex items-start gap-3 bg-green-500/10 border border-green-500/20 rounded-xl px-3 py-2.5 hover:bg-green-500/20 active:scale-[0.98] transition-all cursor-pointer"
                >
                  <Phone className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-green-700 dark:text-green-400">Appeler le client</p>
                    <p className="text-foreground font-medium">{mission.clientPhone}</p>
                  </div>
                </a>
                {isNonFrenchPhone(mission.clientPhone) && (
                  <a
                    href={getWhatsAppUrl(mission.clientPhone)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center w-14 bg-green-600/10 border border-green-600/20 rounded-xl hover:bg-green-600/20 active:scale-[0.95] transition-all cursor-pointer"
                    title="Contacter via WhatsApp"
                  >
                    <MessageCircle className="w-6 h-6 text-green-600" />
                  </a>
                )}
              </div>

              {canTrack && isTracking && (
                <div className="bg-orange-500/10 border border-orange-500/30 rounded-xl px-3 py-2.5">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-2.5 h-2.5 bg-orange-500 rounded-full animate-pulse" />
                    <span className="text-sm font-semibold text-orange-600">Suivi GPS actif</span>
                  </div>
                  <p className="text-xs text-muted-foreground mb-3">Votre position est transmise au client en temps réel.</p>
                  <button
                    type="button"
                    onClick={copyTrackingLink}
                    className="w-full flex items-center justify-center gap-2 bg-orange-500/10 hover:bg-orange-500/20 border border-orange-500/30 text-orange-700 dark:text-orange-400 text-xs font-medium px-3 py-1.5 rounded-lg transition-all mb-2"
                  >
                    {linkCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    {linkCopied ? "Lien copié !" : "Copier le lien client"}
                  </button>
                  <button
                    type="button"
                    onClick={stopTracking}
                    className="w-full flex items-center justify-center gap-2 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-600 text-xs font-medium px-3 py-1.5 rounded-lg transition-all"
                  >
                    <StopCircle className="w-3.5 h-3.5" />
                    Arrêter le suivi
                  </button>
                </div>
              )}

              {geoError && (
                <div className="bg-destructive/10 border border-destructive/20 rounded-xl px-3 py-2 flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
                  <p className="text-xs text-destructive">{geoError}</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="lg:w-72 bg-muted/20 p-6 flex flex-col justify-between gap-4">
          <div className="space-y-3">
            <h3 className="font-semibold text-sm text-muted-foreground mb-1 uppercase tracking-wider">Actions requises</h3>
            
            {mission.status === 'pending' && (
              <>
                <Button 
                  className="w-full shadow-md shadow-primary/20 bg-primary hover:bg-primary/90 text-white" 
                  onClick={handleConfirm}
                  disabled={confirmMutation.isPending}
                >
                  {confirmMutation.isPending ? "Confirmation..." : "Confirmer la mission"}
                </Button>
                <Button
                  variant="outline"
                  className="w-full border-red-500/40 text-red-600 hover:bg-red-50 hover:text-red-700"
                  onClick={() => setRefuseDialogOpen(true)}
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Refuser la mission
                </Button>
              </>
            )}

            {(mission.status === 'confirmed' || mission.status === 'in_progress') && (
              <>
                {!isTracking ? (
                  <Button
                    className="w-full bg-orange-500 hover:bg-orange-600 text-white shadow-md shadow-orange-500/20 flex items-center gap-2"
                    onClick={startTracking}
                  >
                    <Radio className="w-4 h-4" />
                    Démarrer le suivi GPS
                  </Button>
                ) : (
                  <Button
                    variant="outline"
                    className="w-full border-orange-500/40 text-orange-600 flex items-center gap-2"
                    onClick={copyTrackingLink}
                  >
                    {linkCopied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    {linkCopied ? "Lien copié !" : "Copier le lien client"}
                  </Button>
                )}

                <Button 
                  className="w-full bg-green-600 hover:bg-green-700 text-white shadow-md shadow-green-600/20"
                  onClick={() => setCompleteDialogOpen(true)}
                >
                  Marquer comme terminée
                </Button>

                <Button
                  variant="outline"
                  className="w-full border-red-500/40 text-red-600 hover:bg-red-50 hover:text-red-700"
                  onClick={() => setRefuseDialogOpen(true)}
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Refuser la mission
                </Button>
              </>
            )}

            {mission.status === 'completed' && (
              <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-4 text-center">
                <CheckCircle2 className="w-8 h-8 text-green-500 mx-auto mb-2" />
                <p className="text-green-700 font-medium">Mission clôturée</p>
                {mission.amount && <p className="text-2xl font-bold mt-2">{mission.amount} €</p>}
              </div>
            )}
          </div>

          {isTracking && (
            <div className="text-center pt-2 border-t border-border/30">
              <p className="text-xs text-muted-foreground mb-1">Lien de suivi client :</p>
              <a
                href={trackingUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-orange-500 hover:text-orange-600 underline break-all"
              >
                {trackingUrl}
              </a>
            </div>
          )}
        </div>
      </div>

      <Dialog open={completeDialogOpen} onOpenChange={setCompleteDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Clôturer la mission</DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(handleComplete)} className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Montant final de l'intervention (€) <span className="text-destructive">*</span></Label>
              <Input 
                id="amount" 
                type="number" 
                step="0.01" 
                {...form.register("amount")} 
                className="text-lg font-semibold"
              />
              {form.formState.errors.amount && (
                <p className="text-sm text-destructive">{form.formState.errors.amount.message}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label>Méthode de paiement client <span className="text-destructive">*</span></Label>
              <Select
                value={form.watch("clientPaymentMethod")}
                onValueChange={(v) => form.setValue("clientPaymentMethod", v)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner..." />
                </SelectTrigger>
                <SelectContent>
                  {CLIENT_PAYMENT_METHODS.map(m => (
                    <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {form.formState.errors.clientPaymentMethod && (
                <p className="text-sm text-destructive">{form.formState.errors.clientPaymentMethod.message}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Notes d'intervention (optionnel)</Label>
              <Textarea 
                id="notes" 
                placeholder="Détails sur la réparation effectuée..."
                {...form.register("notes")} 
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <Label>Pièces jointes (photos, vidéos, PDF)</Label>
              <FileUploadZone ref={fileUploadRef} />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setCompleteDialogOpen(false)}>Annuler</Button>
              <Button type="submit" disabled={completeMutation.isPending} className="bg-green-600 hover:bg-green-700 text-white">
                {completeMutation.isPending ? "Enregistrement..." : "Valider et terminer"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={refuseDialogOpen} onOpenChange={setRefuseDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <XCircle className="w-5 h-5" />
              Refuser cette mission
            </DialogTitle>
            <DialogDescription>
              La mission sera remise en attente et pourra être assignée à un autre prestataire.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div className="space-y-2">
              <Label>Raison du refus (optionnel)</Label>
              <Textarea
                value={refuseReason}
                onChange={e => setRefuseReason(e.target.value)}
                placeholder="Ex: Trop loin, indisponible ce jour..."
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRefuseDialogOpen(false)}>Annuler</Button>
            <Button
              variant="destructive"
              onClick={handleRefuse}
              disabled={isRefusing}
            >
              {isRefusing ? "Refus en cours..." : "Confirmer le refus"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

function MissionAttachments({ missionId }: { missionId: number }) {
  const [attachments, setAttachments] = useState<any[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    fetch(`${BASE}/api/missions/${missionId}/attachments`)
      .then(r => r.json())
      .then(data => { setAttachments(Array.isArray(data) ? data : []); setLoaded(true); })
      .catch(() => setLoaded(true));
  }, [missionId]);

  if (!loaded || attachments.length === 0) return null;

  return (
    <div className="space-y-2">
      <p className="text-sm font-medium text-muted-foreground flex items-center gap-2">
        <FileText className="w-4 h-4 text-primary" />
        Pièces jointes ({attachments.length})
      </p>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        {attachments.map((a: any) => {
          const isImage = a.mimeType?.startsWith("image/");
          const storagePath = a.objectPath?.startsWith("/objects/") ? a.objectPath.slice("/objects/".length) : a.objectPath;
          const url = a.objectPath?.startsWith("http") ? a.objectPath : `${BASE}/api/storage/objects/${storagePath}`;
          return (
            <a key={a.id} href={url} target="_blank" rel="noopener noreferrer" className="block border border-border/50 rounded-xl overflow-hidden hover:border-primary/50 transition-colors">
              {isImage ? (
                <img src={url} alt={a.originalName} className="w-full h-24 object-cover" />
              ) : (
                <div className="h-24 flex flex-col items-center justify-center p-2 bg-muted/20">
                  <FileText className="w-8 h-8 text-muted-foreground mb-1" />
                  <span className="text-[10px] text-muted-foreground text-center truncate w-full">{a.originalName}</span>
                </div>
              )}
            </a>
          );
        })}
      </div>
    </div>
  );
}
