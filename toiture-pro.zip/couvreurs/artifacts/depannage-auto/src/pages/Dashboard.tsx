import { useGetMissions, useGetPaymentSummary, Mission } from "@workspace/api-client-react";
import { Layout } from "@/components/Layout";
import { useAuth } from "@/lib/auth";
import { Card, CardContent } from "@/components/ui/card";
import { formatCurrency, formatDateTime, getStatusLabel, getPriorityLabel } from "@/lib/format";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, AlertTriangle, Car, Truck, BatteryWarning, Wrench, CircleDashed, ArrowRight, Activity, Euro, CheckCircle2, BarChart3, Clock } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "wouter";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } }
};

const LIVE_OPTS = {
  query: {
    refetchInterval: 20_000,
    refetchOnWindowFocus: true,
    staleTime: 0,
  },
} as const;

export default function Dashboard() {
  const { user } = useAuth();
  const { data: missionsData, isLoading: missionsLoading } = useGetMissions({ status: "pending", limit: 5, providerId: user?.id }, LIVE_OPTS);
  const { data: confirmedMissionsData } = useGetMissions({ status: "confirmed", limit: 5, providerId: user?.id }, LIVE_OPTS);
  const { data: activeMissionsData } = useGetMissions({ status: "in_progress", limit: 3, providerId: user?.id }, LIVE_OPTS);
  const { data: paymentSummary, isLoading: paymentLoading } = useGetPaymentSummary({ providerId: user?.id }, LIVE_OPTS);

  const pendingMissions = missionsData?.missions || [];
  const confirmedMissions = confirmedMissionsData?.missions || [];
  const activeMissions = activeMissionsData?.missions || [];

  return (
    <Layout>
      <div className="flex flex-col gap-8">
        
        {/* Hero Section */}
        <div className="relative overflow-hidden rounded-3xl bg-secondary text-secondary-foreground shadow-2xl">
          <div className="absolute inset-0 opacity-40">
            <img 
              src={`${import.meta.env.BASE_URL}images/dashboard-hero.png`} 
              alt="Background" 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-secondary via-secondary/90 to-transparent"></div>
          </div>
          
          <div className="relative p-8 md:p-12 z-10">
            <h1 className="text-3xl md:text-5xl font-display font-bold mb-4">
              Bonjour, Prêt pour vos <span className="text-primary">chantiers</span> ?
            </h1>
            <p className="text-secondary-foreground/80 max-w-xl text-lg mb-8">
              Voici un aperçu de votre journée. Vous avez {pendingMissions.length} chantiers en attente de confirmation.
            </p>
            <Link href="/disponibilites">
              <Button size="lg" className="rounded-xl font-semibold shadow-lg shadow-primary/25 hover-elevate bg-primary text-primary-foreground">
                <Activity className="mr-2 w-5 h-5" />
                Mettre à jour ma disponibilité
              </Button>
            </Link>
          </div>
        </div>

        {/* Stats Grid */}
        <motion.div 
          variants={container}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
        >
          <StatCard 
            title="Chantiers du jour" 
            value={paymentSummary?.missionsCount?.toString() || "0"} 
            subtitle="Chantiers effectués"
            icon={<CheckCircle2 className="w-5 h-5 text-green-500" />}
            loading={paymentLoading}
          />
          <StatCard 
            title="En attente" 
            value={pendingMissions.length.toString()} 
            subtitle="Chantiers à confirmer"
            icon={<AlertTriangle className="w-5 h-5 text-orange-500" />}
            loading={missionsLoading}
          />
          <StatCard 
            title="Revenus du mois" 
            value={paymentSummary ? formatCurrency(paymentSummary.totalRevenue) : "0,00 €"} 
            subtitle="Total généré"
            icon={<Euro className="w-5 h-5 text-primary" />}
            loading={paymentLoading}
          />
          <StatCard 
            title="Panier moyen" 
            value={paymentSummary ? formatCurrency(paymentSummary.avgMissionAmount) : "0,00 €"} 
            subtitle="Par mission"
            icon={<BarChart3 className="w-5 h-5 text-blue-500" />}
            loading={paymentLoading}
          />
        </motion.div>

        {/* Active & Pending Missions */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-display font-bold">Missions Récentes</h2>
              <Link href="/missions" className="text-sm font-medium text-primary hover:underline flex items-center gap-1">
                Voir tout <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
            
            <div className="flex flex-col gap-4">
              {activeMissions.map(m => <MissionCard key={m.id} mission={m} isActive />)}
              {confirmedMissions.map(m => <MissionCard key={m.id} mission={m} isActive />)}
              {pendingMissions.map(m => <MissionCard key={m.id} mission={m} />)}
              
              {!missionsLoading && activeMissions.length === 0 && confirmedMissions.length === 0 && pendingMissions.length === 0 && (
                <Card className="border-dashed border-2 bg-transparent shadow-none p-12 flex flex-col items-center justify-center text-center">
                  <div className="w-20 h-20 mb-4 opacity-50">
                    <img src={`${import.meta.env.BASE_URL}images/empty-state.png`} alt="Empty" className="w-full h-full object-contain" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground">Aucune mission en cours</h3>
                  <p className="text-muted-foreground mt-2 max-w-sm">Vous n'avez pas de missions assignées pour le moment. Détendez-vous ou mettez à jour vos disponibilités.</p>
                </Card>
              )}
            </div>
          </div>
          
          <div className="flex flex-col gap-4">
            <h2 className="text-xl font-display font-bold">Activité</h2>
            <Card className="rounded-2xl border-none shadow-lg shadow-black/5 p-6">
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="w-2 h-2 rounded-full bg-primary mt-2"></div>
                  <div>
                    <p className="text-sm font-medium">Nouveau paiement reçu</p>
                    <p className="text-xs text-muted-foreground">Il y a 10 min - Mission #1042</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="w-2 h-2 rounded-full bg-green-500 mt-2"></div>
                  <div>
                    <p className="text-sm font-medium">Mission terminée</p>
                    <p className="text-xs text-muted-foreground">Il y a 45 min - Peugeot 208</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="w-2 h-2 rounded-full bg-orange-500 mt-2"></div>
                  <div>
                    <p className="text-sm font-medium">Nouvelle assignation</p>
                    <p className="text-xs text-muted-foreground">Il y a 1 heure - Dépannage urgent</p>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}

function StatCard({ title, value, subtitle, icon, loading }: { title: string, value: string, subtitle: string, icon: React.ReactNode, loading?: boolean }) {
  return (
    <motion.div variants={item}>
      <Card className="rounded-2xl border-none shadow-lg shadow-black/5 hover:shadow-xl transition-shadow duration-300">
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-muted/50 border border-border/50">
              {icon}
            </div>
          </div>
          <div>
            {loading ? (
              <div className="h-8 w-24 bg-muted animate-pulse rounded-md mb-1"></div>
            ) : (
              <h3 className="text-3xl font-display font-bold tracking-tight text-foreground">{value}</h3>
            )}
            <p className="text-sm font-medium text-muted-foreground mt-1">{title}</p>
            <p className="text-xs text-muted-foreground/60 mt-1">{subtitle}</p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export function MissionCard({ mission, isActive = false }: { mission: Mission, isActive?: boolean }) {
  const getInterventionIcon = (type: string) => {
    switch(type) {
      case 'depannage': return <Wrench className="w-5 h-5 text-blue-500" />;
      case 'remorquage': return <Truck className="w-5 h-5 text-orange-500" />;
      case 'panne_batterie': return <BatteryWarning className="w-5 h-5 text-red-500" />;
      case 'crevaison': return <CircleDashed className="w-5 h-5 text-zinc-500" />;
      case 'accident': return <AlertTriangle className="w-5 h-5 text-destructive" />;
      default: return <Car className="w-5 h-5 text-primary" />;
    }
  };

  return (
    <Card className={`rounded-2xl overflow-hidden transition-all duration-300 ${isActive ? 'border-primary/50 shadow-md shadow-primary/10' : 'border-border shadow-sm'}`}>
      <div className="flex flex-col md:flex-row">
        <div className={`p-4 md:w-48 flex flex-col justify-center items-center text-center border-b md:border-b-0 md:border-r ${isActive ? 'bg-primary/5 border-primary/20' : 'bg-muted/30 border-border'}`}>
          <div className="bg-background p-3 rounded-full shadow-sm mb-3">
            {getInterventionIcon(mission.interventionType)}
          </div>
          <span className="font-semibold text-sm capitalize">{mission.interventionType.replace('_', ' ')}</span>
          <Badge variant={isActive ? "default" : "secondary"} className="mt-2 text-[10px] uppercase tracking-wider">
            {getStatusLabel(mission.status)}
          </Badge>
        </div>
        
        <div className="flex-1 p-5 md:p-6 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-start mb-2">
              <h3 className="text-lg font-bold">
                {mission.vehicleMake} {mission.vehicleModel} <span className="text-muted-foreground font-normal text-sm ml-2">{mission.vehiclePlate}</span>
              </h3>
              {mission.priority === 'urgent' && (
                <Badge variant="destructive" className="animate-pulse">URGENT</Badge>
              )}
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-2 gap-x-4 mt-4">
              <div className="flex items-center text-sm text-muted-foreground">
                <MapPin className="w-4 h-4 mr-2 text-primary" />
                <span className="truncate">{mission.locationAddress}</span>
              </div>
              <div className="flex items-center text-sm text-muted-foreground">
                <Clock className="w-4 h-4 mr-2 text-primary" />
                <span>Prévu: {formatDateTime(mission.scheduledAt)}</span>
              </div>
            </div>
          </div>
          
          <div className="mt-6 flex items-center justify-between pt-4 border-t border-border/50">
            <div className="text-sm font-medium">
              Client: <span className="text-foreground">{mission.clientName}</span>
            </div>
            <Link href={`/missions?id=${mission.id}`}>
              <Button variant="outline" size="sm" className="rounded-lg hover-elevate">
                Voir détails
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </Card>
  );
}
