import { useState } from "react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { HardHat, Eye, EyeOff, Loader2, UserPlus, LogIn } from "lucide-react";

type Mode = "login" | "register";

export default function Login() {
  const { login, register } = useAuth();
  const [mode, setMode] = useState<Mode>("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const switchMode = (m: Mode) => { setMode(m); setError(null); setPassword(""); setConfirmPassword(""); };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setError(null);
    if (mode === "register") {
      if (password !== confirmPassword) { setError("Les mots de passe ne correspondent pas."); return; }
      if (password.length < 6) { setError("Le mot de passe doit contenir au moins 6 caractères."); return; }
    }
    setIsLoading(true);
    try {
      if (mode === "login") await login(email, password);
      else await register(name, email, phone, password);
    } catch (err: any) {
      setError(err.message || "Une erreur est survenue.");
    } finally { setIsLoading(false); }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0f1a2e] via-[#1a2a45] to-[#0f1a2e] flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-orange-500 shadow-2xl shadow-orange-500/30 mb-4">
            <HardHat className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white">ToiturePro</h1>
          <p className="text-slate-400 text-sm mt-1">Espace Couvreur</p>
        </div>

        <div className="flex bg-slate-800/50 rounded-xl p-1 mb-5 border border-slate-700/50">
          <button type="button" onClick={() => switchMode("login")}
            className={`flex-1 flex items-center justify-center gap-2 py-2 text-sm font-medium rounded-lg transition-all ${mode === "login" ? "bg-orange-500 text-white shadow" : "text-slate-400 hover:text-slate-200"}`}>
            <LogIn className="w-4 h-4" /> Se connecter
          </button>
          <button type="button" onClick={() => switchMode("register")}
            className={`flex-1 flex items-center justify-center gap-2 py-2 text-sm font-medium rounded-lg transition-all ${mode === "register" ? "bg-orange-500 text-white shadow" : "text-slate-400 hover:text-slate-200"}`}>
            <UserPlus className="w-4 h-4" /> S'inscrire
          </button>
        </div>

        <div className="bg-slate-800/60 backdrop-blur border border-slate-700/50 rounded-2xl p-6 shadow-2xl">
          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === "register" && (
              <div className="space-y-1.5">
                <Label htmlFor="name" className="text-slate-300 text-sm">Nom de l'entreprise / Prénom Nom</Label>
                <Input id="name" type="text" placeholder="Couverture Dupont" value={name} onChange={e => setName(e.target.value)} required
                  className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 focus:border-orange-500 rounded-xl h-11" />
              </div>
            )}
            <div className="space-y-1.5">
              <Label htmlFor="email" className="text-slate-300 text-sm">Adresse email</Label>
              <Input id="email" type="email" placeholder="couvreur@exemple.fr" value={email} onChange={e => setEmail(e.target.value)} required
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 focus:border-orange-500 rounded-xl h-11" />
            </div>
            {mode === "register" && (
              <div className="space-y-1.5">
                <Label htmlFor="phone" className="text-slate-300 text-sm">Téléphone</Label>
                <Input id="phone" type="tel" placeholder="06 12 34 56 78" value={phone} onChange={e => setPhone(e.target.value)} required
                  className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 focus:border-orange-500 rounded-xl h-11" />
              </div>
            )}
            <div className="space-y-1.5">
              <Label htmlFor="password" className="text-slate-300 text-sm">Mot de passe</Label>
              <div className="relative">
                <Input id="password" type={showPassword ? "text" : "password"} placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} required
                  className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 focus:border-orange-500 rounded-xl h-11 pr-10" />
                <button type="button" onClick={() => setShowPassword(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 transition-colors">
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            {mode === "register" && (
              <div className="space-y-1.5">
                <Label htmlFor="confirm" className="text-slate-300 text-sm">Confirmer le mot de passe</Label>
                <Input id="confirm" type="password" placeholder="••••••••" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} required
                  className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 focus:border-orange-500 rounded-xl h-11" />
              </div>
            )}
            {error && <div className="bg-red-500/10 border border-red-500/30 rounded-xl px-3 py-2 text-sm text-red-400">{error}</div>}
            <Button type="submit" disabled={isLoading} className="w-full bg-orange-500 hover:bg-orange-600 text-white h-11 rounded-xl font-semibold shadow-lg shadow-orange-500/20 mt-2">
              {isLoading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />{mode === "login" ? "Connexion…" : "Inscription…"}</> : (mode === "login" ? "Se connecter" : "Créer mon compte")}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
