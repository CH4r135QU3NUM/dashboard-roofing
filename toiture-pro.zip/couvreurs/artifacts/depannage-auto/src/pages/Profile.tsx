import { useState, useRef, useEffect } from "react";
import { Layout } from "@/components/Layout";
import { useAuth } from "@/lib/auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Truck, Shield, Upload, CheckCircle2, User, Mail, Phone, MapPin, Star, Briefcase, Loader2 } from "lucide-react";
import { FileUploadZone, type FileUploadZoneRef } from "@/components/FileUploadZone";

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") || "";

function resolveStorageUrl(path: string | null | undefined): string | null {
  if (!path) return null;
  if (path.startsWith("http")) return path;
  const clean = path.startsWith("/objects/") ? path.slice("/objects/".length) : path;
  return `${BASE}/api/storage/objects/${clean}`;
}

export default function Profile() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [provider, setProvider] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [uploadingTruck, setUploadingTruck] = useState(false);
  const [uploadingInsurance, setUploadingInsurance] = useState(false);
  const [showTruckUpload, setShowTruckUpload] = useState(false);
  const [showInsuranceUpload, setShowInsuranceUpload] = useState(false);
  const truckUploadRef = useRef<FileUploadZoneRef>(null);
  const insuranceUploadRef = useRef<FileUploadZoneRef>(null);

  const fetchProvider = async () => {
    if (!user?.id) return;
    try {
      const res = await fetch(`${BASE}/api/providers/${user.id}`);
      if (res.ok) {
        const data = await res.json();
        setProvider(data);
      }
    } catch {} finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchProvider(); }, [user?.id]);

  const handleUploadTruck = async () => {
    if (!truckUploadRef.current?.hasPendingFiles()) return;
    setUploadingTruck(true);
    try {
      const uploaded = await truckUploadRef.current.uploadStagedFiles();
      if (uploaded.length > 0) {
        const res = await fetch(`${BASE}/api/providers/${user?.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ equipmentPhoto: uploaded[0].objectPath }),
        });
        if (!res.ok) throw new Error();
        toast({ title: "Photo enregistrée", description: "La photo de votre matériel a été mise à jour." });
        setShowTruckUpload(false);
        fetchProvider();
      }
    } catch {
      toast({ title: "Erreur", description: "Impossible d'enregistrer la photo.", variant: "destructive" });
    } finally {
      setUploadingTruck(false);
    }
  };

  const handleUploadInsurance = async () => {
    if (!insuranceUploadRef.current?.hasPendingFiles()) return;
    setUploadingInsurance(true);
    try {
      const uploaded = await insuranceUploadRef.current.uploadStagedFiles();
      if (uploaded.length > 0) {
        const res = await fetch(`${BASE}/api/providers/${user?.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ insuranceDocument: uploaded[0].objectPath }),
        });
        if (!res.ok) throw new Error();
        toast({ title: "Document enregistré", description: "Votre assurance a été mise à jour." });
        setShowInsuranceUpload(false);
        fetchProvider();
      }
    } catch {
      toast({ title: "Erreur", description: "Impossible d'enregistrer le document.", variant: "destructive" });
    } finally {
      setUploadingInsurance(false);
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-[60vh]">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  if (!provider) {
    return (
      <Layout>
        <div className="text-center py-20 text-muted-foreground">Impossible de charger le profil.</div>
      </Layout>
    );
  }

  const truckPhotoUrl = resolveStorageUrl(provider.equipmentPhoto);
  const insuranceUrl = resolveStorageUrl(provider.insuranceDocument);

  return (
    <Layout>
      <div className="flex flex-col gap-8 max-w-3xl mx-auto">
        <div>
          <h1 className="text-3xl font-display font-bold">Mon Profil</h1>
          <p className="text-muted-foreground mt-1">Gérez vos informations et documents professionnels..</p>
        </div>

        <Card className="rounded-2xl border-border/50 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-primary to-orange-400 shadow-lg flex items-center justify-center text-white text-2xl font-bold">
                {provider.name?.charAt(0)?.toUpperCase() || "P"}
              </div>
              <div>
                <h2 className="text-xl font-bold">{provider.name}</h2>
                {provider.companyName && <p className="text-sm text-muted-foreground">{provider.companyName}</p>}
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant={provider.status === "active" ? "default" : "secondary"} className="text-xs">
                    {provider.status === "active" ? "Actif" : provider.status === "inactive" ? "Inactif" : "Suspendu"}
                  </Badge>
                  {provider.rating && (
                    <span className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Star className="w-3 h-3 fill-orange-400 text-orange-400" />
                      {provider.rating.toFixed(1)}
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-primary" />
                <span className="text-sm">{provider.email}</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-primary" />
                <span className="text-sm">{provider.phone}</span>
              </div>
              {provider.address && (
                <div className="flex items-center gap-3 sm:col-span-2">
                  <MapPin className="w-4 h-4 text-primary" />
                  <span className="text-sm">{provider.address}</span>
                </div>
              )}
              {provider.zone && (
                <div className="flex items-center gap-3">
                  <Briefcase className="w-4 h-4 text-primary" />
                  <span className="text-sm">Zone : {provider.zone}</span>
                </div>
              )}
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              {provider.specialties?.map((s: string) => (
                <Badge key={s} variant="secondary" className="text-xs capitalize">{s.replace("_", " ")}</Badge>
              ))}
            </div>

            <div className="mt-4 grid grid-cols-2 gap-4 border-t border-border/50 pt-4">
              <div>
                <p className="text-xs text-muted-foreground">Missions réalisées</p>
                <p className="text-lg font-bold">{provider.totalMissions || 0}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Revenus totaux</p>
                <p className="text-lg font-bold">{new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(provider.totalRevenue || 0)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-border/50 shadow-lg">
          <CardHeader className="border-b border-border/50">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Truck className="w-5 h-5 text-primary" />
              Photo de la dépanneuse
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            {truckPhotoUrl ? (
              <div className="space-y-4">
                <img src={truckPhotoUrl} alt="Équipement" className="w-full h-48 object-cover rounded-xl border border-border/50" />
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                  <span className="text-sm text-green-700 font-medium">Photo téléchargée</span>
                </div>
                <Button variant="outline" size="sm" onClick={() => setShowTruckUpload(!showTruckUpload)}>
                  Changer la photo
                </Button>
              </div>
            ) : (
              <div className="text-center py-6">
                <Truck className="w-12 h-12 mx-auto text-muted-foreground/40 mb-3" />
                <p className="text-sm text-muted-foreground mb-4">Aucune photo téléchargée (optionnel)</p>
                <Button variant="outline" onClick={() => setShowTruckUpload(!showTruckUpload)}>
                  <Upload className="w-4 h-4 mr-2" /> Ajouter une photo
                </Button>
              </div>
            )}

            {showTruckUpload && (
              <div className="mt-4 space-y-3">
                <FileUploadZone ref={truckUploadRef} />
                <div className="flex gap-2">
                  <Button onClick={handleUploadTruck} disabled={uploadingTruck} className="bg-primary text-white">
                    {uploadingTruck ? "Envoi..." : "Enregistrer"}
                  </Button>
                  <Button variant="outline" onClick={() => setShowTruckUpload(false)}>Annuler</Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-border/50 shadow-lg">
          <CardHeader className="border-b border-border/50">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Shield className="w-5 h-5 text-primary" />
              Assurance
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            {insuranceUrl ? (
              <div className="space-y-4">
                <div className="flex items-center gap-3 bg-green-500/10 border border-green-500/20 rounded-xl p-4">
                  <CheckCircle2 className="w-6 h-6 text-green-600" />
                  <div>
                    <p className="font-medium text-green-700">Document téléchargé</p>
                    <a href={insuranceUrl} target="_blank" rel="noopener noreferrer" className="text-sm text-primary hover:underline">
                      Voir le document
                    </a>
                  </div>
                </div>
                <Button variant="outline" size="sm" onClick={() => setShowInsuranceUpload(!showInsuranceUpload)}>
                  Changer le document
                </Button>
              </div>
            ) : (
              <div className="text-center py-6">
                <Shield className="w-12 h-12 mx-auto text-muted-foreground/40 mb-3" />
                <p className="text-sm text-muted-foreground mb-4">Aucune assurance téléchargée (optionnel)</p>
                <Button variant="outline" onClick={() => setShowInsuranceUpload(!showInsuranceUpload)}>
                  <Upload className="w-4 h-4 mr-2" /> Ajouter une assurance
                </Button>
              </div>
            )}

            {showInsuranceUpload && (
              <div className="mt-4 space-y-3">
                <FileUploadZone ref={insuranceUploadRef} />
                <div className="flex gap-2">
                  <Button onClick={handleUploadInsurance} disabled={uploadingInsurance} className="bg-primary text-white">
                    {uploadingInsurance ? "Envoi..." : "Enregistrer"}
                  </Button>
                  <Button variant="outline" onClick={() => setShowInsuranceUpload(false)}>Annuler</Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
