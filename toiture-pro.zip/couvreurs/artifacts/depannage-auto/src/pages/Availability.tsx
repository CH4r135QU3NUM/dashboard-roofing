import { Layout } from "@/components/Layout";
import { 
  useGetAvailability, 
  useUpdateAvailability, 
  useGetAvailabilitySlots,
  useCreateAvailabilitySlot,
  useDeleteAvailabilitySlot
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import { Clock, Navigation, CalendarOff, Trash2 } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatDateTime } from "@/lib/format";
import { useAuth } from "@/lib/auth";

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") || "";

export default function Availability() {
  const { user, token } = useAuth();
  const { data: availability, isLoading: availLoading } = useGetAvailability();
  const { data: slotsData } = useGetAvailabilitySlots();
  const updateMutation = useUpdateAvailability();
  const deleteSlotMutation = useDeleteAvailabilitySlot();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [radius, setRadius] = useState([50]);
  const [isAvailable, setIsAvailable] = useState(true);

  // Sync state when data loads
  useEffect(() => {
    if (availability) {
      setRadius([availability.interventionRadius || 50]);
      setIsAvailable(availability.isAvailable);
    }
  }, [availability]);

  const handleToggleStatus = async (checked: boolean) => {
    setIsAvailable(checked);
    try {
      await updateMutation.mutateAsync({ data: { isAvailable: checked } });

      // Sync to the providers table so the admin panel reflects the change
      if (user?.id && token) {
        await fetch(`${BASE}/api/providers/${user.id}`, {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`,
          },
          body: JSON.stringify({ isAvailable: checked }),
        });
      }

      toast({ 
        title: checked ? "Mode en ligne activé" : "Mode hors ligne activé", 
        description: checked ? "Vous pouvez recevoir de nouveaux chantiers." : "Vous ne recevrez plus de nouveaux chantiers.",
        variant: checked ? "default" : "secondary"
      });
      queryClient.invalidateQueries({ queryKey: ["/api/availability"] });
    } catch (e) {
      setIsAvailable(!checked); // revert
      toast({ title: "Erreur", description: "Mise à jour impossible", variant: "destructive" });
    }
  };

  const handleSaveSettings = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    try {
      await updateMutation.mutateAsync({
        data: {
          workingHoursStart: formData.get("start") as string,
          workingHoursEnd: formData.get("end") as string,
          maxDailyMissions: Number(formData.get("maxMissions")),
          interventionRadius: radius[0]
        }
      });
      toast({ title: "Paramètres enregistrés", description: "Vos préférences ont été mises à jour." });
      queryClient.invalidateQueries({ queryKey: ["/api/availability"] });
    } catch (e) {
      toast({ title: "Erreur", description: "Échec de la sauvegarde", variant: "destructive" });
    }
  };

  const handleDeleteSlot = async (id: number) => {
    try {
      await deleteSlotMutation.mutateAsync({ id });
      toast({ title: "Période supprimée", description: "Le créneau a été libéré." });
      queryClient.invalidateQueries({ queryKey: ["/api/availability/slots"] });
    } catch(e) {
      toast({ title: "Erreur", description: "Impossible de supprimer la période", variant: "destructive" });
    }
  };

  if (availLoading) return <Layout><div className="p-8 text-center">Chargement...</div></Layout>;

  return (
    <Layout>
      <div className="flex flex-col gap-8 max-w-5xl mx-auto">
        <div>
          <h1 className="text-3xl font-display font-bold">Disponibilités</h1>
          <p className="text-muted-foreground mt-1">Gérez vos horaires et zones de déplacement.</p>
        </div>

        {/* Global Status Toggle */}
        <Card className={`rounded-2xl border-2 transition-colors duration-500 shadow-xl ${isAvailable ? 'border-primary/50 bg-primary/5' : 'border-border bg-card'}`}>
          <CardContent className="p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-6">
              <div className={`p-4 rounded-full ${isAvailable ? 'bg-primary text-white shadow-lg shadow-primary/30' : 'bg-muted text-muted-foreground'}`}>
                <Navigation className="w-8 h-8" />
              </div>
              <div>
                <h2 className="text-2xl font-display font-bold">
                  {isAvailable ? "Vous êtes EN LIGNE" : "Vous êtes HORS LIGNE"}
                </h2>
                <p className="text-muted-foreground mt-1">
                  {isAvailable 
                    ? "Les clients peuvent vous assigner de nouveaux chantiers." 
                    : "Votre profil est masqué. Vous ne recevrez pas de missions."}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Label htmlFor="status-toggle" className="font-semibold text-lg cursor-pointer">
                {isAvailable ? "Actif" : "Inactif"}
              </Label>
              <Switch 
                id="status-toggle" 
                checked={isAvailable} 
                onCheckedChange={handleToggleStatus} 
                className="scale-125 data-[state=checked]:bg-primary"
              />
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Settings Form */}
          <Card className="rounded-2xl border-border/50 shadow-lg shadow-black/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Clock className="w-5 h-5 text-primary" /> Horaires & Préférences</CardTitle>
              <CardDescription>Définissez vos heures de travail habituelles.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSaveSettings} className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Heure de début</Label>
                    <Input name="start" type="time" defaultValue={availability?.workingHoursStart} required />
                  </div>
                  <div className="space-y-2">
                    <Label>Heure de fin</Label>
                    <Input name="end" type="time" defaultValue={availability?.workingHoursEnd} required />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Missions max par jour</Label>
                  <Input name="maxMissions" type="number" min="1" max="50" defaultValue={availability?.maxDailyMissions} required />
                </div>

                <div className="space-y-4 pt-4 border-t border-border/50">
                  <div className="flex justify-between items-center">
                    <Label>Rayon d'intervention</Label>
                    <span className="font-bold text-primary">{radius[0]} km</span>
                  </div>
                  <Slider 
                    value={radius} 
                    onValueChange={setRadius} 
                    max={150} 
                    min={5} 
                    step={5}
                    className="py-4"
                  />
                  <p className="text-xs text-muted-foreground">La distance maximale à laquelle vous acceptez des missions depuis votre base.</p>
                </div>

                <Button type="submit" disabled={updateMutation.isPending} className="w-full bg-primary hover:bg-primary/90 hover-elevate">
                  {updateMutation.isPending ? "Sauvegarde..." : "Enregistrer les modifications"}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Blocked Slots */}
          <Card className="rounded-2xl border-border/50 shadow-lg shadow-black/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><CalendarOff className="w-5 h-5 text-destructive" /> Indisponibilités Ponctuelles</CardTitle>
              <CardDescription>Bloquez des créneaux (vacances, maintenance, etc.)</CardDescription>
            </CardHeader>
            <CardContent>
              {/* Simple inline form to add a slot */}
              <CreateSlotForm onCreated={() => queryClient.invalidateQueries({ queryKey: ["/api/availability/slots"] })} />
              
              <div className="mt-8 space-y-3">
                <Label>Créneaux bloqués à venir</Label>
                {slotsData?.slots && slotsData.slots.length > 0 ? (
                  slotsData.slots.map(slot => (
                    <div key={slot.id} className="flex items-center justify-between p-3 rounded-lg border border-border/50 bg-muted/20">
                      <div>
                        <p className="text-sm font-medium">{slot.reason || "Indisponible"}</p>
                        <p className="text-xs text-muted-foreground">
                          Du {formatDateTime(slot.startAt)} au {formatDateTime(slot.endAt)}
                        </p>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                        onClick={() => handleDeleteSlot(slot.id)}
                        disabled={deleteSlotMutation.isPending}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground italic p-4 text-center border rounded-lg border-dashed">Aucun créneau bloqué.</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}

function CreateSlotForm({ onCreated }: { onCreated: () => void }) {
  const createMutation = useCreateAvailabilitySlot();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);
    
    // Ensure properly formatted ISO dates for API
    const start = new Date(formData.get("start") as string).toISOString();
    const end = new Date(formData.get("end") as string).toISOString();

    try {
      await createMutation.mutateAsync({
        data: { startAt: start, endAt: end, reason: formData.get("reason") as string }
      });
      toast({ title: "Période bloquée ajoutée" });
      form.reset();
      onCreated();
    } catch(e) {
      toast({ title: "Erreur", description: "Impossible d'ajouter la période", variant: "destructive" });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-muted/30 p-4 rounded-xl border border-border/50 space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label className="text-xs">Début</Label>
          <Input name="start" type="datetime-local" required className="text-sm h-9" />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs">Fin</Label>
          <Input name="end" type="datetime-local" required className="text-sm h-9" />
        </div>
      </div>
      <div className="space-y-1.5">
        <Label className="text-xs">Raison (optionnelle)</Label>
        <Input name="reason" placeholder="Ex: Maintenance dépanneuse" className="h-9" />
      </div>
      <Button type="submit" size="sm" disabled={createMutation.isPending} className="w-full">
        Ajouter l'indisponibilité
      </Button>
    </form>
  );
}
