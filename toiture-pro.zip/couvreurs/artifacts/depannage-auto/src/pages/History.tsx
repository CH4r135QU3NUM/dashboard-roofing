import { Layout } from "@/components/Layout";
import { useGetStats } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCurrency } from "@/lib/format";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, PieChart, Pie, Cell, LineChart, Line } from "recharts";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const COLORS = ['#f97316', '#3b82f6', '#10b981', '#f43f5e', '#8b5cf6', '#64748b'];

function formatDuration(minutes: number): string {
  if (!minutes || minutes <= 0) return "0min";
  const totalMinutes = Math.round(minutes * 100) / 100;
  const h = Math.floor(totalMinutes / 60);
  const m = Math.round(totalMinutes % 60);
  if (h === 0) return `${m}min`;
  if (m === 0) return `${h}h`;
  return `${h}h ${m.toString().padStart(2, "0")}min`;
}

export default function History() {
  const { user } = useAuth();
  const { data: stats, isLoading } = useGetStats({ period: "all", providerId: user?.id }, {
    query: { refetchInterval: 30_000, refetchOnWindowFocus: true, staleTime: 0 },
  });

  if (isLoading) {
    return (
      <Layout>
        <div className="animate-pulse space-y-8">
           <div className="h-12 w-1/4 bg-muted rounded"></div>
           <div className="h-64 bg-muted rounded-2xl"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="flex flex-col gap-8">
        <div>
          <h1 className="text-3xl font-display font-bold">Historique & Statistiques</h1>
          <p className="text-muted-foreground mt-1">Analysez vos performances sur la durée..</p>
        </div>

        {/* KPI Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KPICard title="Missions Totales" value={stats?.totalMissions || 0} />
          <KPICard title="Missions Complétées" value={stats?.completedMissions || 0} />
          <KPICard title="Revenu Moyen" value={formatCurrency(stats?.avgRevenue || 0)} />
          <KPICard title="Durée Moyenne" value={formatDuration(stats?.avgDuration || 0)} />
        </div>

        {/* Charts */}
        <Tabs defaultValue="revenue" className="w-full">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold font-display">Aperçu analytique</h2>
            <TabsList className="bg-muted/50 border border-border/50">
              <TabsTrigger value="revenue" className="rounded-md">Revenus</TabsTrigger>
              <TabsTrigger value="missions" className="rounded-md">Missions par mois</TabsTrigger>
              <TabsTrigger value="types" className="rounded-md">Répartition</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="revenue">
            <Card className="rounded-2xl shadow-lg shadow-black/5 border-border/50">
              <CardHeader>
                <CardTitle>Évolution des revenus</CardTitle>
              </CardHeader>
              <CardContent className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={stats?.missionsByMonth || []} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                    <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{fill: 'hsl(var(--muted-foreground))'}} />
                    <YAxis axisLine={false} tickLine={false} tickFormatter={(v) => `${v}€`} tick={{fill: 'hsl(var(--muted-foreground))'}} />
                    <Tooltip 
                      formatter={(value: number) => formatCurrency(value)}
                      contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                    />
                    <Line type="monotone" dataKey="revenue" stroke="hsl(var(--primary))" strokeWidth={4} dot={{ r: 4, fill: "hsl(var(--primary))", strokeWidth: 2 }} activeDot={{ r: 8 }} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="missions">
            <Card className="rounded-2xl shadow-lg shadow-black/5 border-border/50">
              <CardHeader>
                <CardTitle>Volume de missions par mois</CardTitle>
              </CardHeader>
              <CardContent className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={stats?.missionsByMonth || []} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                    <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{fill: 'hsl(var(--muted-foreground))'}} />
                    <YAxis axisLine={false} tickLine={false} tick={{fill: 'hsl(var(--muted-foreground))'}} />
                    <Tooltip cursor={{fill: 'hsl(var(--muted)/0.5)'}} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                    <Bar dataKey="missions" fill="hsl(var(--primary))" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="types">
            <Card className="rounded-2xl shadow-lg shadow-black/5 border-border/50">
              <CardHeader>
                <CardTitle>Répartition par type de travaux</CardTitle>
              </CardHeader>
              <CardContent className="h-[400px] flex items-center justify-center">
                {stats?.missionsByType && stats.missionsByType.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={stats.missionsByType}
                        cx="50%"
                        cy="50%"
                        innerRadius={80}
                        outerRadius={140}
                        paddingAngle={5}
                        dataKey="count"
                        nameKey="type"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {stats.missionsByType.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="text-muted-foreground">Pas assez de données pour afficher la répartition.</div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}

function KPICard({ title, value }: { title: string, value: string | number }) {
  return (
    <Card className="rounded-2xl border-none bg-card shadow-md shadow-black/5">
      <CardContent className="p-6">
        <p className="text-sm font-medium text-muted-foreground mb-2">{title}</p>
        <p className="text-2xl md:text-3xl font-bold font-display text-foreground">{value}</p>
      </CardContent>
    </Card>
  );
}
