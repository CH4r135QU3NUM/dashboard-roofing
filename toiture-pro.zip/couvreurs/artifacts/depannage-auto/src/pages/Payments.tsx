import { useState, useRef } from "react";
import { Layout } from "@/components/Layout";
import { useGetPayments, useGetPaymentSummary } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCurrency, formatDateTime } from "@/lib/format";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { CreditCard, Wallet, Banknote, History, Percent, Eye, Upload, MapPin, Car, User, FileText, CheckCircle2, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { FileUploadZone, type FileUploadZoneRef } from "@/components/FileUploadZone";

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") || "";

const PAYMENT_METHOD_LABELS: Record<string, string> = {
  cash: "Espèces",
  especes: "Espèces",
  virement: "Virement",
  carte_bancaire: "Carte bancaire",
  cheque: "Chèque",
  compensation: "Compensation",
};

const REFETCH_OPTS = {
  query: {
    refetchInterval: 30_000,
    refetchOnWindowFocus: true,
    staleTime: 0,
  },
} as const;

export default function Payments() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: summary } = useGetPaymentSummary({ providerId: user?.id }, REFETCH_OPTS);
  const { data: paymentsData, isLoading } = useGetPayments({ providerId: user?.id }, REFETCH_OPTS);
  const payments = paymentsData?.payments || [];

  const [previewPayment, setPreviewPayment] = useState<any>(null);
  const [proofPayment, setProofPayment] = useState<any>(null);
  const [isUploading, setIsUploading] = useState(false);
  const fileUploadRef = useRef<FileUploadZoneRef>(null);

  const totalCommission = payments.reduce((sum: number, p: any) => sum + (p.commissionAmount || 0), 0);

  const handleUploadProof = async () => {
    if (!proofPayment || !fileUploadRef.current?.hasPendingFiles()) return;
    setIsUploading(true);
    try {
      const uploaded = await fileUploadRef.current.uploadStagedFiles();
      if (uploaded.length > 0) {
        const res = await fetch(`${BASE}/api/payments/${proofPayment.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ commissionProof: uploaded[0].objectPath, commissionStatus: "paid" }),
        });
        if (!res.ok) throw new Error();
        toast({ title: "Justificatif envoyé", description: "La commission a été marquée comme réglée." });
        setProofPayment(null);
        queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
      }
    } catch {
      toast({ title: "Erreur", description: "Impossible d'envoyer le justificatif.", variant: "destructive" });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <Layout>
      <div className="flex flex-col gap-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold">Paiements</h1>
            <p className="text-muted-foreground mt-1">Suivez vos transactions et revenus.</p>
          </div>
          <Button
            variant="outline"
            className="rounded-xl gap-2"
            onClick={() => {
              if (!user?.id) return;
              const now = new Date();
              const url = `${BASE}/api/reports/provider/${user.id}/monthly?year=${now.getFullYear()}&month=${now.getMonth() + 1}`;
              window.open(url, "_blank");
            }}
          >
            <Download className="w-4 h-4" />
            Exporter mon rapport
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <SummaryCard
            title="Total Revenus"
            amount={summary?.totalRevenue || 0}
            icon={<Wallet className="w-5 h-5 text-primary" />}
            variant="primary"
          />
          <SummaryCard
            title="En attente"
            amount={summary?.pendingAmount || 0}
            icon={<History className="w-5 h-5 text-orange-500" />}
            variant="warning"
          />
          <SummaryCard
            title="Payé"
            amount={summary?.paidAmount || 0}
            icon={<Banknote className="w-5 h-5 text-green-500" />}
            variant="success"
          />
          <SummaryCard
            title="Commission (20%)"
            amount={totalCommission}
            icon={<Percent className="w-5 h-5 text-red-500" />}
            variant="danger"
          />
        </div>

        <Card className="rounded-2xl border-border/50 shadow-lg shadow-black/5 overflow-hidden">
          <CardHeader className="bg-muted/30 border-b border-border/50">
            <CardTitle className="flex items-center gap-2 text-lg">
              <CreditCard className="w-5 h-5 text-primary" />
              Historique des transactions
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {isLoading ? (
               <div className="p-8 space-y-4">
                 {[1,2,3,4].map(i => <div key={i} className="h-12 bg-muted/40 animate-pulse rounded-lg"></div>)}
               </div>
            ) : payments.length === 0 ? (
              <div className="p-12 text-center text-muted-foreground">
                <p>Aucune transaction trouvée.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/10 hover:bg-muted/10">
                      <TableHead className="font-semibold text-foreground">Date</TableHead>
                      <TableHead className="font-semibold text-foreground">Mission</TableHead>
                      <TableHead className="font-semibold text-foreground">Méthode</TableHead>
                      <TableHead className="font-semibold text-foreground text-right">Montant</TableHead>
                      <TableHead className="font-semibold text-foreground text-right">Commission</TableHead>
                      <TableHead className="font-semibold text-foreground text-center">Statut</TableHead>
                      <TableHead className="font-semibold text-foreground text-center">Commission</TableHead>
                      <TableHead className="font-semibold text-foreground text-center">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {payments.map((payment: any) => (
                      <TableRow
                        key={payment.id}
                        className="group hover:bg-muted/30 transition-colors cursor-pointer"
                        onClick={() => setPreviewPayment(payment)}
                      >
                        <TableCell className="text-muted-foreground whitespace-nowrap">
                          {formatDateTime(payment.createdAt)}
                        </TableCell>
                        <TableCell>
                          {payment.missionId ? (
                            <span className="font-medium">#{payment.missionId}</span>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-xs font-medium">
                            {PAYMENT_METHOD_LABELS[payment.clientPaymentMethod || payment.method] || payment.method}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right font-bold text-foreground">
                          {formatCurrency(payment.amount)}
                        </TableCell>
                        <TableCell className="text-right font-semibold text-red-600">
                          {payment.commissionAmount ? `-${formatCurrency(payment.commissionAmount)}` : "-"}
                        </TableCell>
                        <TableCell className="text-center">
                          <PaymentStatusBadge status={payment.status} />
                        </TableCell>
                        <TableCell className="text-center">
                          <CommissionStatusBadge status={payment.commissionStatus} />
                        </TableCell>
                        <TableCell className="text-center">
                          <div className="flex items-center justify-center gap-1" onClick={(e) => e.stopPropagation()}>
                            <Button variant="ghost" size="icon" className="h-8 w-8" title="Voir la mission" onClick={() => setPreviewPayment(payment)}>
                              <Eye className="w-4 h-4" />
                            </Button>
                            {payment.commissionStatus === "pending" && (
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-green-600" title="Joindre justificatif" onClick={() => setProofPayment(payment)}>
                                <Upload className="w-4 h-4" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={!!previewPayment} onOpenChange={(open) => !open && setPreviewPayment(null)}>
        <DialogContent className="sm:max-w-lg rounded-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Eye className="w-5 h-5 text-primary" />
              Détails de la mission #{previewPayment?.missionId}
            </DialogTitle>
          </DialogHeader>
          {previewPayment && (
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-start gap-2">
                  <User className="w-4 h-4 text-primary mt-0.5" />
                  <div>
                    <p className="text-xs text-muted-foreground">Client</p>
                    <p className="text-sm font-medium">{previewPayment.clientName || "-"}</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <Car className="w-4 h-4 text-primary mt-0.5" />
                  <div>
                    <p className="text-xs text-muted-foreground">Véhicule</p>
                    <p className="text-sm font-medium">{previewPayment.vehicleMake} {previewPayment.vehicleModel} <span className="text-muted-foreground">{previewPayment.vehiclePlate}</span></p>
                  </div>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-primary mt-0.5" />
                <div>
                  <p className="text-xs text-muted-foreground">Lieu d'intervention</p>
                  <p className="text-sm font-medium">{previewPayment.locationAddress || "-"}</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <FileText className="w-4 h-4 text-primary mt-0.5" />
                <div>
                  <p className="text-xs text-muted-foreground">Type d'intervention</p>
                  <p className="text-sm font-medium capitalize">{(previewPayment.interventionType || "-").replace("_", " ")}</p>
                </div>
              </div>
              <div className="border-t border-border/50 pt-4 grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground">Montant</p>
                  <p className="text-lg font-bold">{formatCurrency(previewPayment.amount)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Commission (20%)</p>
                  <p className="text-lg font-bold text-red-600">{previewPayment.commissionAmount ? formatCurrency(previewPayment.commissionAmount) : "-"}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Méthode de paiement</p>
                  <p className="text-sm font-medium">{PAYMENT_METHOD_LABELS[previewPayment.clientPaymentMethod || previewPayment.method] || previewPayment.method}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Statut commission</p>
                  <CommissionStatusBadge status={previewPayment.commissionStatus} />
                </div>
              </div>
              {previewPayment.commissionProof && (
                <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-3 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                  <span className="text-sm text-green-700 font-medium">Justificatif envoyé</span>
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setPreviewPayment(null)}>Fermer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!proofPayment} onOpenChange={(open) => !open && setProofPayment(null)}>
        <DialogContent className="sm:max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Upload className="w-5 h-5 text-green-600" />
              Justificatif de paiement
            </DialogTitle>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <p className="text-sm text-muted-foreground">
              Joignez un justificatif pour la commission de <strong>{proofPayment?.commissionAmount ? formatCurrency(proofPayment.commissionAmount) : ""}</strong> (Mission #{proofPayment?.missionId}).
            </p>
            <FileUploadZone ref={fileUploadRef} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setProofPayment(null)}>Annuler</Button>
            <Button
              onClick={handleUploadProof}
              disabled={isUploading}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              {isUploading ? "Envoi..." : "Envoyer le justificatif"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}

function SummaryCard({ title, amount, icon, variant }: { title: string, amount: number, icon: React.ReactNode, variant: 'primary' | 'warning' | 'success' | 'danger' }) {
  const bgColors = {
    primary: "bg-primary/10 border-primary/20",
    warning: "bg-orange-500/10 border-orange-500/20",
    success: "bg-green-500/10 border-green-500/20",
    danger: "bg-red-500/10 border-red-500/20",
  };

  return (
    <Card className={`rounded-2xl border shadow-sm ${bgColors[variant]}`}>
      <CardContent className="p-6 flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground mb-1">{title}</p>
          <h3 className="text-2xl font-display font-bold text-foreground">{formatCurrency(amount)}</h3>
        </div>
        <div className="p-4 rounded-full bg-background shadow-sm border border-border/50">
          {icon}
        </div>
      </CardContent>
    </Card>
  );
}

function PaymentStatusBadge({ status }: { status: string }) {
  switch (status) {
    case 'paid':
      return <Badge className="bg-green-500/10 text-green-700 hover:bg-green-500/20 border-green-500/20 font-medium">Payé</Badge>;
    case 'pending':
      return <Badge className="bg-orange-500/10 text-orange-700 hover:bg-orange-500/20 border-orange-500/20 font-medium">En attente</Badge>;
    case 'failed':
      return <Badge variant="destructive">Échoué</Badge>;
    case 'refunded':
      return <Badge variant="secondary">Remboursé</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
}

function CommissionStatusBadge({ status }: { status: string | null }) {
  if (!status) return <span className="text-muted-foreground text-xs">-</span>;
  switch (status) {
    case 'paid':
      return <Badge className="bg-green-500/10 text-green-700 hover:bg-green-500/20 border-green-500/20 text-xs">Réglée</Badge>;
    case 'pending':
      return <Badge className="bg-orange-500/10 text-orange-700 hover:bg-orange-500/20 border-orange-500/20 text-xs">À payer</Badge>;
    default:
      return <Badge variant="outline" className="text-xs">{status}</Badge>;
  }
}
