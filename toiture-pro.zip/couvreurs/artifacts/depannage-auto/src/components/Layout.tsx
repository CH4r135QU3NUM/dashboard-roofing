import { ReactNode, useEffect, useState } from "react";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "./AppSidebar";
import { Bell, Menu, CheckCheck, BellOff, Wrench, CreditCard, RefreshCw, Info, LogOut, UserCircle, BellRing } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { useMarkNotificationRead } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import { fr } from "date-fns/locale";
import { registerPushNotifications, isPushSupported, getPushPermission } from "@/lib/push";

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") || "";

const NOTIF_ICONS: Record<string, React.ReactNode> = {
  new_mission: <Wrench className="w-4 h-4 text-primary" />,
  mission_update: <RefreshCw className="w-4 h-4 text-blue-500" />,
  payment_received: <CreditCard className="w-4 h-4 text-green-500" />,
  system: <Info className="w-4 h-4 text-muted-foreground" />,
};

export function Layout({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [pushEnabled, setPushEnabled] = useState(false);

  useEffect(() => {
    if (!user?.id || !isPushSupported()) return;
    const perm = getPushPermission();
    if (perm === "granted") {
      registerPushNotifications(user.id).then(ok => setPushEnabled(ok));
    }
  }, [user?.id]);

  const handleEnablePush = async () => {
    if (!user?.id) return;
    const ok = await registerPushNotifications(user.id);
    setPushEnabled(ok);
  };

  const notifQueryKey = ["provider-notifications", user?.id];
  const { data: notificationsData } = useQuery({
    queryKey: notifQueryKey,
    queryFn: async () => {
      const url = user?.id ? `${BASE}/api/notifications?providerId=${user.id}` : `${BASE}/api/notifications`;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch notifications");
      return res.json();
    },
    enabled: !!user?.id,
    refetchInterval: 30_000,
  });
  const notifications = notificationsData?.notifications || [];
  const unreadCount = notificationsData?.unreadCount || 0;

  const refreshNotifications = () =>
    queryClient.invalidateQueries({ queryKey: notifQueryKey, refetchType: "all" });

  const markRead = useMarkNotificationRead({
    mutation: { onSuccess: refreshNotifications }
  });
  const markAllMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${BASE}/api/notifications/read-all`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ providerId: user?.id }),
      });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    onSuccess: refreshNotifications,
  });

  return (
    <SidebarProvider style={{ "--sidebar-width": "18rem" } as React.CSSProperties}>
      <div className="flex min-h-screen w-full bg-background text-foreground selection:bg-primary/30">
        <AppSidebar />
        
        <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
          <header className="h-16 flex items-center justify-between px-4 lg:px-8 border-b border-border bg-card/50 backdrop-blur-md sticky top-0 z-50">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="lg:hidden">
                <Menu className="w-5 h-5" />
              </SidebarTrigger>
            </div>
            
            <div className="flex items-center gap-4">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="ghost" size="icon" className="relative hover-elevate rounded-full">
                    <Bell className="w-5 h-5 text-muted-foreground" />
                    {unreadCount > 0 && (
                      <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-primary text-white border-2 border-card rounded-full text-[10px]">
                        {unreadCount > 99 ? '99+' : unreadCount}
                      </Badge>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent align="end" className="w-80 p-0 rounded-2xl shadow-xl border-border/50 overflow-hidden">
                  <div className="flex items-center justify-between px-4 py-3 border-b border-border/50 bg-muted/30">
                    <h3 className="font-semibold text-sm">Notifications</h3>
                    <div className="flex items-center gap-1">
                      {isPushSupported() && !pushEnabled && getPushPermission() !== "denied" && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-xs text-orange-600 hover:text-orange-700 h-auto py-1 px-2 gap-1"
                          onClick={handleEnablePush}
                        >
                          <BellRing className="w-3.5 h-3.5" />
                          Activer
                        </Button>
                      )}
                      {unreadCount > 0 && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-xs text-primary hover:text-primary h-auto py-1 px-2 gap-1"
                          onClick={() => markAllMutation.mutate()}
                          disabled={markAllMutation.isPending}
                        >
                          <CheckCheck className="w-3.5 h-3.5" />
                          Tout marquer lu
                        </Button>
                      )}
                    </div>
                  </div>
                  <div className="max-h-[380px] overflow-y-auto divide-y divide-border/40">
                    {notifications.length === 0 ? (
                      <div className="flex flex-col items-center justify-center py-10 text-muted-foreground gap-2">
                        <BellOff className="w-8 h-8 opacity-40" />
                        <p className="text-sm">Aucune notification</p>
                      </div>
                    ) : (
                      notifications.map((n) => (
                        <button
                          key={n.id}
                          className={`w-full text-left flex items-start gap-3 px-4 py-3 hover:bg-muted/50 transition-colors ${!n.isRead ? 'bg-primary/5' : ''}`}
                          onClick={() => !n.isRead && markRead.mutate({ id: n.id })}
                        >
                          <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0 mt-0.5">
                            {NOTIF_ICONS[n.type] || <Info className="w-4 h-4" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className={`text-sm leading-tight ${!n.isRead ? 'font-semibold' : 'font-medium'}`}>{n.title}</p>
                            <p className="text-xs text-muted-foreground mt-0.5 leading-snug">{n.message}</p>
                            <p className="text-[10px] text-muted-foreground/60 mt-1">
                              {formatDistanceToNow(new Date(n.createdAt), { addSuffix: true, locale: fr })}
                            </p>
                          </div>
                          {!n.isRead && <span className="w-2 h-2 rounded-full bg-primary flex-shrink-0 mt-1.5" />}
                        </button>
                      ))
                    )}
                  </div>
                </PopoverContent>
              </Popover>

              <ProviderUserButton />
            </div>
          </header>
          
          <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 scroll-smooth">
            <div className="max-w-7xl mx-auto w-full">
              {children}
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function ProviderUserButton() {
  const { user, logout } = useAuth();
  return (
    <div className="flex items-center gap-1">
      <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-primary to-orange-400 shadow-md shadow-primary/20 border-2 border-card flex items-center justify-center text-white text-xs font-bold select-none">
        {user?.name?.charAt(0)?.toUpperCase() || "P"}
      </div>
      <Button
        variant="ghost"
        size="icon"
        title="Se déconnecter"
        className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-full"
        onClick={logout}
      >
        <LogOut className="w-4 h-4" />
      </Button>
    </div>
  );
}
