import { LayoutDashboard, ClipboardList, CreditCard, BarChart3, Clock, HardHat, UserCircle } from "lucide-react";
import { Link, useLocation } from "wouter";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel,
  SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarHeader,
} from "@/components/ui/sidebar";

const navItems = [
  { title: "Tableau de bord",     url: "/",              icon: LayoutDashboard },
  { title: "Chantiers",           url: "/missions",      icon: ClipboardList },
  { title: "Paiements",           url: "/paiements",     icon: CreditCard },
  { title: "Historique & Stats",  url: "/historique",    icon: BarChart3 },
  { title: "Disponibilités",      url: "/disponibilites",icon: Clock },
  { title: "Mon Profil",          url: "/profil",        icon: UserCircle },
];

export function AppSidebar() {
  const [location] = useLocation();

  return (
    <Sidebar variant="sidebar" className="border-r border-sidebar-border bg-sidebar text-sidebar-foreground">
      <SidebarHeader className="p-4 pt-6">
        <div className="flex items-center gap-3 px-2">
          <div className="bg-primary p-2 rounded-xl shadow-lg shadow-primary/20">
            <HardHat className="w-6 h-6 text-primary-foreground" />
          </div>
          <div className="flex flex-col">
            <span className="font-display font-bold text-xl leading-tight text-sidebar-foreground">
              Toiture<span className="text-primary">Pro</span>
            </span>
            <span className="text-xs text-sidebar-foreground/60">Espace Couvreur</span>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent className="mt-6">
        <SidebarGroup>
          <SidebarGroupLabel className="text-sidebar-foreground/50 text-xs font-semibold tracking-wider uppercase px-4 mb-2">
            Menu Principal
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {navItems.map(item => {
                const isActive = location === item.url || (item.url !== "/" && location.startsWith(item.url));
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild isActive={isActive}
                      className={`my-1 px-4 py-3 mx-2 rounded-xl transition-all duration-200 ${isActive ? "bg-primary/10 text-primary font-semibold shadow-sm" : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"}`}>
                      <Link href={item.url} className="flex items-center gap-3 w-full">
                        <item.icon className={`w-5 h-5 ${isActive ? "text-primary" : ""}`} />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
