import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/lib/auth";
import Login from "@/pages/Login";
import { Loader2 } from "lucide-react";

import Dashboard from "@/pages/Dashboard";
import Missions from "@/pages/Missions";
import Payments from "@/pages/Payments";
import History from "@/pages/History";
import Availability from "@/pages/Availability";
import Tracking from "@/pages/Tracking";
import Profile from "@/pages/Profile";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
      staleTime: 5 * 60 * 1000,
    },
  },
});

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!user) return <Login />;
  return <Component />;
}

function Router() {
  return (
    <Switch>
      {/* Public route — no auth needed */}
      <Route path="/tracking/:id" component={Tracking} />
      <Route path="/login" component={Login} />

      {/* Protected routes */}
      <Route path="/" component={() => <ProtectedRoute component={Dashboard} />} />
      <Route path="/missions" component={() => <ProtectedRoute component={Missions} />} />
      <Route path="/paiements" component={() => <ProtectedRoute component={Payments} />} />
      <Route path="/historique" component={() => <ProtectedRoute component={History} />} />
      <Route path="/disponibilites" component={() => <ProtectedRoute component={Availability} />} />
      <Route path="/profil" component={() => <ProtectedRoute component={Profile} />} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
