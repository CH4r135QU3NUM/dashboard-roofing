import { format, parseISO } from "date-fns";
import { fr } from "date-fns/locale";

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(amount);
}

export function formatDateTime(dateString: string | null | undefined): string {
  if (!dateString) return "N/A";
  try {
    const withoutTz = dateString.replace("Z", "").replace(/\+\d{2}:\d{2}$/, "");
    return format(parseISO(withoutTz), "dd MMM yyyy, HH:mm", { locale: fr });
  } catch { return dateString; }
}

export function formatDate(dateString: string | null | undefined): string {
  if (!dateString) return "N/A";
  try {
    const withoutTz = dateString.replace("Z", "").replace(/\+\d{2}:\d{2}$/, "");
    return format(parseISO(withoutTz), "dd MMM yyyy", { locale: fr });
  } catch { return dateString; }
}

export function getStatusLabel(status: string): string {
  const map: Record<string, string> = {
    pending:     "En attente",
    confirmed:   "Confirmé",
    in_progress: "En cours",
    completed:   "Terminé",
    cancelled:   "Annulé",
  };
  return map[status] || status;
}

export function getPriorityLabel(priority: string): string {
  const map: Record<string, string> = {
    low:    "Basse",
    normal: "Normale",
    high:   "Haute",
    urgent: "Urgente",
  };
  return map[priority] || priority;
}

export function getInterventionLabel(type: string): string {
  const map: Record<string, string> = {
    reparation_fuite:    "Réparation fuite",
    remplacement_tuiles: "Remplacement tuiles",
    renovation_complete: "Rénovation complète",
    nettoyage_toiture:   "Nettoyage / traitement",
    pose_velux:          "Pose Velux",
    isolation_combles:   "Isolation combles",
    autre:               "Autre",
  };
  return map[type] || type;
}

export function getRoofTypeLabel(type: string): string {
  const map: Record<string, string> = {
    tuiles_terre_cuite: "Tuiles terre cuite",
    tuiles_beton:       "Tuiles béton",
    ardoise:            "Ardoise",
    zinc:               "Zinc",
    bac_acier:          "Bac acier",
    bitume:             "Bitume",
    chaume:             "Chaume",
    autre:              "Autre",
  };
  return map[type] || type;
}
