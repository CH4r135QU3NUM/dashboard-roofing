import { db } from "@workspace/db";
import { missionsTable, notificationsTable } from "@workspace/db/schema";
import { and, eq, gte, lte, inArray, sql } from "drizzle-orm";
import { sendPushToProvider } from "./routes/push";

async function hasSentReminder(missionId: number): Promise<boolean> {
  const [row] = await db
    .select({ id: notificationsTable.id })
    .from(notificationsTable)
    .where(
      and(
        eq(notificationsTable.missionId, missionId),
        sql`${notificationsTable.title} = 'Rappel de chantier'`
      )
    )
    .limit(1);
  return !!row;
}

async function checkUpcomingMissions() {
  try {
    const now = new Date();
    const oneHourFromNow = new Date(now.getTime() + 60 * 60 * 1000);

    const upcoming = await db
      .select()
      .from(missionsTable)
      .where(
        and(
          gte(missionsTable.scheduledAt, now),
          lte(missionsTable.scheduledAt, oneHourFromNow),
          inArray(missionsTable.status, ["pending", "confirmed", "in_progress"])
        )
      );

    for (const mission of upcoming) {
      if (!mission.providerId) continue;
      const alreadySent = await hasSentReminder(mission.id);
      if (alreadySent) continue;

      const scheduledAt = new Date(mission.scheduledAt);
      const minutesUntil = Math.round((scheduledAt.getTime() - now.getTime()) / 60000);

      await db.insert(notificationsTable).values({
        type: "mission_update",
        title: "Rappel de chantier",
        message: `Chantier #${mission.id} dans ${minutesUntil} minutes — ${mission.interventionType || "Couverture"} à ${mission.locationAddress || ""}`,
        missionId: mission.id,
        providerId: mission.providerId,
        isRead: false,
      });

      sendPushToProvider(mission.providerId, {
        title: "Rappel — Chantier dans moins d'1 heure",
        body: `Chantier #${mission.id} prévu dans ${minutesUntil} min — ${mission.clientName || ""} à ${mission.locationAddress || ""}`,
        url: `/missions?id=${mission.id}`,
      });
    }
  } catch (err) {
    console.error("Rappel chantier — erreur :", err);
  }
}

export function startMissionReminderScheduler() {
  console.log("Rappel chantiers actif (toutes les 5 min) — déduplication en base");
  setInterval(checkUpcomingMissions, 5 * 60 * 1000);
  setTimeout(checkUpcomingMissions, 10_000);
}
