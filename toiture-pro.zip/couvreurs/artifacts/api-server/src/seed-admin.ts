import bcrypt from "bcryptjs";
import { db } from "@workspace/db";
import { adminsTable, settingsTable } from "@workspace/db";
import { count, eq } from "drizzle-orm";

export async function seedAdmin() {
  try {
    const [result] = await db.select({ total: count() }).from(adminsTable);
    if (result.total > 0) return;

    const email = process.env["ADMIN_EMAIL"] || "admin@toiture-pro.fr";
    const password = process.env["ADMIN_PASSWORD"] || "Admin123!";
    const name = "Super Admin";

    const passwordHash = await bcrypt.hash(password, 12);
    await db.insert(adminsTable).values({ name, email, passwordHash });
    console.log(`✅ Admin créé : ${email} / ${password}`);
  } catch (err) {
    console.error("Erreur lors de la création de l'admin :", err);
  }

  try {
    const [existing] = await db.select().from(settingsTable).where(eq(settingsTable.key, "deletionCode"));
    if (!existing) {
      await db.insert(settingsTable).values({ key: "deletionCode", value: "Admin123!" });
      console.log("✅ Code de suppression par défaut défini : Admin123!");
    }
  } catch (err) {
    console.error("Erreur lors du seed des réglages :", err);
  }
}
