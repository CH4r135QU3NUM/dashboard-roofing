import express, { type Express } from "express";
import cors from "cors";
import router from "./routes";

// ─── Vérification des secrets obligatoires au démarrage ───────────────────────
// Le serveur refuse de démarrer si les variables critiques sont absentes.
// Cela évite les fallbacks hardcodés dangereux en production.
const REQUIRED_ENV = ["JWT_SECRET"] as const;
const missing = REQUIRED_ENV.filter((k) => !process.env[k]);
if (missing.length > 0) {
  console.error(
    `[FATAL] Variables d'environnement manquantes : ${missing.join(", ")}\n` +
    `Le serveur ne peut pas démarrer sans ces secrets.`
  );
  process.exit(1);
}

// ─── CORS ─────────────────────────────────────────────────────────────────────
// En production, restreindre aux origines connues via ALLOWED_ORIGINS.
// En développement (NODE_ENV !== "production"), toutes les origines sont autorisées.
const allowedOrigins = process.env["ALLOWED_ORIGINS"]
  ? process.env["ALLOWED_ORIGINS"].split(",").map((o) => o.trim())
  : [];

const corsOptions: cors.CorsOptions =
  process.env["NODE_ENV"] === "production" && allowedOrigins.length > 0
    ? {
        origin: (origin, callback) => {
          // Autoriser les requêtes sans origin (ex. Postman, SSR côté serveur)
          if (!origin || allowedOrigins.includes(origin)) {
            callback(null, true);
          } else {
            callback(new Error(`Origine non autorisée : ${origin}`));
          }
        },
        credentials: true,
      }
    : {}; // Développement : accès libre

const app: Express = express();

app.use(cors(corsOptions));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

export default app;
