import { Request, Response, NextFunction } from "express";
import { verifyToken } from "../routes/auth";

export interface AuthRequest extends Request {
  user?: { id: number; email: string; name: string; role: string };
}

/**
 * Middleware d'authentification générique.
 * Vérifie la présence et la validité du token JWT dans le header Authorization.
 */
export function requireAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Non authentifié." });
  }
  try {
    const token = authHeader.slice(7);
    const payload = verifyToken(token);
    req.user = {
      id: Number(payload["id"]),
      email: String(payload["email"]),
      name: String(payload["name"]),
      role: String(payload["role"]),
    };
    next();
  } catch {
    return res.status(401).json({ error: "Token invalide ou expiré." });
  }
}

/**
 * Middleware réservé aux admins.
 */
export function requireAdmin(req: AuthRequest, res: Response, next: NextFunction) {
  requireAuth(req, res, () => {
    if (req.user?.role !== "admin") {
      return res.status(403).json({ error: "Accès réservé aux administrateurs." });
    }
    next();
  });
}

/**
 * Middleware réservé aux prestataires.
 * Un admin peut également accéder aux routes prestataire.
 */
export function requireProvider(req: AuthRequest, res: Response, next: NextFunction) {
  requireAuth(req, res, () => {
    if (req.user?.role !== "provider" && req.user?.role !== "admin") {
      return res.status(403).json({ error: "Accès réservé aux prestataires." });
    }
    next();
  });
}
