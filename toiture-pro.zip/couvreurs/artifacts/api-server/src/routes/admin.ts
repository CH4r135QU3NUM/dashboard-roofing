import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import {
  providersTable,
  clientsTable,
  vehiclesTable,
  missionsTable,
  paymentsTable,
} from "@workspace/db/schema";
import { eq, count, sum, desc, sql, and, gte } from "drizzle-orm";

const router: IRouter = Router();

router.get("/admin/stats", async (req, res) => {
  try {
    const [providerStats] = await db
      .select({
        total: count(),
        active: sql<number>`count(*) filter (where ${providersTable.status} = 'active')`,
      })
      .from(providersTable);

    const [clientStats] = await db.select({ total: count() }).from(clientsTable);
    const [vehicleStats] = await db.select({ total: count() }).from(vehiclesTable);

    const [missionStats] = await db
      .select({
        total: count(),
        pending: sql<number>`count(*) filter (where ${missionsTable.status} = 'pending' or ${missionsTable.status} = 'confirmed' or ${missionsTable.status} = 'in_progress')`,
        completed: sql<number>`count(*) filter (where ${missionsTable.status} = 'completed')`,
        totalRevenue: sum(missionsTable.amount),
      })
      .from(missionsTable);

    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const [monthRevenue] = await db
      .select({ revenue: sum(missionsTable.amount) })
      .from(missionsTable)
      .where(gte(missionsTable.completedAt, startOfMonth));

    const missionsByMonth = await db
      .select({
        month: sql<string>`to_char(${missionsTable.scheduledAt}, 'YYYY-MM')`,
        missions: count(missionsTable.id),
        revenue: sum(missionsTable.amount),
      })
      .from(missionsTable)
      .groupBy(sql`to_char(${missionsTable.scheduledAt}, 'YYYY-MM')`)
      .orderBy(sql`to_char(${missionsTable.scheduledAt}, 'YYYY-MM')`);

    const missionsByStatus = await db
      .select({
        status: missionsTable.status,
        count: count(missionsTable.id),
      })
      .from(missionsTable)
      .groupBy(missionsTable.status);

    const topProviders = await db
      .select({
        id: providersTable.id,
        name: providersTable.name,
        missions: count(missionsTable.id),
        revenue: sum(missionsTable.amount),
        rating: providersTable.rating,
      })
      .from(providersTable)
      .leftJoin(missionsTable, eq(missionsTable.providerId, providersTable.id))
      .groupBy(providersTable.id, providersTable.name, providersTable.rating)
      .orderBy(desc(count(missionsTable.id)))
      .limit(5);

    const recentMissions = await db
      .select({
        id: missionsTable.id,
        providerId: missionsTable.providerId,
        providerName: providersTable.name,
        clientName: missionsTable.clientName,
        clientPhone: missionsTable.clientPhone,
        interventionType: missionsTable.interventionType,
        
        
        interventionType: missionsTable.interventionType,
        description: missionsTable.description,
        locationAddress: missionsTable.locationAddress,
        status: missionsTable.status,
        priority: missionsTable.priority,
        estimatedDuration: missionsTable.estimatedDuration,
        scheduledAt: missionsTable.scheduledAt,
        completedAt: missionsTable.completedAt,
        amount: missionsTable.amount,
        notes: missionsTable.notes,
        createdAt: missionsTable.createdAt,
        updatedAt: missionsTable.updatedAt,
      })
      .from(missionsTable)
      .leftJoin(providersTable, eq(missionsTable.providerId, providersTable.id))
      .orderBy(desc(missionsTable.createdAt))
      .limit(5);

    const allProviders = await db.select().from(providersTable);
    const allMissions = await db.select().from(missionsTable);
    const providerZoneMap = new Map(allProviders.map(p => [p.id, p.zone || null]));

    const zoneMap: Record<string, { missions: number; revenue: number }> = {};
    for (const m of allMissions) {
      const zone = m.providerId ? (providerZoneMap.get(m.providerId) || "Inconnue") : "Non assignée";
      if (!zoneMap[zone]) zoneMap[zone] = { missions: 0, revenue: 0 };
      zoneMap[zone].missions++;
      if (m.status === "completed") zoneMap[zone].revenue += m.amount || 0;
    }
    const topCities = Object.entries(zoneMap)
      .filter(([zone]) => zone !== "Non assignée")
      .map(([city, d]) => ({ city, missions: d.missions, revenue: d.revenue }))
      .sort((a, b) => b.missions - a.missions)
      .slice(0, 10);

    const topRefusals = await db
      .select({
        providerId: providersTable.id,
        name: providersTable.name,
        refusalCount: providersTable.refusalCount,
      })
      .from(providersTable)
      .orderBy(desc(providersTable.refusalCount))
      .limit(10);

    res.json({
      totalProviders: Number(providerStats.total),
      activeProviders: Number(providerStats.active),
      totalClients: Number(clientStats.total),
      totalVehicles: Number(vehicleStats.total),
      totalMissions: Number(missionStats.total),
      pendingMissions: Number(missionStats.pending),
      completedMissions: Number(missionStats.completed),
      totalRevenue: Number(missionStats.totalRevenue || 0),
      revenueThisMonth: Number(monthRevenue.revenue || 0),
      missionsByMonth: missionsByMonth.map((m) => ({
        month: m.month,
        missions: Number(m.missions),
        revenue: Number(m.revenue || 0),
      })),
      missionsByStatus: missionsByStatus.map((s) => ({
        status: s.status,
        count: Number(s.count),
      })),
      topProviders: topProviders.map((p) => ({
        id: p.id,
        name: p.name,
        missions: Number(p.missions),
        revenue: Number(p.revenue || 0),
        rating: p.rating || 0,
      })),
      recentMissions,
      topCities,
      topRefusals,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
