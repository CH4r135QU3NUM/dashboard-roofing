import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { missionsTable, providersTable, missionRefusalsTable } from "@workspace/db/schema";
import { desc, gte, and, eq, count, sum, sql } from "drizzle-orm";
import { requireAuth } from "../middleware/auth";

const router: IRouter = Router();

router.get("/stats", requireAuth, async (req, res) => {
  try {
    const { period = "month", providerId } = req.query as { period?: string; providerId?: string };

    // ── Calcul de la borne de date ──────────────────────────────────────────
    let since: Date | undefined;
    const now = new Date();
    if (period === "week") {
      since = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    } else if (period === "month") {
      since = new Date(now.getFullYear(), now.getMonth(), 1);
    } else if (period === "year") {
      since = new Date(now.getFullYear(), 0, 1);
    }

    const providerCondition = providerId ? eq(missionsTable.providerId, parseInt(providerId)) : undefined;
    const periodCondition = since ? gte(missionsTable.createdAt, since) : undefined;
    const filteredCondition = [providerCondition, periodCondition].filter(Boolean);

    // ── Agrégations globales (via SQL — ne charge plus tout en mémoire) ─────
    const [agg] = await db
      .select({
        totalMissions:    count(missionsTable.id),
        completedCount:   sql<number>`COUNT(*) FILTER (WHERE ${missionsTable.status} = 'completed')`,
        cancelledCount:   sql<number>`COUNT(*) FILTER (WHERE ${missionsTable.status} = 'cancelled')`,
        totalRevenue:     sql<number>`COALESCE(SUM(${missionsTable.amount}) FILTER (WHERE ${missionsTable.status} = 'completed'), 0)`,
      })
      .from(missionsTable)
      .where(filteredCondition.length > 0 ? and(...filteredCondition) : undefined);

    const totalMissions   = Number(agg?.totalMissions ?? 0);
    const completedCount  = Number(agg?.completedCount ?? 0);
    const cancelledCount  = Number(agg?.cancelledCount ?? 0);
    const totalRevenue    = Number(agg?.totalRevenue ?? 0);
    const avgRevenue      = completedCount > 0 ? totalRevenue / completedCount : 0;

    // ── Durée moyenne (entre scheduledAt et completedAt) ───────────────────
    const [durationAgg] = await db
      .select({
        avgDuration: sql<number>`
          COALESCE(
            AVG(ABS(EXTRACT(EPOCH FROM (${missionsTable.completedAt} - ${missionsTable.scheduledAt})) / 60)),
            0
          )
        `,
      })
      .from(missionsTable)
      .where(
        and(
          ...(filteredCondition.length > 0 ? filteredCondition : [sql`1=1`]),
          sql`${missionsTable.status} = 'completed'`,
          sql`${missionsTable.completedAt} IS NOT NULL`
        )
      );
    const avgDuration = Number(durationAgg?.avgDuration ?? 0);

    // ── Par type d'intervention ─────────────────────────────────────────────
    const byType = await db
      .select({
        type:    missionsTable.interventionType,
        total:   count(missionsTable.id),
        revenue: sql<number>`COALESCE(SUM(${missionsTable.amount}) FILTER (WHERE ${missionsTable.status} = 'completed'), 0)`,
      })
      .from(missionsTable)
      .where(filteredCondition.length > 0 ? and(...filteredCondition) : undefined)
      .groupBy(missionsTable.interventionType);

    const missionsByType = byType.map(r => ({
      type:    r.type,
      count:   Number(r.total),
      revenue: Number(r.revenue),
    }));

    // ── Par mois (12 derniers mois, sans filtre de période pour avoir l'historique) ─
    const allTimeCondition = providerCondition ? [providerCondition] : [];
    const byMonth = await db
      .select({
        month:   sql<string>`TO_CHAR(${missionsTable.createdAt}, 'YYYY-MM')`,
        total:   count(missionsTable.id),
        revenue: sql<number>`COALESCE(SUM(${missionsTable.amount}) FILTER (WHERE ${missionsTable.status} = 'completed'), 0)`,
      })
      .from(missionsTable)
      .where(
        and(
          ...(allTimeCondition.length > 0 ? allTimeCondition : [sql`1=1`]),
          gte(missionsTable.createdAt, new Date(now.getFullYear() - 1, now.getMonth(), 1))
        )
      )
      .groupBy(sql`TO_CHAR(${missionsTable.createdAt}, 'YYYY-MM')`)
      .orderBy(sql`TO_CHAR(${missionsTable.createdAt}, 'YYYY-MM')`);

    const missionsByMonth = byMonth.map(r => ({
      month:    r.month,
      missions: Number(r.total),
      revenue:  Number(r.revenue),
    }));

    // ── Top villes (basé sur zone du prestataire — comportement conservé intentionnellement) ─
    const topCitiesRaw = await db
      .select({
        zone:    providersTable.zone,
        total:   count(missionsTable.id),
        revenue: sql<number>`COALESCE(SUM(${missionsTable.amount}) FILTER (WHERE ${missionsTable.status} = 'completed'), 0)`,
      })
      .from(missionsTable)
      .innerJoin(providersTable, eq(missionsTable.providerId, providersTable.id))
      .where(
        and(
          ...(filteredCondition.length > 0 ? filteredCondition : [sql`1=1`]),
          sql`${providersTable.zone} IS NOT NULL`
        )
      )
      .groupBy(providersTable.zone)
      .orderBy(sql`COUNT(${missionsTable.id}) DESC`)
      .limit(10);

    const topCities = topCitiesRaw.map(r => ({
      city:     r.zone ?? "Inconnue",
      missions: Number(r.total),
      revenue:  Number(r.revenue),
    }));

    // ── Top refus ──────────────────────────────────────────────────────────
    const topRefusals = await db
      .select({
        providerId:   providersTable.id,
        name:         providersTable.name,
        refusalCount: providersTable.refusalCount,
      })
      .from(providersTable)
      .orderBy(desc(providersTable.refusalCount))
      .limit(10);

    // ── Activité récente ───────────────────────────────────────────────────
    const recentActivity = await db
      .select()
      .from(missionsTable)
      .where(providerCondition)
      .orderBy(desc(missionsTable.createdAt))
      .limit(5);

    res.json({
      totalMissions,
      completedMissions: completedCount,
      cancelledMissions: cancelledCount,
      avgDuration,
      totalRevenue,
      avgRevenue,
      missionsByType,
      missionsByMonth,
      recentActivity,
      topCities,
      topRefusals,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
