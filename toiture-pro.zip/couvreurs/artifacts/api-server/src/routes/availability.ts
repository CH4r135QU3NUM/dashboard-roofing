import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { availabilityTable, availabilitySlotsTable } from "@workspace/db/schema";
import { eq, desc } from "drizzle-orm";

const router: IRouter = Router();

async function getOrCreateAvailability() {
  const rows = await db.select().from(availabilityTable).limit(1);
  if (rows.length > 0) return rows[0];
  const [row] = await db.insert(availabilityTable).values({
    isAvailable: true,
    workingHoursStart: "08:00",
    workingHoursEnd: "20:00",
    workingDays: [1, 2, 3, 4, 5, 6],
    maxDailyMissions: 8,
    interventionRadius: 50,
  }).returning();
  return row;
}

function getProviderIdFromRequest(req: any): number | null {
  try {
    const authHeader = req.headers.authorization as string | undefined;
    if (!authHeader?.startsWith("Bearer ")) return null;
    const token = authHeader.slice(7);
    const payload = verifyToken(token);
    if (payload.role === "provider" && payload.id) return Number(payload.id);
  } catch {
    // ignore invalid tokens
  }
  return null;
}

router.get("/availability", async (_req, res) => {
  try {
    const avail = await getOrCreateAvailability();
    res.json(avail);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/availability", async (req, res) => {
  try {
    const avail = await getOrCreateAvailability();
    const body = req.body;
    const updates: any = { updatedAt: new Date() };
    if (body.isAvailable !== undefined) updates.isAvailable = body.isAvailable;
    if (body.workingHoursStart !== undefined) updates.workingHoursStart = body.workingHoursStart;
    if (body.workingHoursEnd !== undefined) updates.workingHoursEnd = body.workingHoursEnd;
    if (body.workingDays !== undefined) updates.workingDays = body.workingDays;
    if (body.maxDailyMissions !== undefined) updates.maxDailyMissions = body.maxDailyMissions;
    if (body.interventionRadius !== undefined) updates.interventionRadius = body.interventionRadius;

    const [updated] = await db.update(availabilityTable).set(updates).where(eq(availabilityTable.id, avail.id)).returning();


    res.json(updated);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/availability/slots", async (_req, res) => {
  try {
    const slots = await db.select().from(availabilitySlotsTable).orderBy(desc(availabilitySlotsTable.startAt));
    res.json({ slots });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/availability/slots", async (req, res) => {
  try {
    const { startAt, endAt, reason } = req.body;
    const [slot] = await db.insert(availabilitySlotsTable).values({
      startAt: new Date(startAt),
      endAt: new Date(endAt),
      reason: reason || null,
    }).returning();
    res.status(201).json(slot);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/availability/slots/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.delete(availabilitySlotsTable).where(eq(availabilitySlotsTable.id, id));
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
