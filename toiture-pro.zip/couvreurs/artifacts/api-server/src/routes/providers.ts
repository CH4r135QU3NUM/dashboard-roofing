import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { providersTable, missionsTable, missionRefusalsTable } from "@workspace/db/schema";
import { eq, desc, count, sum, sql } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { requireAdmin, requireAuth } from "../middleware/auth";

const router: IRouter = Router();

router.get("/providers", requireAuth, async (req, res) => {
  try {
    const providers = await db.select().from(providersTable).orderBy(desc(providersTable.createdAt));

    const missionStats = await db
      .select({
        providerId: missionsTable.providerId,
        totalMissions: count(missionsTable.id),
        totalRevenue: sum(missionsTable.amount),
      })
      .from(missionsTable)
      .groupBy(missionsTable.providerId);

    const statsMap = new Map(missionStats.map((s) => [s.providerId, s]));

    const result = providers.map((p) => {
      const stats = statsMap.get(p.id);
      return {
        ...p,
        passwordHash: undefined, // Ne jamais exposer le hash
        totalMissions: Number(stats?.totalMissions || 0),
        totalRevenue: Number(stats?.totalRevenue || 0),
      };
    });

    res.json({ providers: result, total: result.length });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/providers", requireAdmin, async (req, res) => {
  try {
    const body = req.body;
    const [provider] = await db
      .insert(providersTable)
      .values({
        name: body.name,
        email: body.email,
        phone: body.phone,
        address: body.address || null,
        zone: body.zone || null,
        specialties: body.specialties || [],
        storageType: body.storageType || null,
        storageCapacity: body.storageCapacity ? Number(body.storageCapacity) : null,
        storagePricePerDay: body.storagePricePerDay ? Number(body.storagePricePerDay) : null,
        storageAddress: body.storageAddress || null,
        siret: body.siret || null,
        companyName: body.companyName || null,
        tvaNumber: body.tvaNumber || null,
        isSubjectToTva: body.isSubjectToTva ?? false,
        acceptedPaymentMethods: body.acceptedPaymentMethods || [],
        status: body.status || "active",
        isAvailable: true,
      })
      .returning();
    res.status(201).json({ ...provider, passwordHash: undefined, totalMissions: 0, totalRevenue: 0 });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/providers/:id", requireAuth, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [provider] = await db.select().from(providersTable).where(eq(providersTable.id, id));
    if (!provider) return res.status(404).json({ error: "Provider not found" });

    const [stats] = await db
      .select({
        totalMissions: count(missionsTable.id),
        totalRevenue: sum(missionsTable.amount),
      })
      .from(missionsTable)
      .where(eq(missionsTable.providerId, id));

    res.json({
      ...provider,
      passwordHash: undefined,
      totalMissions: Number(stats?.totalMissions || 0),
      totalRevenue: Number(stats?.totalRevenue || 0),
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/providers/:id", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const body = req.body;
    const updates: any = { updatedAt: new Date() };
    if (body.name !== undefined) updates.name = body.name;
    if (body.email !== undefined) updates.email = body.email;
    if (body.phone !== undefined) updates.phone = body.phone;
    if (body.address !== undefined) updates.address = body.address;
    if (body.zone !== undefined) updates.zone = body.zone;
    if (body.specialties !== undefined) updates.specialties = body.specialties;
    if (body.storageType !== undefined) updates.storageType = body.storageType || null;
    if (body.storageCapacity !== undefined) updates.storageCapacity = body.storageCapacity ? Number(body.storageCapacity) : null;
    if (body.storagePricePerDay !== undefined) updates.storagePricePerDay = body.storagePricePerDay ? Number(body.storagePricePerDay) : null;
    if (body.storageAddress !== undefined) updates.storageAddress = body.storageAddress || null;
    if (body.siret !== undefined) updates.siret = body.siret || null;
    if (body.companyName !== undefined) updates.companyName = body.companyName || null;
    if (body.tvaNumber !== undefined) updates.tvaNumber = body.tvaNumber || null;
    if (body.isSubjectToTva !== undefined) updates.isSubjectToTva = body.isSubjectToTva;
    if (body.status !== undefined) updates.status = body.status;
    if (body.rating !== undefined) updates.rating = body.rating !== null ? Number(body.rating) : null;
    if (body.isAvailable !== undefined) updates.isAvailable = body.isAvailable;
    if (body.acceptedPaymentMethods !== undefined) updates.acceptedPaymentMethods = body.acceptedPaymentMethods;
    if (body.towTruckPhoto !== undefined) updates.towTruckPhoto = body.towTruckPhoto || null;
    if (body.insuranceDocument !== undefined) updates.insuranceDocument = body.insuranceDocument || null;

    const [provider] = await db
      .update(providersTable)
      .set(updates)
      .where(eq(providersTable.id, id))
      .returning();

    if (!provider) return res.status(404).json({ error: "Provider not found" });

    const [stats] = await db
      .select({
        totalMissions: count(missionsTable.id),
        totalRevenue: sum(missionsTable.amount),
      })
      .from(missionsTable)
      .where(eq(missionsTable.providerId, id));

    res.json({
      ...provider,
      passwordHash: undefined,
      totalMissions: Number(stats?.totalMissions || 0),
      totalRevenue: Number(stats?.totalRevenue || 0),
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/providers/:id/refusals", requireAuth, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const refusals = await db
      .select({
        id: missionRefusalsTable.id,
        missionId: missionRefusalsTable.missionId,
        reason: missionRefusalsTable.reason,
        createdAt: missionRefusalsTable.createdAt,
      })
      .from(missionRefusalsTable)
      .where(eq(missionRefusalsTable.providerId, id))
      .orderBy(desc(missionRefusalsTable.createdAt));
    res.json(refusals);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── NOUVEAU : Réinitialiser le compteur de refus d'un prestataire ────────────
// Accessible uniquement par un admin. Permet de repartir de zéro après une
// période difficile ou une erreur de saisie.
router.post("/providers/:id/reset-refusal-count", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: "ID invalide" });

    const [provider] = await db
      .update(providersTable)
      .set({ refusalCount: 0, updatedAt: new Date() })
      .where(eq(providersTable.id, id))
      .returning({ id: providersTable.id, name: providersTable.name, refusalCount: providersTable.refusalCount });

    if (!provider) return res.status(404).json({ error: "Prestataire introuvable" });

    res.json({ success: true, provider });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/providers/:id", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.delete(providersTable).where(eq(providersTable.id, id));
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.put("/providers/:id/password", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { password } = req.body;
    if (!password || password.length < 6) {
      return res.status(400).json({ error: "Le mot de passe doit contenir au moins 6 caractères." });
    }
    const passwordHash = await bcrypt.hash(password, 12);
    await db.update(providersTable)
      .set({ passwordHash, updatedAt: new Date() })
      .where(eq(providersTable.id, id));
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
