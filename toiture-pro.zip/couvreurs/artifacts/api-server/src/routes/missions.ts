import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import {
  missionsTable,
  notificationsTable,
  providersTable,
  missionAttachmentsTable,
  settingsTable,
  paymentsTable,
  missionRefusalsTable,
} from "@workspace/db/schema";
import { eq, desc, count, sql, and, gte, lte } from "drizzle-orm";
import { sendPushToProvider } from "./push";
import { requireAuth, requireAdmin, requireProvider, type AuthRequest } from "../middleware/auth";

// ─── Machine d'états ──────────────────────────────────────────────────────────
const ALLOWED_TRANSITIONS: Record<string, string[]> = {
  pending:     ["confirmed", "cancelled"],
  confirmed:   ["in_progress", "cancelled"],
  in_progress: ["completed", "cancelled"],
  completed:   [],
  cancelled:   [],
};

function isValidTransition(from: string, to: string): boolean {
  return ALLOWED_TRANSITIONS[from]?.includes(to) ?? false;
}

function isValidCoords(lat: unknown, lng: unknown): boolean {
  const la = Number(lat);
  const lo = Number(lng);
  return isFinite(la) && la >= -90 && la <= 90 && isFinite(lo) && lo >= -180 && lo <= 180;
}

async function upsertMissionPayment(missionId: number, amount: number, paymentMethod?: string) {
  const commissionAmount = Math.round(amount * 0.2 * 100) / 100;
  const method = paymentMethod || "virement";
  const existing = await db.select().from(paymentsTable).where(eq(paymentsTable.missionId, missionId)).limit(1);
  if (existing.length > 0) {
    await db.update(paymentsTable).set({ amount, commissionAmount, method }).where(eq(paymentsTable.missionId, missionId));
  } else {
    await db.insert(paymentsTable).values({
      missionId,
      amount,
      currency: "EUR",
      status: "pending",
      method,
      commissionAmount,
      commissionStatus: "pending",
    });
  }
}

const router: IRouter = Router();

const missionWithProvider = {
  id: missionsTable.id,
  providerId: missionsTable.providerId,
  providerName: providersTable.name,
  clientName: missionsTable.clientName,
  clientPhone: missionsTable.clientPhone,
  roofType: missionsTable.roofType,
  roofTypeOther: missionsTable.roofTypeOther,
  roofSurface: missionsTable.roofSurface,
  roofAge: missionsTable.roofAge,
  interventionType: missionsTable.interventionType,
  description: missionsTable.description,
  locationAddress: missionsTable.locationAddress,
  locationLat: missionsTable.locationLat,
  locationLng: missionsTable.locationLng,
  status: missionsTable.status,
  priority: missionsTable.priority,
  estimatedDuration: missionsTable.estimatedDuration,
  scheduledAt: missionsTable.scheduledAt,
  completedAt: missionsTable.completedAt,
  amount: missionsTable.amount,
  clientPaymentMethod: missionsTable.clientPaymentMethod,
  photos: missionsTable.photos,
  notes: missionsTable.notes,
  createdAt: missionsTable.createdAt,
  updatedAt: missionsTable.updatedAt,
};

// ─── GET /missions ─────────────────────────────────────────────────────────────
router.get("/missions", requireAuth, async (req, res) => {
  try {
    const { status, providerId, limit = "50", offset = "0" } = req.query as Record<string, string>;
    const conditions: any[] = [];
    if (status) conditions.push(eq(missionsTable.status, status as any));
    if (providerId) conditions.push(eq(missionsTable.providerId, parseInt(providerId)));

    const missions = await db
      .select(missionWithProvider)
      .from(missionsTable)
      .leftJoin(providersTable, eq(missionsTable.providerId, providersTable.id))
      .where(conditions.length > 0 ? (conditions.length === 1 ? conditions[0] : and(...conditions)) : undefined)
      .orderBy(desc(missionsTable.scheduledAt))
      .limit(parseInt(limit))
      .offset(parseInt(offset));

    const [{ total }] = await db.select({ total: count() }).from(missionsTable);
    res.json({ missions, total: Number(total) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── POST /missions/simulate-price ────────────────────────────────────────────
// Doit être AVANT /:id pour ne pas être capturé comme un id numérique
router.post("/missions/simulate-price", requireAuth, async (_req, res) => {
  try {
    const { surfaceM2, interventionType } = _req.body;
    const surface = Number(surfaceM2);
    if (!isFinite(surface) || surface <= 0) {
      return res.status(400).json({ error: "surfaceM2 invalide (doit être > 0)" });
    }

    // Tarification couverture (prix par m² selon le type de travaux)
    const pricePerM2: Record<string, { min: number; max: number; label: string }> = {
      reparation_fuite:    { min: 50,  max: 150,  label: "Réparation fuite" },
      remplacement_tuiles: { min: 80,  max: 200,  label: "Remplacement de tuiles" },
      renovation_complete: { min: 150, max: 450,  label: "Rénovation complète" },
      nettoyage_toiture:   { min: 15,  max: 40,   label: "Nettoyage / traitement" },
      pose_velux:          { min: 800, max: 2500,  label: "Pose Velux (prix unitaire)" },
      isolation_combles:   { min: 25,  max: 80,   label: "Isolation des combles" },
      autre:               { min: 60,  max: 250,  label: "Autre intervention" },
    };

    const type = interventionType && pricePerM2[interventionType] ? interventionType : "autre";
    const config = pricePerM2[type];

    let priceMin: number;
    let priceMax: number;

    if (type === "pose_velux") {
      // Prix unitaire par Velux, surfaceM2 = nombre de Velux
      const count = Math.max(1, Math.round(surface));
      priceMin = Math.round(count * config.min);
      priceMax = Math.round(count * config.max);
    } else {
      priceMin = Math.round(surface * config.min);
      priceMax = Math.round(surface * config.max);
    }

    res.json({
      priceMin,
      priceMax,
      priceAvg: Math.round((priceMin + priceMax) / 2),
      surfaceM2: surface,
      interventionType: type,
      label: config.label,
      unit: type === "pose_velux" ? "par Velux" : "par m²",
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── POST /missions ─────────────────────────────────────────────────────────────
router.post("/missions", requireAdmin, async (req, res) => {
  try {
    const body = req.body;

    if (
      (body.locationLat !== undefined || body.locationLng !== undefined) &&
      !isValidCoords(body.locationLat, body.locationLng)
    ) {
      return res.status(400).json({ error: "Coordonnées GPS invalides." });
    }

    if (body.roofType === "autre" && !body.roofTypeOther?.trim()) {
      return res.status(400).json({ error: "roofTypeOther est requis quand roofType est 'autre'." });
    }

    const [mission] = await db.insert(missionsTable).values({
      providerId: body.providerId || null,
      clientName: body.clientName,
      clientPhone: body.clientPhone,
      roofType: body.roofType || null,
      roofTypeOther: body.roofTypeOther || null,
      roofSurface: body.roofSurface ? Number(body.roofSurface) : null,
      roofAge: body.roofAge ? Number(body.roofAge) : null,
      interventionType: body.interventionType || "reparation_fuite",
      description: body.description,
      locationAddress: body.locationAddress,
      locationLat: body.locationLat ?? null,
      locationLng: body.locationLng ?? null,
      priority: body.priority || "normal",
      estimatedDuration: body.estimatedDuration || 480,
      scheduledAt: new Date(body.scheduledAt),
      amount: body.amount || null,
      clientPaymentMethod: body.clientPaymentMethod || null,
      photos: body.photos || [],
      notes: body.notes,
      status: "pending",
    }).returning();

    if (body.providerId) {
      await db.insert(notificationsTable).values({
        type: "new_mission",
        title: "Nouveau chantier assigné",
        message: `Chantier de ${body.interventionType || "couverture"} pour ${body.clientName} à ${body.locationAddress}`,
        missionId: mission.id,
        providerId: body.providerId,
        isRead: false,
      });
    }

    res.status(201).json({ ...mission, providerName: null });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── GET /missions/:id ──────────────────────────────────────────────────────────
router.get("/missions/:id", requireAuth, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [mission] = await db
      .select(missionWithProvider)
      .from(missionsTable)
      .leftJoin(providersTable, eq(missionsTable.providerId, providersTable.id))
      .where(eq(missionsTable.id, id));
    if (!mission) return res.status(404).json({ error: "Chantier introuvable" });
    res.json(mission);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── PATCH /missions/:id ─────────────────────────────────────────────────────────
router.patch("/missions/:id", requireAuth, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const body = req.body;

    const [current] = await db.select({ status: missionsTable.status, providerId: missionsTable.providerId, amount: missionsTable.amount })
      .from(missionsTable).where(eq(missionsTable.id, id)).limit(1);
    if (!current) return res.status(404).json({ error: "Chantier introuvable" });

    if (body.status !== undefined && body.status !== current.status) {
      if (!isValidTransition(current.status, body.status)) {
        return res.status(422).json({
          error: `Transition de statut invalide : '${current.status}' → '${body.status}'.`,
        });
      }
    }

    const updates: any = { updatedAt: new Date() };
    const fields = ["status","notes","amount","estimatedDuration","providerId","clientName","clientPhone",
      "roofType","roofTypeOther","roofSurface","roofAge","interventionType","description",
      "locationAddress","priority","scheduledAt","clientPaymentMethod","locationLat","locationLng"];
    for (const f of fields) {
      if (body[f] !== undefined) updates[f] = body[f] ?? null;
    }

    if (updates.scheduledAt) updates.scheduledAt = new Date(updates.scheduledAt);

    await db.update(missionsTable).set(updates).where(eq(missionsTable.id, id));

    const [mission] = await db
      .select(missionWithProvider)
      .from(missionsTable)
      .leftJoin(providersTable, eq(missionsTable.providerId, providersTable.id))
      .where(eq(missionsTable.id, id));

    if (!mission) return res.status(404).json({ error: "Chantier introuvable" });

    const effectiveStatus = updates.status ?? mission.status;
    const effectiveAmount = updates.amount ?? mission.amount;
    if (effectiveStatus === "completed" && effectiveAmount && Number(effectiveAmount) > 0) {
      await upsertMissionPayment(id, Number(effectiveAmount), updates.clientPaymentMethod ?? (mission as any).clientPaymentMethod);
    }

    if (mission.providerId) {
      await db.insert(notificationsTable).values({
        type: "mission_update",
        title: "Chantier mis à jour",
        message: `Le chantier #${id} a été mis à jour`,
        missionId: id,
        providerId: mission.providerId,
        isRead: false,
      });
    }

    res.json(mission);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── PUT /missions/:id/provider-location ──────────────────────────────────────
router.put("/missions/:id/provider-location", requireProvider, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { lat, lng, isTracking } = req.body;
    if (lat !== undefined && lng !== undefined && !isValidCoords(lat, lng)) {
      return res.status(400).json({ error: "Coordonnées GPS invalides." });
    }
    await db.update(missionsTable)
      .set({ providerLat: lat ?? null, providerLng: lng ?? null, isTracking: isTracking ?? false, updatedAt: new Date() })
      .where(eq(missionsTable.id, id));
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── GET /missions/:id/provider-location ─────────────────────────────────────
// Publique : partagée avec le client via lien direct
router.get("/missions/:id/provider-location", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [mission] = await db
      .select({
        id: missionsTable.id,
        providerLat: missionsTable.providerLat,
        providerLng: missionsTable.providerLng,
        isTracking: missionsTable.isTracking,
        locationAddress: missionsTable.locationAddress,
        clientName: missionsTable.clientName,
        providerName: providersTable.name,
        status: missionsTable.status,
        interventionType: missionsTable.interventionType,
        roofType: missionsTable.roofType,
      })
      .from(missionsTable)
      .leftJoin(providersTable, eq(missionsTable.providerId, providersTable.id))
      .where(eq(missionsTable.id, id));
    if (!mission) return res.status(404).json({ error: "Chantier introuvable" });
    res.json(mission);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── POST /missions/:id/confirm ───────────────────────────────────────────────
router.post("/missions/:id/confirm", requireAuth, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [current] = await db.select({ status: missionsTable.status }).from(missionsTable).where(eq(missionsTable.id, id)).limit(1);
    if (!current) return res.status(404).json({ error: "Chantier introuvable" });
    if (!isValidTransition(current.status, "confirmed")) {
      return res.status(422).json({ error: `Impossible de confirmer un chantier en statut '${current.status}'.` });
    }
    await db.update(missionsTable).set({ status: "confirmed", updatedAt: new Date() }).where(eq(missionsTable.id, id));

    const [mission] = await db.select(missionWithProvider).from(missionsTable)
      .leftJoin(providersTable, eq(missionsTable.providerId, providersTable.id))
      .where(eq(missionsTable.id, id));
    if (!mission) return res.status(404).json({ error: "Chantier introuvable" });

    if (mission.providerId) {
      await db.insert(notificationsTable).values({
        type: "mission_update",
        title: "Chantier confirmé",
        message: `Le chantier #${id} a été confirmé`,
        missionId: id,
        providerId: mission.providerId,
        isRead: false,
      });
      const scheduledAt = mission.scheduledAt ? new Date(mission.scheduledAt).toLocaleString("fr-FR") : "";
      sendPushToProvider(mission.providerId, {
        title: "Chantier confirmé",
        body: `Chantier #${id} confirmé${scheduledAt ? ` — prévu le ${scheduledAt}` : ""} à ${mission.locationAddress || ""}`,
        url: `/missions?id=${id}`,
      });
    }
    res.json(mission);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── POST /missions/:id/complete ──────────────────────────────────────────────
router.post("/missions/:id/complete", requireProvider, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { notes, amount, clientPaymentMethod } = req.body;
    const [current] = await db.select({ status: missionsTable.status }).from(missionsTable).where(eq(missionsTable.id, id)).limit(1);
    if (!current) return res.status(404).json({ error: "Chantier introuvable" });
    if (!isValidTransition(current.status, "completed")) {
      return res.status(422).json({ error: `Impossible de terminer un chantier en statut '${current.status}'.` });
    }

    const updates: any = { status: "completed", completedAt: new Date(), updatedAt: new Date(), notes: notes || null, amount: amount || null };
    if (clientPaymentMethod) updates.clientPaymentMethod = clientPaymentMethod;
    await db.update(missionsTable).set(updates).where(eq(missionsTable.id, id));

    if (amount && Number(amount) > 0) {
      await upsertMissionPayment(id, Number(amount), clientPaymentMethod || undefined);
    }

    const [mission] = await db.select(missionWithProvider).from(missionsTable)
      .leftJoin(providersTable, eq(missionsTable.providerId, providersTable.id))
      .where(eq(missionsTable.id, id));
    if (!mission) return res.status(404).json({ error: "Chantier introuvable" });

    if (mission.providerId) {
      await db.insert(notificationsTable).values({
        type: "mission_update",
        title: "Chantier terminé",
        message: `Le chantier #${id} a été clôturé${amount ? ` — Montant: ${amount}€` : ""}`,
        missionId: id,
        providerId: mission.providerId,
        isRead: false,
      });
      sendPushToProvider(mission.providerId, {
        title: "Chantier terminé",
        body: `Chantier #${id} clôturé${amount ? ` — ${amount}€` : ""}`,
        url: `/missions?id=${id}`,
      });
    }
    res.json(mission);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── POST /missions/:id/refuse ────────────────────────────────────────────────
router.post("/missions/:id/refuse", requireProvider, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: "ID invalide" });
    const { providerId, reason } = req.body;
    if (!providerId || isNaN(Number(providerId))) return res.status(400).json({ error: "providerId requis" });

    const [mission] = await db.select().from(missionsTable).where(eq(missionsTable.id, id)).limit(1);
    if (!mission) return res.status(404).json({ error: "Chantier introuvable" });
    if (!["pending", "confirmed", "in_progress"].includes(mission.status)) {
      return res.status(400).json({ error: "Ce chantier ne peut plus être refusé" });
    }
    if (mission.providerId !== Number(providerId)) {
      return res.status(403).json({ error: "Ce couvreur n'est pas assigné à ce chantier" });
    }

    const existingRefusals = await db.select().from(missionRefusalsTable)
      .where(and(eq(missionRefusalsTable.missionId, id), eq(missionRefusalsTable.providerId, Number(providerId))));
    if (existingRefusals.length >= 3) {
      return res.status(409).json({ error: "Ce couvreur a déjà refusé ce chantier 3 fois" });
    }

    await db.insert(missionRefusalsTable).values({ missionId: id, providerId: Number(providerId), reason: reason || null });
    await db.update(providersTable).set({ refusalCount: sql`${providersTable.refusalCount} + 1` }).where(eq(providersTable.id, Number(providerId)));
    await db.update(missionsTable).set({ providerId: null, status: "pending", updatedAt: new Date() }).where(eq(missionsTable.id, id));
    await db.insert(notificationsTable).values({
      type: "mission_update",
      title: "Chantier refusé",
      message: `Le chantier #${id} a été refusé${reason ? ` — ${reason}` : ""}`,
      missionId: id,
      providerId: null,
      isRead: false,
    });
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── GET /missions/:id/refusals ───────────────────────────────────────────────
router.get("/missions/:id/refusals", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const refusals = await db
      .select({ id: missionRefusalsTable.id, providerId: missionRefusalsTable.providerId, providerName: providersTable.name, reason: missionRefusalsTable.reason, createdAt: missionRefusalsTable.createdAt })
      .from(missionRefusalsTable)
      .leftJoin(providersTable, eq(missionRefusalsTable.providerId, providersTable.id))
      .where(eq(missionRefusalsTable.missionId, id))
      .orderBy(desc(missionRefusalsTable.createdAt));
    res.json(refusals);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── POST /missions/:id/assign ────────────────────────────────────────────────
router.post("/missions/:id/assign", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { providerId } = req.body;
    await db.update(missionsTable).set({ providerId, updatedAt: new Date() }).where(eq(missionsTable.id, id));

    const [mission] = await db.select(missionWithProvider).from(missionsTable)
      .leftJoin(providersTable, eq(missionsTable.providerId, providersTable.id))
      .where(eq(missionsTable.id, id));
    if (!mission) return res.status(404).json({ error: "Chantier introuvable" });

    if (mission.providerId) {
      await db.insert(notificationsTable).values({
        type: "mission_update",
        title: "Chantier affecté",
        message: `Le chantier #${id} a été affecté à ${mission.providerName || "un couvreur"}`,
        missionId: id,
        providerId: mission.providerId,
        isRead: false,
      });
      const scheduledAt = mission.scheduledAt ? new Date(mission.scheduledAt).toLocaleString("fr-FR") : "";
      sendPushToProvider(mission.providerId, {
        title: "Nouveau chantier assigné",
        body: `Chantier #${id} - ${mission.interventionType || "Couverture"} pour ${mission.clientName || "un client"} à ${mission.locationAddress || ""}${scheduledAt ? ` le ${scheduledAt}` : ""}`,
        url: `/missions?id=${id}`,
      });
    }
    res.json(mission);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── GET /missions/:id/attachments ───────────────────────────────────────────
router.get("/missions/:id/attachments", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "ID invalide" });
  try {
    const attachments = await db.select().from(missionAttachmentsTable)
      .where(eq(missionAttachmentsTable.missionId, id))
      .orderBy(desc(missionAttachmentsTable.createdAt));
    res.json(attachments);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── POST /missions/:id/attachments ─────────────────────────────────────────
router.post("/missions/:id/attachments", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "ID invalide" });
  const { objectPath, originalName, mimeType, fileSize } = req.body;
  if (!objectPath || !originalName || !mimeType || !fileSize) return res.status(400).json({ error: "Champs manquants" });
  try {
    const [attachment] = await db.insert(missionAttachmentsTable).values({ missionId: id, objectPath, originalName, mimeType, fileSize }).returning();
    res.status(201).json(attachment);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── DELETE /missions/:id ─────────────────────────────────────────────────────
router.delete("/missions/:id", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: "ID invalide." });
    const { code } = req.body;
    const [setting] = await db.select().from(settingsTable).where(eq(settingsTable.key, "deletionCode"));
    if (!setting?.value) return res.status(500).json({ error: "Code de suppression non configuré. Définissez-le dans les paramètres." });
    if (!code || code !== setting.value) return res.status(403).json({ error: "Code de suppression incorrect." });
    await db.delete(missionsTable).where(eq(missionsTable.id, id));
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── DELETE /missions/:missionId/attachments/:attachmentId ──────────────────
router.delete("/missions/:missionId/attachments/:attachmentId", requireAuth, async (req, res) => {
  const missionId = parseInt(req.params.missionId);
  const attachmentId = parseInt(req.params.attachmentId);
  if (isNaN(missionId) || isNaN(attachmentId)) return res.status(400).json({ error: "ID invalide" });
  try {
    await db.delete(missionAttachmentsTable)
      .where(and(eq(missionAttachmentsTable.id, attachmentId), eq(missionAttachmentsTable.missionId, missionId)));
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
