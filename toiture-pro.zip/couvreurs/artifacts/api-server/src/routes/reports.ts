import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { missionsTable, paymentsTable, providersTable } from "@workspace/db/schema";
import { eq, and, gte, lte, desc, count, sql } from "drizzle-orm";
import { requireAdmin, requireAuth } from "../middleware/auth";

const router: IRouter = Router();

function formatCSVField(val: any): string {
  if (val === null || val === undefined) return "";
  const str = String(val);
  if (str.includes(",") || str.includes('"') || str.includes("\n")) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

function buildCSV(headers: string[], rows: any[][]): string {
  const bom = "\uFEFF";
  const headerLine = headers.map(formatCSVField).join(";");
  const dataLines = rows.map(row => row.map(formatCSVField).join(";"));
  return bom + [headerLine, ...dataLines].join("\n");
}

// ─── GET /reports/admin/monthly ───────────────────────────────────────────────
router.get("/reports/admin/monthly", requireAdmin, async (req, res) => {
  try {
    const { year, month } = req.query as { year?: string; month?: string };
    const now = new Date();
    const y = year ? parseInt(year) : now.getFullYear();
    const m = month ? parseInt(month) - 1 : now.getMonth();
    const startDate = new Date(y, m, 1);
    const endDate = new Date(y, m + 1, 0, 23, 59, 59);

    const monthLabel = `${String(m + 1).padStart(2, "0")}/${y}`;

    const providers = await db.select().from(providersTable).orderBy(providersTable.name);

    // Paiements du mois
    const allPayments = await db
      .select({
        id: paymentsTable.id,
        missionId: paymentsTable.missionId,
        amount: paymentsTable.amount,
        commissionAmount: paymentsTable.commissionAmount,
        commissionStatus: paymentsTable.commissionStatus,
        status: paymentsTable.status,
        method: paymentsTable.method,
        createdAt: paymentsTable.createdAt,
        providerId: missionsTable.providerId,
      })
      .from(paymentsTable)
      .innerJoin(missionsTable, eq(paymentsTable.missionId, missionsTable.id))
      .where(
        and(
          gte(paymentsTable.createdAt, startDate),
          lte(paymentsTable.createdAt, endDate)
        )
      )
      .orderBy(desc(paymentsTable.createdAt));

    // FIX : nombre de missions COMPLÉTÉES du mois, par prestataire
    // (et non le nombre de paiements, qui peut différer)
    const completedMissionsByProvider = await db
      .select({
        providerId: missionsTable.providerId,
        completedCount: count(missionsTable.id),
      })
      .from(missionsTable)
      .where(
        and(
          gte(missionsTable.completedAt, startDate),
          lte(missionsTable.completedAt, endDate),
          sql`${missionsTable.status} = 'completed'`,
          sql`${missionsTable.providerId} IS NOT NULL`
        )
      )
      .groupBy(missionsTable.providerId);

    const completedMap = new Map(
      completedMissionsByProvider.map(r => [r.providerId, Number(r.completedCount)])
    );

    const headers = [
      "Prestataire",
      "SIRET",
      "N\u00b0 TVA",
      "Zone",
      "Missions Compl\u00e9t\u00e9es",
      "Chiffre d'Affaires (\u20ac)",
      "Commission 20% (\u20ac)",
      "Commission Pay\u00e9e (\u20ac)",
      "Commission En Attente (\u20ac)",
      "Mois",
    ];

    const rows = providers.map(provider => {
      const provPayments = allPayments.filter(p => p.providerId === provider.id);
      const totalRevenue = provPayments.reduce((s, p) => s + (p.amount || 0), 0);
      const totalCommission = provPayments.reduce((s, p) => s + (p.commissionAmount || 0), 0);
      const paidCommission = provPayments
        .filter(p => p.commissionStatus === "paid")
        .reduce((s, p) => s + (p.commissionAmount || 0), 0);
      const pendingCommission = totalCommission - paidCommission;
      // FIX : utiliser le vrai compteur de missions complétées
      const completedMissions = completedMap.get(provider.id) ?? 0;

      return [
        provider.name,
        provider.siret || "",
        provider.tvaNumber || "",
        provider.zone || "",
        completedMissions,
        totalRevenue.toFixed(2),
        totalCommission.toFixed(2),
        paidCommission.toFixed(2),
        pendingCommission.toFixed(2),
        monthLabel,
      ];
    });

    const totalCompletedAll = completedMissionsByProvider.reduce((s, r) => s + Number(r.completedCount), 0);
    const totalRow = [
      "TOTAL",
      "",
      "",
      "",
      totalCompletedAll,
      allPayments.reduce((s, p) => s + (p.amount || 0), 0).toFixed(2),
      allPayments.reduce((s, p) => s + (p.commissionAmount || 0), 0).toFixed(2),
      allPayments.filter(p => p.commissionStatus === "paid").reduce((s, p) => s + (p.commissionAmount || 0), 0).toFixed(2),
      (
        allPayments.reduce((s, p) => s + (p.commissionAmount || 0), 0) -
        allPayments.filter(p => p.commissionStatus === "paid").reduce((s, p) => s + (p.commissionAmount || 0), 0)
      ).toFixed(2),
      monthLabel,
    ];
    rows.push(totalRow);

    const csv = buildCSV(headers, rows);
    const filename = `rapport-mensuel-admin-${monthLabel.replace("/", "-")}.csv`;

    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.send(csv);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── GET /reports/provider/:id/monthly ────────────────────────────────────────
router.get("/reports/provider/:id/monthly", requireAuth, async (req, res) => {
  try {
    const providerId = parseInt(req.params.id);
    if (isNaN(providerId)) return res.status(400).json({ error: "ID invalide" });

    const { year, month } = req.query as { year?: string; month?: string };
    const now = new Date();
    const y = year ? parseInt(year) : now.getFullYear();
    const m = month ? parseInt(month) - 1 : now.getMonth();
    const startDate = new Date(y, m, 1);
    const endDate = new Date(y, m + 1, 0, 23, 59, 59);

    const monthLabel = `${String(m + 1).padStart(2, "0")}/${y}`;

    const [provider] = await db.select().from(providersTable).where(eq(providersTable.id, providerId)).limit(1);
    if (!provider) return res.status(404).json({ error: "Prestataire introuvable" });

    const payments = await db
      .select({
        id: paymentsTable.id,
        missionId: paymentsTable.missionId,
        amount: paymentsTable.amount,
        commissionAmount: paymentsTable.commissionAmount,
        commissionStatus: paymentsTable.commissionStatus,
        status: paymentsTable.status,
        method: paymentsTable.method,
        createdAt: paymentsTable.createdAt,
        clientName: missionsTable.clientName,
        vehicleMake: missionsTable.vehicleMake,
        vehicleModel: missionsTable.vehicleModel,
        interventionType: missionsTable.interventionType,
        locationAddress: missionsTable.locationAddress,
      })
      .from(paymentsTable)
      .innerJoin(missionsTable, eq(paymentsTable.missionId, missionsTable.id))
      .where(
        and(
          eq(missionsTable.providerId, providerId),
          gte(paymentsTable.createdAt, startDate),
          lte(paymentsTable.createdAt, endDate)
        )
      )
      .orderBy(desc(paymentsTable.createdAt));

    const headers = [
      "Date",
      "Mission #",
      "Client",
      "V\u00e9hicule",
      "Type",
      "Adresse",
      "Montant (\u20ac)",
      "Commission 20% (\u20ac)",
      "Net (\u20ac)",
      "M\u00e9thode",
      "Statut Commission",
    ];

    const rows = payments.map(p => {
      const net = (p.amount || 0) - (p.commissionAmount || 0);
      return [
        p.createdAt ? new Date(p.createdAt).toLocaleDateString("fr-FR") : "",
        `#${p.missionId}`,
        p.clientName || "",
        `${p.vehicleMake || ""} ${p.vehicleModel || ""}`.trim(),
        p.interventionType || "",
        p.locationAddress || "",
        (p.amount || 0).toFixed(2),
        (p.commissionAmount || 0).toFixed(2),
        net.toFixed(2),
        p.method || "",
        p.commissionStatus === "paid" ? "R\u00e9gl\u00e9e" : "En attente",
      ];
    });

    const totalRevenue = payments.reduce((s, p) => s + (p.amount || 0), 0);
    const totalCommission = payments.reduce((s, p) => s + (p.commissionAmount || 0), 0);
    const totalNet = totalRevenue - totalCommission;

    rows.push([
      "TOTAL", "", "", "", "", "",
      totalRevenue.toFixed(2),
      totalCommission.toFixed(2),
      totalNet.toFixed(2),
      "", "",
    ]);

    const csv = buildCSV(headers, rows);
    const filename = `rapport-${provider.name.replace(/\s+/g, "_")}-${monthLabel.replace("/", "-")}.csv`;

    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.send(csv);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
