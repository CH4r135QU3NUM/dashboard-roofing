import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { notificationsTable } from "@workspace/db/schema";
import { eq, desc, count, sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/notifications", async (req, res) => {
  try {
    const { providerId } = req.query as { providerId?: string };
    const conditions: any[] = [];
    if (providerId) {
      const pid = parseInt(providerId);
      conditions.push(
        sql`(${notificationsTable.providerId} = ${pid} OR ${notificationsTable.providerId} IS NULL)`
      );
    }
    const notifications = await db
      .select()
      .from(notificationsTable)
      .where(conditions.length > 0 ? conditions[0] : undefined)
      .orderBy(desc(notificationsTable.createdAt))
      .limit(50);

    const unreadCount = notifications.filter(n => !n.isRead).length;
    res.json({ notifications, unreadCount });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/notifications/:id/read", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [notification] = await db
      .update(notificationsTable)
      .set({ isRead: true })
      .where(eq(notificationsTable.id, id))
      .returning();
    if (!notification) return res.status(404).json({ error: "Notification not found" });
    res.json(notification);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/notifications/read-all", async (req, res) => {
  try {
    const { providerId } = req.body as { providerId?: number };
    if (providerId) {
      await db.update(notificationsTable).set({ isRead: true }).where(
        sql`(${notificationsTable.providerId} = ${providerId} OR ${notificationsTable.providerId} IS NULL)`
      );
    } else {
      await db.update(notificationsTable).set({ isRead: true });
    }
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
