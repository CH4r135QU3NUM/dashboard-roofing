import { Router, type IRouter } from "express";
import healthRouter from "./health";
import missionsRouter from "./missions";
import paymentsRouter from "./payments";
import availabilityRouter from "./availability";
import statsRouter from "./stats";
import notificationsRouter from "./notifications";
import providersRouter from "./providers";
import clientsRouter from "./clients";
import vehiclesRouter from "./vehicles";
import adminRouter from "./admin";
import storageRouter from "./storage";
import authRouter from "./auth";
import settingsRouter from "./settings";
import companiesRouter from "./companies";
import pushRouter from "./push";
import reportsRouter from "./reports";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/auth", authRouter);
router.use(missionsRouter);
router.use(paymentsRouter);
router.use(availabilityRouter);
router.use(statsRouter);
router.use(notificationsRouter);
router.use(providersRouter);
router.use(clientsRouter);
router.use(vehiclesRouter);
router.use(adminRouter);
router.use(storageRouter);
router.use(settingsRouter);
router.use(companiesRouter);
router.use(pushRouter);
router.use(reportsRouter);

export default router;
