import { Router, type IRouter } from "express";

function computeTvaNumber(siren: string): string {
  const sirenNum = parseInt(siren, 10);
  if (isNaN(sirenNum)) return "";
  const key = (12 + 3 * (sirenNum % 97)) % 97;
  return `FR${key.toString().padStart(2, "0")}${siren}`;
}

const router: IRouter = Router();

router.get("/companies/search", async (req, res) => {
  try {
    const { q } = req.query as { q?: string };
    if (!q || q.trim().length < 2) {
      return res.json({ results: [] });
    }

    const query = encodeURIComponent(q.trim());
    const url = `https://recherche-entreprises.api.gouv.fr/search?q=${query}&page=1&per_page=10`;

    const response = await fetch(url, {
      headers: { "Accept": "application/json" },
      signal: AbortSignal.timeout(5000),
    });

    if (!response.ok) {
      return res.json({ results: [] });
    }

    const data = await response.json();
    const results = (data.results || []).map((r: any) => {
      const siege = r.siege || {};
      const addressParts = [
        siege.numero_voie,
        siege.type_voie,
        siege.libelle_voie,
        siege.code_postal,
        siege.libelle_commune,
      ].filter(Boolean);

      return {
        siren: r.siren || "",
        siret: siege.siret || "",
        companyName: r.nom_complet || r.nom_raison_sociale || "",
        address: addressParts.join(" "),
        tvaNumber: r.siren ? computeTvaNumber(r.siren) : "",
        natureJuridique: r.nature_juridique || "",
        activitePrincipale: r.activite_principale || "",
        trancheEffectifs: r.tranche_effectif_salarie || "",
      };
    });

    res.json({ results });
  } catch (err) {
    console.error("Company search error:", err);
    res.json({ results: [] });
  }
});

export default router;
