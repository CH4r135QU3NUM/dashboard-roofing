import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { vehiclesTable, clientsTable } from "@workspace/db/schema";
import { eq, desc, sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/vehicles/by-plate/:plate", async (req, res) => {
  try {
    const plate = req.params.plate.toUpperCase().replace(/[\s\-]/g, "");
    const [vehicle] = await db
      .select({
        id: vehiclesTable.id,
        make: vehiclesTable.make,
        model: vehiclesTable.model,
        year: vehiclesTable.year,
        plate: vehiclesTable.plate,
        color: vehiclesTable.color,
        clientName: sql<string | null>`concat(${clientsTable.firstName}, ' ', ${clientsTable.lastName})`,
        clientPhone: clientsTable.phone,
      })
      .from(vehiclesTable)
      .leftJoin(clientsTable, eq(vehiclesTable.clientId, clientsTable.id))
      .where(sql`upper(replace(replace(${vehiclesTable.plate}, ' ', ''), '-', '')) = ${plate}`);

    if (!vehicle) return res.status(404).json({ error: "Bien introuvable" });
    res.json(vehicle);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/vehicles", async (req, res) => {
  try {
    const { clientId } = req.query as Record<string, string>;

    let query = db
      .select({
        id: vehiclesTable.id,
        clientId: vehiclesTable.clientId,
        clientName: sql<string | null>`concat(${clientsTable.firstName}, ' ', ${clientsTable.lastName})`,
        make: vehiclesTable.make,
        model: vehiclesTable.model,
        year: vehiclesTable.year,
        plate: vehiclesTable.plate,
        color: vehiclesTable.color,
        vin: vehiclesTable.vin,
        createdAt: vehiclesTable.createdAt,
        updatedAt: vehiclesTable.updatedAt,
      })
      .from(vehiclesTable)
      .leftJoin(clientsTable, eq(vehiclesTable.clientId, clientsTable.id))
      .$dynamic();

    if (clientId) {
      query = query.where(eq(vehiclesTable.clientId, parseInt(clientId)));
    }

    const vehicles = await query.orderBy(desc(vehiclesTable.createdAt));

    const result = vehicles.map((v) => ({
      ...v,
      totalMissions: 0,
    }));

    res.json({ vehicles: result, total: result.length });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/vehicles", async (req, res) => {
  try {
    const body = req.body;
    const [vehicle] = await db
      .insert(vehiclesTable)
      .values({
        clientId: body.clientId || null,
        make: body.make,
        model: body.model,
        year: body.year || null,
        plate: body.plate,
        color: body.color || null,
        vin: body.vin || null,
      })
      .returning();

    let clientName: string | null = null;
    if (vehicle.clientId) {
      const [client] = await db.select().from(clientsTable).where(eq(clientsTable.id, vehicle.clientId));
      if (client) clientName = `${client.firstName} ${client.lastName}`;
    }

    res.status(201).json({ ...vehicle, clientName, totalMissions: 0 });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/vehicles/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const body = req.body;
    const updates: any = { updatedAt: new Date() };
    if (body.clientId !== undefined) updates.clientId = body.clientId;
    if (body.make !== undefined) updates.make = body.make;
    if (body.model !== undefined) updates.model = body.model;
    if (body.year !== undefined) updates.year = body.year;
    if (body.plate !== undefined) updates.plate = body.plate;
    if (body.color !== undefined) updates.color = body.color;
    if (body.vin !== undefined) updates.vin = body.vin;

    const [vehicle] = await db
      .update(vehiclesTable)
      .set(updates)
      .where(eq(vehiclesTable.id, id))
      .returning();

    if (!vehicle) return res.status(404).json({ error: "Bien introuvable" });

    let clientName: string | null = null;
    if (vehicle.clientId) {
      const [client] = await db.select().from(clientsTable).where(eq(clientsTable.id, vehicle.clientId));
      if (client) clientName = `${client.firstName} ${client.lastName}`;
    }

    res.json({ ...vehicle, clientName, totalMissions: 0 });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/vehicles/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.delete(vehiclesTable).where(eq(vehiclesTable.id, id));
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
