import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { clientsTable, missionsTable } from "@workspace/db/schema";
import { eq, desc, count, sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/clients", async (req, res) => {
  try {
    const clients = await db.select().from(clientsTable).orderBy(desc(clientsTable.createdAt));

    const missionCounts = await db
      .select({
        clientName: sql<string>`concat(${clientsTable.firstName}, ' ', ${clientsTable.lastName})`,
        totalMissions: count(missionsTable.id),
      })
      .from(missionsTable)
      .leftJoin(clientsTable, sql`lower(${missionsTable.clientName}) = lower(concat(${clientsTable.firstName}, ' ', ${clientsTable.lastName}))`)
      .groupBy(clientsTable.id, clientsTable.firstName, clientsTable.lastName);

    const result = clients.map((c) => ({
      ...c,
      totalMissions: 0,
    }));

    res.json({ clients: result, total: result.length });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/clients", async (req, res) => {
  try {
    const body = req.body;
    const [client] = await db
      .insert(clientsTable)
      .values({
        firstName: body.firstName,
        lastName: body.lastName,
        email: body.email || null,
        phone: body.phone,
        address: body.address || null,
      })
      .returning();
    res.status(201).json({ ...client, totalMissions: 0 });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/clients/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [client] = await db.select().from(clientsTable).where(eq(clientsTable.id, id));
    if (!client) return res.status(404).json({ error: "Client not found" });
    res.json({ ...client, totalMissions: 0 });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/clients/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const body = req.body;
    const updates: any = { updatedAt: new Date() };
    if (body.firstName !== undefined) updates.firstName = body.firstName;
    if (body.lastName !== undefined) updates.lastName = body.lastName;
    if (body.email !== undefined) updates.email = body.email;
    if (body.phone !== undefined) updates.phone = body.phone;
    if (body.address !== undefined) updates.address = body.address;

    const [client] = await db
      .update(clientsTable)
      .set(updates)
      .where(eq(clientsTable.id, id))
      .returning();

    if (!client) return res.status(404).json({ error: "Client not found" });
    res.json({ ...client, totalMissions: 0 });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/clients/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.delete(clientsTable).where(eq(clientsTable.id, id));
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
