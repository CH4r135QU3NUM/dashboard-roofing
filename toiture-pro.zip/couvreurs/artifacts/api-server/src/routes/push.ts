import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { pushSubscriptionsTable } from "@workspace/db/schema";
import { eq, and } from "drizzle-orm";
import webpush from "web-push";

const VAPID_PUBLIC = process.env.VAPID_PUBLIC_KEY || "";
const VAPID_PRIVATE = process.env.VAPID_PRIVATE_KEY || "";

if (VAPID_PUBLIC && VAPID_PRIVATE) {
  webpush.setVapidDetails("mailto:admin@toiture-pro.fr", VAPID_PUBLIC, VAPID_PRIVATE);
}

const router: IRouter = Router();

router.get("/push/vapid-key", (_req, res) => {
  res.json({ publicKey: VAPID_PUBLIC });
});

router.post("/push/subscribe", async (req, res) => {
  try {
    const { providerId, subscription } = req.body;
    if (!providerId || !subscription?.endpoint || !subscription?.keys) {
      return res.status(400).json({ error: "Données manquantes" });
    }

    const existing = await db.select().from(pushSubscriptionsTable)
      .where(and(
        eq(pushSubscriptionsTable.providerId, Number(providerId)),
        eq(pushSubscriptionsTable.endpoint, subscription.endpoint)
      )).limit(1);

    if (existing.length === 0) {
      await db.insert(pushSubscriptionsTable).values({
        providerId: Number(providerId),
        endpoint: subscription.endpoint,
        keys: subscription.keys,
      });
    }

    res.json({ success: true });
  } catch (err) {
    console.error("Push subscribe error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/push/unsubscribe", async (req, res) => {
  try {
    const { providerId, endpoint } = req.body;
    if (!providerId || !endpoint) return res.status(400).json({ error: "Données manquantes" });

    await db.delete(pushSubscriptionsTable)
      .where(and(
        eq(pushSubscriptionsTable.providerId, Number(providerId)),
        eq(pushSubscriptionsTable.endpoint, endpoint)
      ));

    res.json({ success: true });
  } catch (err) {
    console.error("Push unsubscribe error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export async function sendPushToProvider(providerId: number, payload: { title: string; body: string; url?: string }) {
  if (!VAPID_PUBLIC || !VAPID_PRIVATE) return;

  try {
    const subscriptions = await db.select().from(pushSubscriptionsTable)
      .where(eq(pushSubscriptionsTable.providerId, providerId));

    const message = JSON.stringify(payload);

    for (const sub of subscriptions) {
      try {
        await webpush.sendNotification(
          { endpoint: sub.endpoint, keys: sub.keys as any },
          message
        );
      } catch (err: any) {
        if (err.statusCode === 410 || err.statusCode === 404) {
          await db.delete(pushSubscriptionsTable).where(eq(pushSubscriptionsTable.id, sub.id));
        }
      }
    }
  } catch (err) {
    console.error("sendPushToProvider error:", err);
  }
}

export default router;
