import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { paymentsTable, notificationsTable, missionsTable, providersTable } from "@workspace/db/schema";
import { eq, desc, sum, count, and, sql, isNotNull } from "drizzle-orm";
import { requireAuth, requireAdmin } from "../middleware/auth";

const router: IRouter = Router();

// ─── GET /payments ────────────────────────────────────────────────────────────
// Ajout de la pagination (limit / offset) pour éviter de tout charger d'un coup.
router.get("/payments", requireAuth, async (req, res) => {
  try {
    const {
      providerId,
      limit = "50",
      offset = "0",
    } = req.query as { providerId?: string; limit?: string; offset?: string };

    const lim = Math.min(parseInt(limit) || 50, 200); // Plafond à 200
    const off = parseInt(offset) || 0;

    if (providerId) {
      const pid = parseInt(providerId);
      const payments = await db
        .select({
          id: paymentsTable.id,
          missionId: paymentsTable.missionId,
          amount: paymentsTable.amount,
          currency: paymentsTable.currency,
          status: paymentsTable.status,
          method: paymentsTable.method,
          reference: paymentsTable.reference,
          description: paymentsTable.description,
          commissionAmount: paymentsTable.commissionAmount,
          commissionStatus: paymentsTable.commissionStatus,
          commissionProof: paymentsTable.commissionProof,
          paidAt: paymentsTable.paidAt,
          createdAt: paymentsTable.createdAt,
          clientName: missionsTable.clientName,
          vehicleMake: missionsTable.vehicleMake,
          vehicleModel: missionsTable.vehicleModel,
          vehiclePlate: missionsTable.vehiclePlate,
          interventionType: missionsTable.interventionType,
          locationAddress: missionsTable.locationAddress,
          clientPaymentMethod: missionsTable.clientPaymentMethod,
        })
        .from(paymentsTable)
        .innerJoin(missionsTable, eq(paymentsTable.missionId, missionsTable.id))
        .where(eq(missionsTable.providerId, pid))
        .orderBy(desc(paymentsTable.createdAt))
        .limit(lim)
        .offset(off);

      const [{ total }] = await db
        .select({ total: count() })
        .from(paymentsTable)
        .innerJoin(missionsTable, eq(paymentsTable.missionId, missionsTable.id))
        .where(eq(missionsTable.providerId, pid));

      res.json({ payments, total: Number(total) });
    } else {
      const payments = await db
        .select({
          id: paymentsTable.id,
          missionId: paymentsTable.missionId,
          amount: paymentsTable.amount,
          currency: paymentsTable.currency,
          status: paymentsTable.status,
          method: paymentsTable.method,
          reference: paymentsTable.reference,
          description: paymentsTable.description,
          commissionAmount: paymentsTable.commissionAmount,
          commissionStatus: paymentsTable.commissionStatus,
          commissionProof: paymentsTable.commissionProof,
          paidAt: paymentsTable.paidAt,
          createdAt: paymentsTable.createdAt,
          providerName: providersTable.name,
          providerId: missionsTable.providerId,
        })
        .from(paymentsTable)
        .innerJoin(missionsTable, eq(paymentsTable.missionId, missionsTable.id))
        .leftJoin(providersTable, eq(missionsTable.providerId, providersTable.id))
        .orderBy(desc(paymentsTable.createdAt))
        .limit(lim)
        .offset(off);

      const [{ total }] = await db.select({ total: count() }).from(paymentsTable);
      res.json({ payments, total: Number(total) });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── GET /payments/summary ────────────────────────────────────────────────────
// Doit être déclarée AVANT /payments/:id pour éviter le conflit de route.
router.get("/payments/summary", requireAuth, async (req, res) => {
  try {
    const { providerId } = req.query as { providerId?: string };
    let all;
    if (providerId) {
      const pid = parseInt(providerId);
      all = await db.select({
        id: paymentsTable.id,
        amount: paymentsTable.amount,
        status: paymentsTable.status,
        missionId: paymentsTable.missionId,
        commissionAmount: paymentsTable.commissionAmount,
      })
        .from(paymentsTable)
        .innerJoin(missionsTable, eq(paymentsTable.missionId, missionsTable.id))
        .where(eq(missionsTable.providerId, pid));
    } else {
      all = await db.select({
        id: paymentsTable.id,
        amount: paymentsTable.amount,
        status: paymentsTable.status,
        missionId: paymentsTable.missionId,
        commissionAmount: paymentsTable.commissionAmount,
      }).from(paymentsTable)
        .innerJoin(missionsTable, eq(paymentsTable.missionId, missionsTable.id));
    }
    const totalRevenue = all.reduce((s, p) => s + (p.amount || 0), 0);
    const pendingAmount = all.filter(p => p.status === "pending").reduce((s, p) => s + (p.amount || 0), 0);
    const paidAmount = all.filter(p => p.status === "paid").reduce((s, p) => s + (p.amount || 0), 0);
    const totalCommission = all.reduce((s, p) => s + (p.commissionAmount || 0), 0);
    const missionsCount = new Set(all.filter(p => p.missionId).map(p => p.missionId)).size;
    const avgMissionAmount = missionsCount > 0 ? totalRevenue / missionsCount : 0;

    res.json({
      totalRevenue,
      pendingAmount,
      paidAmount,
      totalCommission,
      missionsCount,
      avgMissionAmount,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── POST /payments ───────────────────────────────────────────────────────────
router.post("/payments", requireAdmin, async (req, res) => {
  try {
    const body = req.body;
    const amount = Number(body.amount);
    if (!isFinite(amount) || amount <= 0) return res.status(400).json({ error: "Montant invalide" });
    const commissionAmount = Math.round(amount * 0.2 * 100) / 100;
    const [payment] = await db.insert(paymentsTable).values({
      missionId: body.missionId || null,
      amount,
      currency: body.currency || "EUR",
      status: body.status || "pending",
      method: body.method,
      reference: body.reference || null,
      description: body.description || null,
      commissionAmount,
      commissionStatus: "pending",
      paidAt: body.status === "paid" ? new Date() : null,
    }).returning();

    if (body.status === "paid") {
      let notifProviderId = null;
      if (body.missionId) {
        const [mission] = await db.select({ providerId: missionsTable.providerId }).from(missionsTable).where(eq(missionsTable.id, body.missionId)).limit(1);
        if (mission) notifProviderId = mission.providerId;
      }
      if (notifProviderId) {
        await db.insert(notificationsTable).values({
          type: "payment_received",
          title: "Paiement reçu",
          message: `Paiement de ${body.amount}€ reçu via ${body.method}`,
          missionId: body.missionId || null,
          providerId: notifProviderId,
          isRead: false,
        });
      }
    }

    res.status(201).json(payment);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── PATCH /payments/:id ──────────────────────────────────────────────────────
router.patch("/payments/:id", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: "ID invalide" });
    const body = req.body;

    const validStatuses = ["pending", "paid", "failed", "refunded"];
    const validCommissionStatuses = ["pending", "paid"];

    const updates: any = {};
    if (body.status !== undefined) {
      if (!validStatuses.includes(body.status)) return res.status(400).json({ error: "Statut invalide" });
      updates.status = body.status;
      if (body.status === "paid") updates.paidAt = new Date();
    }
    if (body.method !== undefined) updates.method = body.method;
    if (body.commissionStatus !== undefined) {
      if (!validCommissionStatuses.includes(body.commissionStatus)) return res.status(400).json({ error: "Statut commission invalide" });
      updates.commissionStatus = body.commissionStatus;
    }
    if (body.commissionProof !== undefined) updates.commissionProof = body.commissionProof;
    if (body.reference !== undefined) updates.reference = body.reference;

    const [payment] = await db
      .update(paymentsTable)
      .set(updates)
      .where(eq(paymentsTable.id, id))
      .returning();

    if (!payment) return res.status(404).json({ error: "Payment not found" });
    res.json(payment);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
