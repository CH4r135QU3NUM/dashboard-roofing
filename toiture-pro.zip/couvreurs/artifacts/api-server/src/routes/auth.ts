import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { db } from "@workspace/db";
import { providersTable, adminsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";

const router = Router();

// JWT_SECRET est garanti non-undefined grâce à la vérification dans app.ts.
// On caste pour satisfaire TypeScript.
const JWT_SECRET = process.env["JWT_SECRET"] as string;
const JWT_EXPIRES = "7d";

export function signToken(payload: object) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES } as jwt.SignOptions);
}

export function verifyToken(token: string) {
  return jwt.verify(token, JWT_SECRET) as jwt.JwtPayload;
}

// ─── Admin login ──────────────────────────────────────────────────────────────
router.post("/admin/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: "Email et mot de passe requis." });

    const [admin] = await db.select().from(adminsTable).where(eq(adminsTable.email, email.toLowerCase().trim()));
    if (!admin) return res.status(401).json({ error: "Identifiants incorrects." });

    const valid = await bcrypt.compare(password, admin.passwordHash);
    if (!valid) return res.status(401).json({ error: "Identifiants incorrects." });

    const token = signToken({ id: admin.id, email: admin.email, name: admin.name, role: "admin" });
    res.json({ token, user: { id: admin.id, name: admin.name, email: admin.email, role: "admin" } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erreur serveur." });
  }
});

// ─── Provider login ───────────────────────────────────────────────────────────
router.post("/provider/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: "Email et mot de passe requis." });

    const normalizedEmail = email.toLowerCase().trim();
    const providers = await db.select().from(providersTable).where(sql`LOWER(${providersTable.email}) = ${normalizedEmail}`);
    if (providers.length === 0) return res.status(401).json({ error: "Identifiants incorrects." });

    for (const provider of providers) {
      if (!provider.passwordHash) continue;
      if (provider.status === "suspended") continue;

      const valid = await bcrypt.compare(password, provider.passwordHash);
      if (valid) {
        const token = signToken({ id: provider.id, email: provider.email, name: provider.name, role: "provider" });
        return res.json({ token, user: { id: provider.id, name: provider.name, email: provider.email, role: "provider" } });
      }
    }

    const hasPassword = providers.some(p => !!p.passwordHash);
    const allSuspended = providers.filter(p => !!p.passwordHash).every(p => p.status === "suspended");

    if (!hasPassword) return res.status(401).json({ error: "Compte non activé. Contactez l'administrateur." });
    if (allSuspended) return res.status(403).json({ error: "Compte suspendu. Contactez l'administrateur." });
    return res.status(401).json({ error: "Identifiants incorrects." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erreur serveur." });
  }
});

// ─── Provider register ────────────────────────────────────────────────────────
router.post("/provider/register", async (req, res) => {
  try {
    const { name, email, phone, password } = req.body;
    if (!name || !email || !phone || !password) return res.status(400).json({ error: "Tous les champs sont requis." });
    if (password.length < 6) return res.status(400).json({ error: "Le mot de passe doit contenir au moins 6 caractères." });

    const normalizedEmail = email.toLowerCase().trim();
    const [existing] = await db.select({ id: providersTable.id }).from(providersTable).where(eq(providersTable.email, normalizedEmail));
    if (existing) return res.status(409).json({ error: "Un compte avec cet email existe déjà." });

    const passwordHash = await bcrypt.hash(password, 12);
    const [provider] = await db.insert(providersTable).values({
      name: name.trim(),
      email: normalizedEmail,
      phone: phone.trim(),
      passwordHash,
      status: "active",
      specialties: [],
      isAvailable: false,
    }).returning();

    const token = signToken({ id: provider.id, email: provider.email, name: provider.name, role: "provider" });
    res.status(201).json({ token, user: { id: provider.id, name: provider.name, email: provider.email, role: "provider" } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erreur serveur." });
  }
});

// ─── Get current user (verify token) ─────────────────────────────────────────
router.get("/me", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith("Bearer ")) return res.status(401).json({ error: "Non authentifié." });
    const token = authHeader.slice(7);
    const payload = verifyToken(token);
    res.json({ user: { id: payload["id"], name: payload["name"], email: payload["email"], role: payload["role"] } });
  } catch {
    res.status(401).json({ error: "Token invalide ou expiré." });
  }
});

export default router;
