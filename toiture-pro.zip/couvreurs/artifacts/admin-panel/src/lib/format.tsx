import { 
  Wrench, Hammer, Droplets, Sparkles, Square, ThermometerSun, FileText,
  CheckCircle2, Clock, PlayCircle, XCircle
} from "lucide-react";
import { format, parseISO } from "date-fns";
import { fr } from "date-fns/locale";
import { Badge } from "@/components/ui/badge";

export function formatCurrency(value: number | null | undefined): string {
  if (value == null) return "0,00 €";
  return new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(value);
}

export function formatDateTime(dateStr: string | null | undefined): string {
  if (!dateStr) return "-";
  try {
    const withoutTz = dateStr.replace("Z", "").replace(/\+\d{2}:\d{2}$/, "");
    return format(parseISO(withoutTz), "dd MMM yyyy, HH:mm", { locale: fr });
  } catch { return "-"; }
}

export function MissionStatusBadge({ status }: { status: string }) {
  switch (status) {
    case "pending":     return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200"><Clock className="w-3 h-3 mr-1" /> En attente</Badge>;
    case "confirmed":   return <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200"><CheckCircle2 className="w-3 h-3 mr-1" /> Confirmé</Badge>;
    case "in_progress": return <Badge variant="outline" className="bg-orange-100 text-orange-800 border-orange-200"><PlayCircle className="w-3 h-3 mr-1" /> En cours</Badge>;
    case "completed":   return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200"><CheckCircle2 className="w-3 h-3 mr-1" /> Terminé</Badge>;
    case "cancelled":   return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200"><XCircle className="w-3 h-3 mr-1" /> Annulé</Badge>;
    default:            return <Badge variant="outline">{status}</Badge>;
  }
}

export function MissionPriorityBadge({ priority }: { priority: string }) {
  switch (priority) {
    case "low":    return <Badge variant="secondary" className="text-xs">Basse</Badge>;
    case "normal": return <Badge variant="secondary" className="bg-blue-50 text-blue-700 hover:bg-blue-100 border-blue-200 text-xs">Normale</Badge>;
    case "high":   return <Badge variant="secondary" className="bg-orange-50 text-orange-700 hover:bg-orange-100 border-orange-200 text-xs">Haute</Badge>;
    case "urgent": return <Badge variant="destructive" className="animate-pulse text-xs">Urgente</Badge>;
    default:       return <Badge variant="secondary">{priority}</Badge>;
  }
}

export function ProviderStatusBadge({ status }: { status: string }) {
  switch (status) {
    case "active":    return <Badge className="bg-green-500 hover:bg-green-600">Actif</Badge>;
    case "inactive":  return <Badge variant="secondary">Inactif</Badge>;
    case "suspended": return <Badge variant="destructive">Suspendu</Badge>;
    default:          return <Badge variant="outline">{status}</Badge>;
  }
}

// Icônes par type de travaux de couverture
export function InterventionIcon({ type, className = "w-4 h-4" }: { type: string; className?: string }) {
  switch (type) {
    case "reparation_fuite":    return <Droplets className={`text-blue-500 ${className}`} />;
    case "remplacement_tuiles": return <Hammer className={`text-orange-500 ${className}`} />;
    case "renovation_complete": return <Wrench className={`text-red-500 ${className}`} />;
    case "nettoyage_toiture":   return <Sparkles className={`text-green-500 ${className}`} />;
    case "pose_velux":          return <Square className={`text-purple-500 ${className}`} />;
    case "isolation_combles":   return <ThermometerSun className={`text-amber-500 ${className}`} />;
    default:                    return <FileText className={`text-primary ${className}`} />;
  }
}

export function getInterventionLabel(type: string): string {
  const map: Record<string, string> = {
    reparation_fuite:    "Réparation fuite",
    remplacement_tuiles: "Remplacement tuiles",
    renovation_complete: "Rénovation complète",
    nettoyage_toiture:   "Nettoyage / traitement",
    pose_velux:          "Pose Velux",
    isolation_combles:   "Isolation combles",
    autre:               "Autre",
  };
  return map[type] || type;
}

export function getRoofTypeLabel(type: string): string {
  const map: Record<string, string> = {
    tuiles_terre_cuite: "Tuiles terre cuite",
    tuiles_beton:       "Tuiles béton",
    ardoise:            "Ardoise",
    zinc:               "Zinc",
    bac_acier:          "Bac acier",
    bitume:             "Bitume",
    chaume:             "Chaume",
    autre:              "Autre",
  };
  return map[type] || type;
}
