import { useState, useEffect } from "react";
import { Layout } from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { KeyRound, Eye, EyeOff, ShieldCheck, Save, RefreshCw } from "lucide-react";

export default function Settings() {
  const { toast } = useToast();

  const [currentCode, setCurrentCode] = useState<string | null>(null);
  const [newCode, setNewCode] = useState("");
  const [confirmCode, setConfirmCode] = useState("");
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetch("/api/settings/deletionCode")
      .then(r => r.json())
      .then(d => {
        if (d.value) setCurrentCode(d.value);
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  }, []);

  const handleSave = async () => {
    if (!newCode || newCode.length < 4) {
      toast({ title: "Erreur", description: "Le code doit contenir au moins 4 caractères.", variant: "destructive" });
      return;
    }
    if (newCode !== confirmCode) {
      toast({ title: "Erreur", description: "Les deux codes ne correspondent pas.", variant: "destructive" });
      return;
    }
    setIsSaving(true);
    try {
      const res = await fetch("/api/settings/deletionCode", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ value: newCode }),
      });
      if (!res.ok) throw new Error();
      setCurrentCode(newCode);
      setNewCode("");
      setConfirmCode("");
      toast({ title: "Succès", description: "Code de suppression mis à jour." });
    } catch {
      toast({ title: "Erreur", description: "Impossible de mettre à jour le code.", variant: "destructive" });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Layout>
      <div className="flex flex-col gap-6 max-w-2xl">
        <div>
          <h1 className="text-3xl font-display font-bold">Réglages</h1>
          <p className="text-muted-foreground mt-1">Paramètres de sécurité et configuration.</p>
        </div>

        <Card className="rounded-2xl border-border/50 shadow-sm">
          <CardHeader className="pb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
                <KeyRound className="w-5 h-5 text-amber-500" />
              </div>
              <div>
                <CardTitle className="text-base">Code de suppression des missions</CardTitle>
                <CardDescription className="text-sm mt-0.5">
                  Ce code est requis pour supprimer définitivement une mission.
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-5">
            {/* Current code indicator */}
            <div className="flex items-center gap-2 p-3 rounded-xl bg-muted/50 border border-border/40">
              <ShieldCheck className="w-4 h-4 text-green-500 shrink-0" />
              <span className="text-sm text-muted-foreground">
                {isLoading ? "Chargement..." : (
                  <>Code actuel : <span className="font-mono font-semibold text-foreground tracking-wider">{currentCode?.replace(/./g, "•")}</span></>
                )}
              </span>
            </div>

            {/* New code */}
            <div className="space-y-2">
              <Label htmlFor="newCode" className="text-sm font-medium">Nouveau code</Label>
              <div className="relative">
                <Input
                  id="newCode"
                  type={showNew ? "text" : "password"}
                  placeholder="Minimum 4 caractères"
                  value={newCode}
                  onChange={e => setNewCode(e.target.value)}
                  className="rounded-xl pr-10 font-mono"
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  onClick={() => setShowNew(!showNew)}
                >
                  {showNew ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Confirm code */}
            <div className="space-y-2">
              <Label htmlFor="confirmCode" className="text-sm font-medium">Confirmer le nouveau code</Label>
              <div className="relative">
                <Input
                  id="confirmCode"
                  type={showConfirm ? "text" : "password"}
                  placeholder="Répétez le code"
                  value={confirmCode}
                  onChange={e => setConfirmCode(e.target.value)}
                  className="rounded-xl pr-10 font-mono"
                  onKeyDown={e => e.key === "Enter" && handleSave()}
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  onClick={() => setShowConfirm(!showConfirm)}
                >
                  {showConfirm ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {confirmCode && newCode && confirmCode !== newCode && (
                <p className="text-xs text-destructive">Les codes ne correspondent pas.</p>
              )}
              {confirmCode && newCode && confirmCode === newCode && (
                <p className="text-xs text-green-600">Les codes correspondent.</p>
              )}
            </div>

            <div className="flex justify-end pt-2">
              <Button
                onClick={handleSave}
                disabled={isSaving || !newCode || !confirmCode}
                className="bg-primary hover:bg-primary/90 text-white rounded-xl px-6 shadow-md shadow-primary/20 gap-2"
              >
                {isSaving ? (
                  <><RefreshCw className="w-4 h-4 animate-spin" /> Enregistrement...</>
                ) : (
                  <><Save className="w-4 h-4" /> Enregistrer</>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
