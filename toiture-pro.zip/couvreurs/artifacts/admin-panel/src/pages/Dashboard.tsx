import { Layout } from "@/components/Layout";
import { useGetAdminStats } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCurrency, formatDateTime, MissionStatusBadge, InterventionIcon, getInterventionLabel } from "@/lib/format";
import { Users, ClipboardList, Clock, Euro, Star, MapPin, XCircle, Percent } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, PieChart, Pie, Cell } from "recharts";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { motion } from "framer-motion";

const PIE_COLORS = {
  'completed': '#10b981', // green
  'in_progress': '#f97316', // orange
  'pending': '#eab308', // yellow
  'cancelled': '#ef4444', // red
  'confirmed': '#3b82f6', // blue
};

const STATUS_LABELS_FR: Record<string, string> = {
  'pending': 'En attente',
  'confirmed': 'Confirmée',
  'in_progress': 'En cours',
  'completed': 'Terminée',
  'cancelled': 'Annulée',
};

export default function Dashboard() {
  const { data: stats, isLoading } = useGetAdminStats();

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-[60vh]">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      </Layout>
    );
  }

  if (!stats) return null;

  // Format month data for chart
  const barData = stats.missionsByMonth.map(m => {
    try {
      const d = new Date(m.month + '-01');
      return {
        name: format(d, 'MMM', { locale: fr }).toUpperCase(),
        missions: m.missions,
        revenue: m.revenue
      };
    } catch {
      return { name: m.month, missions: m.missions, revenue: m.revenue };
    }
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    show: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } }
  };

  return (
    <Layout>
      <motion.div variants={containerVariants} initial="hidden" animate="show" className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold font-display text-foreground">Tableau de bord</h1>
          <p className="text-muted-foreground mt-1">Vue d'ensemble de l'activité du réseau de dépannage.</p>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          <motion.div variants={itemVariants}>
            <Card className="rounded-2xl border-none shadow-lg shadow-black/5 bg-gradient-to-br from-card to-card/50 overflow-hidden relative group">
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity transform group-hover:scale-110 duration-500">
                <Users className="w-16 h-16 text-primary" />
              </div>
              <CardContent className="p-6 relative z-10">
                <p className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-2">Prestataires Actifs</p>
                <div className="flex items-end gap-3">
                  <h3 className="text-4xl font-display font-bold text-foreground">{stats.activeProviders}</h3>
                  <span className="text-sm text-muted-foreground mb-1 font-medium">/ {stats.totalProviders} total</span>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Card className="rounded-2xl border-none shadow-lg shadow-black/5 bg-gradient-to-br from-card to-card/50 overflow-hidden relative group">
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity transform group-hover:scale-110 duration-500">
                <ClipboardList className="w-16 h-16 text-blue-500" />
              </div>
              <CardContent className="p-6 relative z-10">
                <p className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-2">Missions Globales</p>
                <div className="flex items-end gap-3">
                  <h3 className="text-4xl font-display font-bold text-foreground">{stats.totalMissions}</h3>
                  <span className="text-sm text-green-500 mb-1 font-medium">{stats.completedMissions} terminées</span>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Card className="rounded-2xl border-none shadow-lg shadow-black/5 bg-gradient-to-br from-card to-card/50 overflow-hidden relative group">
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity transform group-hover:scale-110 duration-500">
                <Clock className="w-16 h-16 text-orange-500" />
              </div>
              <CardContent className="p-6 relative z-10">
                <p className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-2">En Attente</p>
                <div className="flex items-end gap-3">
                  <h3 className="text-4xl font-display font-bold text-foreground">{stats.pendingMissions}</h3>
                  <span className="text-sm text-muted-foreground mb-1 font-medium">à assigner/confirmer</span>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Card className="rounded-2xl border-none shadow-lg shadow-primary/10 bg-gradient-to-br from-primary to-primary/80 text-primary-foreground overflow-hidden relative group">
              <div className="absolute top-0 right-0 p-4 opacity-20 group-hover:opacity-30 transition-opacity transform group-hover:scale-110 duration-500">
                <Euro className="w-16 h-16 text-white" />
              </div>
              <CardContent className="p-6 relative z-10">
                <p className="text-sm font-semibold text-primary-foreground/80 uppercase tracking-wider mb-2">Revenus du mois</p>
                <div className="flex items-end gap-3">
                  <h3 className="text-4xl font-display font-bold text-white">{formatCurrency(stats.revenueThisMonth)}</h3>
                </div>
                <p className="text-xs text-primary-foreground/70 mt-2 font-medium">Total généré: {formatCurrency(stats.totalRevenue)}</p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <motion.div variants={itemVariants} className="lg:col-span-2">
            <Card className="rounded-2xl border-border/50 shadow-md shadow-black/5 h-full">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-display text-foreground">Évolution des Missions (12 mois)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] w-full mt-4">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={barData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                      <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} dy={10} />
                      <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} />
                      <Tooltip 
                        cursor={{ fill: 'hsl(var(--muted)/0.5)' }}
                        contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                      />
                      <Bar dataKey="missions" name="Missions" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} maxBarSize={40} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Card className="rounded-2xl border-border/50 shadow-md shadow-black/5 h-full">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-display text-foreground">Répartition par Statut</CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col items-center justify-center pt-6">
                <div className="h-[220px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={stats.missionsByStatus}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="count"
                        nameKey="status"
                      >
                        {stats.missionsByStatus.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={PIE_COLORS[entry.status as keyof typeof PIE_COLORS] || '#cbd5e1'} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                        formatter={(value: number, _name: string, props: any) => [
                          `${value} mission${value > 1 ? 's' : ''}`,
                          STATUS_LABELS_FR[props.payload?.status] || props.payload?.status
                        ]}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex flex-wrap justify-center gap-3 mt-4 w-full">
                  {stats.missionsByStatus.map(s => (
                    <div key={s.status} className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: PIE_COLORS[s.status as keyof typeof PIE_COLORS] || '#cbd5e1' }} />
                      <span>{STATUS_LABELS_FR[s.status] || s.status}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Bottom Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Top Providers */}
          <motion.div variants={itemVariants}>
            <Card className="rounded-2xl border-border/50 shadow-md shadow-black/5 h-full flex flex-col">
              <CardHeader className="border-b border-border/40 pb-4">
                <CardTitle className="text-lg font-display text-foreground">Top Prestataires</CardTitle>
              </CardHeader>
              <CardContent className="p-0 flex-1">
                <div className="divide-y divide-border/40">
                  {stats.topProviders.map((provider, i) => (
                    <div key={provider.id} className="p-4 flex items-center justify-between hover:bg-muted/30 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${i < 3 ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>
                          #{i + 1}
                        </div>
                        <div>
                          <p className="font-semibold text-foreground text-sm">{provider.name}</p>
                          <div className="flex items-center gap-1 mt-1">
                            <Star className="w-3 h-3 fill-orange-400 text-orange-400" />
                            <span className="text-xs text-muted-foreground">{provider.rating?.toFixed(1) || 'N/A'}</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-sm text-foreground">{provider.missions} <span className="text-xs font-normal text-muted-foreground">missions</span></p>
                        <p className="text-xs text-green-600 font-medium mt-0.5">{formatCurrency(provider.revenue)}</p>
                      </div>
                    </div>
                  ))}
                  {stats.topProviders.length === 0 && (
                    <div className="p-8 text-center text-muted-foreground text-sm">Aucune donnée disponible</div>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Recent Missions */}
          <motion.div variants={itemVariants}>
            <Card className="rounded-2xl border-border/50 shadow-md shadow-black/5 h-full flex flex-col">
              <CardHeader className="border-b border-border/40 pb-4">
                <CardTitle className="text-lg font-display text-foreground">Missions Récentes</CardTitle>
              </CardHeader>
              <CardContent className="p-0 flex-1">
                <div className="divide-y divide-border/40">
                  {stats.recentMissions.map((mission) => (
                    <div key={mission.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-muted/30 transition-colors">
                      <div className="flex items-start gap-3">
                        <div className="bg-background border border-border shadow-sm p-2 rounded-xl mt-0.5">
                          <InterventionIcon type={mission.interventionType} />
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-semibold text-sm text-foreground">{mission.clientName}</span>
                            <MissionStatusBadge status={mission.status} />
                          </div>
                          <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                            <span className="font-medium text-foreground/80">{getInterventionLabel(mission.interventionType)}</span>
                            <span>•</span>
                            <span>{mission.vehicleMake} {mission.vehicleModel}</span>
                          </p>
                        </div>
                      </div>
                      <div className="text-left sm:text-right text-xs">
                        <p className="text-muted-foreground mb-1">{formatDateTime(mission.scheduledAt)}</p>
                        {mission.providerName ? (
                          <p className="font-medium text-primary bg-primary/5 px-2 py-0.5 rounded inline-block">
                            {mission.providerName}
                          </p>
                        ) : (
                          <p className="font-medium text-orange-500 bg-orange-500/10 px-2 py-0.5 rounded inline-block">
                            Non assignée
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                  {stats.recentMissions.length === 0 && (
                    <div className="p-8 text-center text-muted-foreground text-sm">Aucune mission récente</div>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Cities & Refusals Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <motion.div variants={itemVariants}>
            <Card className="rounded-2xl border-border/50 shadow-md shadow-black/5 h-full flex flex-col">
              <CardHeader className="border-b border-border/40 pb-4">
                <CardTitle className="text-lg font-display text-foreground flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-primary" /> Top Villes
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0 flex-1">
                <div className="divide-y divide-border/40">
                  {(stats as any).topCities?.map((city: any, i: number) => (
                    <div key={city.city} className="p-4 flex items-center justify-between hover:bg-muted/30 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs ${i < 3 ? 'bg-blue-500/10 text-blue-600' : 'bg-muted text-muted-foreground'}`}>
                          {i + 1}
                        </div>
                        <span className="font-medium text-sm text-foreground">{city.city}</span>
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-sm text-foreground">{city.missions} <span className="text-xs font-normal text-muted-foreground">missions</span></span>
                        <p className="text-xs text-green-600 font-medium">{formatCurrency(city.revenue)}</p>
                      </div>
                    </div>
                  ))}
                  {(!(stats as any).topCities || (stats as any).topCities.length === 0) && (
                    <div className="p-8 text-center text-muted-foreground text-sm">Aucune donnée disponible</div>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Card className="rounded-2xl border-border/50 shadow-md shadow-black/5 h-full flex flex-col">
              <CardHeader className="border-b border-border/40 pb-4">
                <CardTitle className="text-lg font-display text-foreground flex items-center gap-2">
                  <XCircle className="w-5 h-5 text-red-500" /> Refus par Prestataire
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0 flex-1">
                <div className="divide-y divide-border/40">
                  {(stats as any).topRefusals?.filter((r: any) => r.refusalCount > 0).map((provider: any, i: number) => (
                    <div key={provider.providerId} className="p-4 flex items-center justify-between hover:bg-muted/30 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs ${i < 3 ? 'bg-red-500/10 text-red-600' : 'bg-muted text-muted-foreground'}`}>
                          {i + 1}
                        </div>
                        <span className="font-medium text-sm text-foreground">{provider.name}</span>
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-sm text-red-600">{provider.refusalCount}</span>
                        <span className="text-xs text-muted-foreground ml-1">refus</span>
                      </div>
                    </div>
                  ))}
                  {(!(stats as any).topRefusals || (stats as any).topRefusals.filter((r: any) => r.refusalCount > 0).length === 0) && (
                    <div className="p-8 text-center text-muted-foreground text-sm">Aucun refus enregistré</div>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </motion.div>
    </Layout>
  );
}
