import { useState } from "react";
import { Layout } from "@/components/Layout";
import { useGetVehicles, useCreateVehicle, useUpdateVehicle, useDeleteVehicle, useGetClients } from "@workspace/api-client-react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Search, Plus, Pencil, Trash2, Car, User } from "lucide-react";

const vehicleSchema = z.object({
  make: z.string().min(1, "Marque requise"),
  model: z.string().min(1, "Modèle requis"),
  plate: z.string().min(4, "Plaque requise"),
  year: z.coerce.number().optional().or(z.literal(0)),
  color: z.string().optional(),
  vin: z.string().optional(),
  clientId: z.string().optional().or(z.literal("none")), // Treat "none" as null
});

export default function Vehicles() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [selectedId, setSelectedId] = useState<number | null>(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: vResponse, isLoading: vLoading } = useGetVehicles();
  const { data: cResponse } = useGetClients();
  const createMutation = useCreateVehicle();
  const updateMutation = useUpdateVehicle();
  const deleteMutation = useDeleteVehicle();

  const vehicles = vResponse?.vehicles || [];
  const clients = cResponse?.clients || [];
  
  const filteredVehicles = vehicles.filter(v => 
    v.plate.toLowerCase().includes(searchTerm.toLowerCase()) || 
    `${v.make} ${v.model}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (v.clientName && v.clientName.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const form = useForm<z.infer<typeof vehicleSchema>>({
    resolver: zodResolver(vehicleSchema),
    defaultValues: { make: "", model: "", plate: "", year: undefined, color: "", vin: "", clientId: "none" }
  });

  const openCreate = () => {
    setSelectedId(null);
    form.reset({ make: "", model: "", plate: "", color: "", vin: "", clientId: "none" });
    setIsFormOpen(true);
  };

  const openEdit = (vehicle: any) => {
    setSelectedId(vehicle.id);
    form.reset({
      make: vehicle.make,
      model: vehicle.model,
      plate: vehicle.plate,
      year: vehicle.year || undefined,
      color: vehicle.color || "",
      vin: vehicle.vin || "",
      clientId: vehicle.clientId ? vehicle.clientId.toString() : "none",
    });
    setIsFormOpen(true);
  };

  const onSubmit = async (data: z.infer<typeof vehicleSchema>) => {
    const payload = {
      ...data,
      clientId: data.clientId === "none" ? undefined : parseInt(data.clientId!),
      year: data.year || undefined
    };

    try {
      if (selectedId) {
        await updateMutation.mutateAsync({ id: selectedId, data: payload });
        toast({ title: "Bien mis à jour" });
      } else {
        await createMutation.mutateAsync({ data: payload as any });
        toast({ title: "Bien ajouté" });
      }
      setIsFormOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/vehicles"] });
    } catch {
      toast({ title: "Erreur", variant: "destructive" });
    }
  };

  const handleDelete = async () => {
    if (!selectedId) return;
    try {
      await deleteMutation.mutateAsync({ id: selectedId });
      toast({ title: "Bien supprimé" });
      setIsDeleteOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/vehicles"] });
    } catch {
      toast({ title: "Erreur", variant: "destructive" });
    }
  };

  return (
    <Layout>
      <div className="flex flex-col gap-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold">Biens & Toitures</h1>
            <p className="text-muted-foreground mt-1">Référentiel des biens immobiliers et toitures..</p>
          </div>
          <Button onClick={openCreate} className="bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/25 rounded-xl px-6">
            <Plus className="w-4 h-4 mr-2" /> Ajouter un bien
          </Button>
        </div>

        <Card className="rounded-2xl border-border/50 shadow-md shadow-black/5 overflow-hidden">
          <div className="p-4 border-b border-border/40 bg-muted/10">
            <div className="relative w-full max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Rechercher par référence, type, propriétaire..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 bg-background border-border/50 rounded-xl"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-muted/30">
                <TableRow className="hover:bg-transparent">
                  <TableHead className="font-semibold">Véhicule</TableHead>
                  <TableHead className="font-semibold">Immatriculation</TableHead>
                  <TableHead className="font-semibold">Propriétaire</TableHead>
                  <TableHead className="text-right font-semibold">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {vLoading ? (
                  <TableRow><TableCell colSpan={4} className="h-24 text-center">Chargement...</TableCell></TableRow>
                ) : filteredVehicles.length === 0 ? (
                  <TableRow><TableCell colSpan={4} className="h-32 text-center text-muted-foreground">Aucun bien trouvé.</TableCell></TableRow>
                ) : (
                  filteredVehicles.map((vehicle) => (
                    <TableRow key={vehicle.id} className="hover:bg-muted/20">
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="bg-muted p-2 rounded-lg"><Car className="w-4 h-4 text-primary" /></div>
                          <div>
                            <div className="font-bold text-foreground uppercase tracking-tight">{vehicle.make} {vehicle.model}</div>
                            <div className="text-xs text-muted-foreground mt-0.5">
                              {vehicle.year ? `${vehicle.year} • ` : ''}{vehicle.color || 'Couleur non précisée'}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="inline-block bg-background border-2 border-border px-2 py-1 flex items-center justify-center font-mono font-bold rounded text-sm w-fit shadow-sm">
                          {vehicle.plate}
                        </div>
                      </TableCell>
                      <TableCell>
                        {vehicle.clientName ? (
                          <div className="flex items-center gap-2 text-sm">
                            <User className="w-4 h-4 text-muted-foreground" />
                            <span>{vehicle.clientName}</span>
                          </div>
                        ) : (
                          <span className="text-xs italic text-muted-foreground">Non assigné</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg" onClick={() => openEdit(vehicle)}>
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg" onClick={() => { setSelectedId(vehicle.id); setIsDeleteOpen(true); }}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </Card>
      </div>

      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="sm:max-w-[500px] rounded-2xl">
          <DialogHeader>
            <DialogTitle>{selectedId ? "Modifier le bien" : "Nouveau bien"}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="plate" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Référence cadastrale'immatriculation *</FormLabel>
                    <FormControl><Input placeholder="Ex: 76000 - Section B 123" {...field} className="rounded-xl uppercase font-mono" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="make" render={({ field }) => (
                  <FormItem><FormLabel>Type de bien *</FormLabel><FormControl><Input placeholder="Maison individuelle" {...field} className="rounded-xl" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="model" render={({ field }) => (
                  <FormItem><FormLabel>Type de toiture *</FormLabel><FormControl><Input placeholder="2 pans" {...field} className="rounded-xl" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="year" render={({ field }) => (
                  <FormItem><FormLabel>Année de construction</FormLabel><FormControl><Input type="number" placeholder="ex: 1985" {...field} className="rounded-xl" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="color" render={({ field }) => (
                  <FormItem><FormLabel>Matériau principal</FormLabel><FormControl><Input placeholder="Ex: ardoise" {...field} className="rounded-xl" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="clientId" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Propriétaire / Client</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl><SelectTrigger className="rounded-xl"><SelectValue placeholder="Aucun" /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="none">Aucun (Non assigné)</SelectItem>
                        {clients.map(c => (
                          <SelectItem key={c.id} value={c.id.toString()}>{c.firstName} {c.lastName}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormItem>
                )} />
              </div>
              <DialogFooter className="pt-4 mt-2">
                <Button type="button" variant="outline" onClick={() => setIsFormOpen(false)} className="rounded-xl">Annuler</Button>
                <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending} className="rounded-xl">Enregistrer</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <DialogContent className="sm:max-w-md rounded-2xl">
          <DialogHeader><DialogTitle>Supprimer le bien ?</DialogTitle></DialogHeader>
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={() => setIsDeleteOpen(false)} className="rounded-xl">Annuler</Button>
            <Button variant="destructive" onClick={handleDelete} disabled={deleteMutation.isPending} className="rounded-xl">Confirmer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
