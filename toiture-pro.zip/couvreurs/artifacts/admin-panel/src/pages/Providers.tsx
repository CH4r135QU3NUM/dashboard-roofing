import React, { useState, useCallback, useRef, useEffect } from "react";
import { Layout } from "@/components/Layout";
import { 
  useGetProviders, 
  useCreateProvider, 
  useUpdateProvider, 
  useDeleteProvider 
} from "@workspace/api-client-react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { ProviderStatusBadge, formatCurrency, getInterventionLabel } from "@/lib/format";
import { Search, Plus, Pencil, Trash2, MapPin, Mail, Phone, Map, Star, Briefcase, Euro, Wrench, Car, Warehouse, KeyRound, Eye, EyeOff, Building, Loader2, CreditCard } from "lucide-react";
import { AddressAutocomplete } from "@/components/AddressAutocomplete";
import { motion, AnimatePresence } from "framer-motion";
import { Checkbox } from "@/components/ui/checkbox";

const INTERVENTION_OPTIONS = [
  { value: "depannage", label: "Dépannage" },
  { value: "remorquage", label: "Remorquage" },
  { value: "panne_batterie", label: "Panne batterie" },
  { value: "crevaison", label: "Crevaison" },
  { value: "accident", label: "Accident" },
  { value: "autre", label: "Autre" },
];

const VEHICLE_OPTIONS = [
  { value: "vl", label: "Véhicule Léger (VL)" },
  { value: "pl", label: "Poids Lourd (PL)" },
  { value: "moto", label: "Moto / 2 roues" },
  { value: "utilitaire", label: "Utilitaire" },
];

const PAYMENT_METHOD_OPTIONS = [
  { value: "especes", label: "Espèces" },
  { value: "virement", label: "Virement" },
  { value: "carte_bancaire", label: "Carte bancaire" },
  { value: "cheque", label: "Chèque" },
  { value: "compensation", label: "Compensation" },
  { value: "cryptomonnaie", label: "Cryptomonnaie" },
];

const SPECIALTY_LABELS: Record<string, string> = {
  reparation_fuite: "Réparation fuite", remplacement_tuiles: "Remplacement tuiles", renovation_complete: "Rénovation complète",
  nettoyage_toiture: "Nettoyage", pose_velux: "Pose Velux", autre: "Autre",
  vl: "VL", pl: "PL", moto: "Moto", utilitaire: "Utilitaire",
};

const providerSchema = z.object({
  name: z.string().min(2, "Le nom est requis"),
  email: z.string().email("Email invalide"),
  phone: z.string().min(8, "Téléphone requis"),
  address: z.string().optional(),
  zone: z.string().optional(),
  status: z.enum(["active", "inactive", "suspended"]).default("active"),
  specialties: z.array(z.string()).default([]),
  storageType: z.enum(["interieur", "exterieur", "les_deux"]).nullable().optional(),
  storageCapacity: z.coerce.number().int().min(1).nullable().optional(),
  storagePricePerDay: z.coerce.number().min(0).nullable().optional(),
  storageAddress: z.string().optional(),
  siret: z.string().optional(),
  companyName: z.string().optional(),
  tvaNumber: z.string().optional(),
  isSubjectToTva: z.boolean().default(false),
  acceptedPaymentMethods: z.array(z.string()).default([]),
});

type ProviderFormValues = z.infer<typeof providerSchema>;

function CompanySearchSection({ form }: { form: any }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowResults(false);
      }
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  const searchCompanies = useCallback((q: string) => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (q.trim().length < 2) { setResults([]); setShowResults(false); return; }
    setIsSearching(true);
    debounceRef.current = setTimeout(async () => {
      try {
        const res = await fetch(`/api/companies/search?q=${encodeURIComponent(q)}`);
        const data = await res.json();
        setResults(data.results || []);
        setShowResults(true);
      } catch {
        setResults([]);
      } finally {
        setIsSearching(false);
      }
    }, 400);
  }, []);

  const selectCompany = (company: any) => {
    form.setValue("companyName", company.companyName, { shouldValidate: true });
    form.setValue("siret", company.siret, { shouldValidate: true });
    form.setValue("tvaNumber", company.tvaNumber, { shouldValidate: true });
    if (company.address) {
      form.setValue("address", company.address, { shouldValidate: true });
    }
    setQuery(company.companyName);
    setShowResults(false);
  };

  return (
    <div ref={containerRef} className="border border-blue-500/30 rounded-xl p-4 space-y-2 bg-blue-500/5 relative">
      <p className="text-sm font-semibold flex items-center gap-2 text-blue-600 dark:text-blue-400">
        <Building className="w-4 h-4" /> Recherche entreprise (auto-complétion)
      </p>
      <p className="text-xs text-muted-foreground">Tapez un nom, raison sociale ou SIRET pour pré-remplir les informations légales.</p>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Ex: Couverture Dupont, SARL Auto..."
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            searchCompanies(e.target.value);
          }}
          onFocus={() => results.length > 0 && setShowResults(true)}
          className="pl-9 rounded-xl"
        />
        {isSearching && <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-muted-foreground" />}
      </div>
      {showResults && results.length > 0 && (
        <div className="absolute left-0 right-0 top-full z-50 mt-1 mx-4 bg-background border border-border rounded-xl shadow-xl max-h-60 overflow-y-auto">
          {results.map((r: any, i: number) => (
            <button
              key={i}
              type="button"
              className="w-full text-left px-4 py-3 hover:bg-muted/50 transition-colors border-b border-border/30 last:border-b-0"
              onClick={() => selectCompany(r)}
            >
              <p className="font-medium text-sm">{r.companyName}</p>
              <p className="text-xs text-muted-foreground">SIRET: {r.siret} — {r.address}</p>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export default function Providers() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [passwordProvider, setPasswordProvider] = useState<{ id: number; name: string; email?: string } | null>(null);
  const [newPassword, setNewPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isSettingPassword, setIsSettingPassword] = useState(false);

  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: response, isLoading } = useGetProviders({
    query: {
      refetchInterval: 20_000,
      refetchOnWindowFocus: true,
      staleTime: 0,
    },
  });
  const createMutation = useCreateProvider();
  const updateMutation = useUpdateProvider();
  const deleteMutation = useDeleteProvider();

  const providers = response?.providers || [];
  
  const filteredProviders = providers.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          p.zone?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || p.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const form = useForm<ProviderFormValues>({
    resolver: zodResolver(providerSchema),
    defaultValues: { name: "", email: "", phone: "", address: "", zone: "", status: "active", specialties: [], storageType: null, storageCapacity: null, storagePricePerDay: null, storageAddress: "" }
  });

  const openCreate = () => {
    setSelectedId(null);
    form.reset({ name: "", email: "", phone: "", address: "", zone: "", status: "active", specialties: [], storageType: null, storageCapacity: null, storagePricePerDay: null, storageAddress: "", siret: "", companyName: "", tvaNumber: "", isSubjectToTva: false, acceptedPaymentMethods: [] });
    setIsFormOpen(true);
  };

  const openEdit = (provider: any, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedId(provider.id);
    form.reset({
      name: provider.name,
      email: provider.email,
      phone: provider.phone,
      address: provider.address || "",
      zone: provider.zone || "",
      status: provider.status as any,
      specialties: provider.specialties || [],
      storageType: provider.storageType || null,
      storageCapacity: provider.storageCapacity ?? null,
      storagePricePerDay: provider.storagePricePerDay ?? null,
      storageAddress: provider.storageAddress || "",
      siret: provider.siret || "",
      companyName: provider.companyName || "",
      tvaNumber: provider.tvaNumber || "",
      isSubjectToTva: provider.isSubjectToTva ?? false,
      acceptedPaymentMethods: provider.acceptedPaymentMethods || [],
    });
    setIsFormOpen(true);
  };

  const openDelete = (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedId(id);
    setIsDeleteOpen(true);
  };

  const toggleExpand = (id: number) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const toggleAvailability = async (id: number, currentStatus: boolean, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await updateMutation.mutateAsync({ id, data: { isAvailable: !currentStatus } });
      toast({ title: "Statut mis à jour", description: "La disponibilité a été modifiée." });
      queryClient.invalidateQueries({ queryKey: ["/api/providers"] });
    } catch {
      toast({ title: "Erreur", description: "Impossible de modifier la disponibilité.", variant: "destructive" });
    }
  };

  const onSubmit = async (data: ProviderFormValues) => {
    try {
      if (selectedId) {
        await updateMutation.mutateAsync({ id: selectedId, data });
        toast({ title: "Succès", description: "Couvreur mis à jour." });
      } else {
        await createMutation.mutateAsync({ data });
        toast({ title: "Succès", description: "Nouveau couvreur créé." });
      }
      setIsFormOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/providers"] });
    } catch {
      toast({ title: "Erreur", description: "Une erreur est survenue.", variant: "destructive" });
    }
  };

  const handleDelete = async () => {
    if (!selectedId) return;
    try {
      await deleteMutation.mutateAsync({ id: selectedId });
      toast({ title: "Succès", description: "Couvreur supprimé." });
      setIsDeleteOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/providers"] });
    } catch {
      toast({ title: "Erreur", description: "Impossible de supprimer ce couvreur.", variant: "destructive" });
    }
  };

  const handleSetPassword = async () => {
    if (!passwordProvider || !newPassword) return;
    if (newPassword.length < 6) {
      toast({ title: "Erreur", description: "Le mot de passe doit contenir au moins 6 caractères.", variant: "destructive" });
      return;
    }
    setIsSettingPassword(true);
    try {
      const res = await fetch(`/api/providers/${passwordProvider.id}/password`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: newPassword }),
      });
      if (!res.ok) throw new Error();
      toast({ title: "Succès", description: `Mot de passe mis à jour pour ${passwordProvider.name}.` });
      setPasswordProvider(null);
      setNewPassword("");
    } catch {
      toast({ title: "Erreur", description: "Impossible de définir le mot de passe.", variant: "destructive" });
    } finally {
      setIsSettingPassword(false);
    }
  };

  return (
    <Layout>
      <div className="flex flex-col gap-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold">Prestataires</h1>
            <p className="text-muted-foreground mt-1">Gérez votre réseau de couvreurs partenaires.</p>
          </div>
          <Button onClick={openCreate} className="bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/25 rounded-xl px-6">
            <Plus className="w-4 h-4 mr-2" /> Ajouter un couvreur
          </Button>
        </div>

        <Card className="rounded-2xl border-border/50 shadow-md shadow-black/5 overflow-hidden">
          <div className="p-4 border-b border-border/40 flex flex-col sm:flex-row gap-4 justify-between bg-muted/10">
            <div className="relative w-full sm:w-96">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Rechercher par nom, email ou zone..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 bg-background border-border/50 rounded-xl"
              />
            </div>
            <div className="w-full sm:w-48">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="bg-background border-border/50 rounded-xl">
                  <SelectValue placeholder="Filtrer par statut" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tous les statuts</SelectItem>
                  <SelectItem value="active">Actifs</SelectItem>
                  <SelectItem value="inactive">Inactifs</SelectItem>
                  <SelectItem value="suspended">Suspendus</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-muted/30">
                <TableRow className="hover:bg-transparent">
                  <TableHead className="w-[250px] font-semibold">Prestataire</TableHead>
                  <TableHead className="font-semibold">Contact</TableHead>
                  <TableHead className="font-semibold">Zone</TableHead>
                  <TableHead className="font-semibold">Statut</TableHead>
                  <TableHead className="font-semibold text-center">Disponible</TableHead>
                  <TableHead className="text-right font-semibold">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i} className="animate-pulse">
                      <TableCell><div className="h-10 bg-muted/50 rounded-lg w-full"></div></TableCell>
                      <TableCell><div className="h-10 bg-muted/50 rounded-lg w-full"></div></TableCell>
                      <TableCell><div className="h-6 bg-muted/50 rounded-full w-20"></div></TableCell>
                      <TableCell><div className="h-6 bg-muted/50 rounded-full w-16"></div></TableCell>
                      <TableCell><div className="h-6 bg-muted/50 rounded-full w-10 mx-auto"></div></TableCell>
                      <TableCell><div className="h-8 bg-muted/50 rounded-lg w-16 ml-auto"></div></TableCell>
                    </TableRow>
                  ))
                ) : filteredProviders.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="h-32 text-center text-muted-foreground">
                      Aucun couvreur trouvé.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredProviders.map((provider) => (
                    <React.Fragment key={provider.id}>
                      <TableRow 
                        className={`cursor-pointer transition-colors hover:bg-muted/30 ${expandedId === provider.id ? 'bg-muted/20' : ''}`}
                        onClick={() => toggleExpand(provider.id)}
                      >
                        <TableCell>
                          <div className="font-semibold text-foreground">{provider.name}</div>
                          <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                            <Star className="w-3 h-3 fill-orange-400 text-orange-400" />
                            {provider.rating?.toFixed(1) || 'Nouveau'} • {provider.totalMissions} missions
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col gap-1 text-sm">
                            <span className="flex items-center text-muted-foreground"><Phone className="w-3 h-3 mr-2" />{provider.phone}</span>
                            <span className="flex items-center text-muted-foreground"><Mail className="w-3 h-3 mr-2" />{provider.email}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          {provider.zone ? (
                            <Badge variant="outline" className="bg-background text-xs font-normal"><MapPin className="w-3 h-3 mr-1 text-primary" /> {provider.zone}</Badge>
                          ) : <span className="text-muted-foreground text-xs">-</span>}
                        </TableCell>
                        <TableCell>
                          <ProviderStatusBadge status={provider.status} />
                        </TableCell>
                        <TableCell className="text-center">
                          <Switch 
                            checked={provider.isAvailable} 
                            onCheckedChange={() => {}} 
                            onClick={(e) => toggleAvailability(provider.id, provider.isAvailable, e)}
                            className="data-[state=checked]:bg-green-500"
                          />
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-amber-600 hover:text-amber-700 hover:bg-amber-50 rounded-lg" title="Définir le mot de passe" onClick={(e) => { e.stopPropagation(); setPasswordProvider({ id: provider.id, name: provider.name, email: provider.email }); setNewPassword(""); setShowPassword(false); }}>
                              <KeyRound className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg" onClick={(e) => openEdit(provider, e)}>
                              <Pencil className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg" onClick={(e) => openDelete(provider.id, e)}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                      
                      {/* Expandable Details */}
                      <AnimatePresence>
                        {expandedId === provider.id && (
                          <TableRow className="bg-muted/10 hover:bg-muted/10 border-b-0">
                            <TableCell colSpan={6} className="p-0">
                              <motion.div 
                                initial={{ height: 0, opacity: 0 }}
                                animate={{ height: 'auto', opacity: 1 }}
                                exit={{ height: 0, opacity: 0 }}
                                className="overflow-hidden"
                              >
                                <div className="p-6 border-t border-border/40 shadow-inner bg-background/50 grid grid-cols-1 md:grid-cols-3 gap-6">
                                  <div>
                                    <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2"><Briefcase className="w-4 h-4" /> Spécialités</h4>
                                    {provider.specialties?.length ? (
                                      <div className="space-y-2">
                                        {["depannage","remorquage","panne_batterie","crevaison","accident","autre"].some(v => provider.specialties.includes(v)) && (
                                          <div className="flex flex-wrap gap-1.5">
                                            {provider.specialties.filter((s: string) => INTERVENTION_OPTIONS.some(o => o.value === s)).map((s: string) => (
                                              <Badge key={s} variant="secondary" className="bg-blue-50 text-blue-700 hover:bg-blue-50 text-xs font-normal">
                                                <Wrench className="w-3 h-3 mr-1" />{SPECIALTY_LABELS[s] || s}
                                              </Badge>
                                            ))}
                                          </div>
                                        )}
                                        {["vl","pl","moto","utilitaire"].some(v => provider.specialties.includes(v)) && (
                                          <div className="flex flex-wrap gap-1.5">
                                            {provider.specialties.filter((s: string) => VEHICLE_OPTIONS.some(o => o.value === s)).map((s: string) => (
                                              <Badge key={s} variant="secondary" className="bg-orange-50 text-orange-700 hover:bg-orange-50 text-xs font-normal">
                                                <Car className="w-3 h-3 mr-1" />{SPECIALTY_LABELS[s] || s}
                                              </Badge>
                                            ))}
                                          </div>
                                        )}
                                      </div>
                                    ) : <span className="text-sm text-muted-foreground italic">Aucune spécialité définie</span>}
                                  </div>
                                  
                                  <div className="space-y-3">
                                    <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2"><Map className="w-4 h-4" /> Adresse</h4>
                                    <p className="text-sm text-foreground">{provider.address || <span className="italic text-muted-foreground">Non renseignée</span>}</p>
                                    {/* Storage info */}
                                    <div className="mt-4">
                                      <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-2"><Warehouse className="w-4 h-4" /> Stockage</h4>
                                      {provider.storageType ? (
                                        <div className="space-y-1">
                                          <Badge variant="secondary" className="bg-purple-50 text-purple-700 hover:bg-purple-50 text-xs font-normal">
                                            <Warehouse className="w-3 h-3 mr-1" />
                                            {provider.storageType === "interieur" ? "Intérieur" : provider.storageType === "exterieur" ? "Extérieur" : "Intérieur & Extérieur"}
                                          </Badge>
                                          <div className="flex gap-3 text-xs text-muted-foreground mt-1">
                                            {provider.storageCapacity && <span>{provider.storageCapacity} places</span>}
                                            {provider.storagePricePerDay != null && <span>{formatCurrency(provider.storagePricePerDay)}/jour</span>}
                                          </div>
                                          {provider.storageAddress && (
                                            <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                                              <MapPin className="w-3 h-3 flex-shrink-0" />{provider.storageAddress}
                                            </p>
                                          )}
                                        </div>
                                      ) : (
                                        <span className="text-sm text-muted-foreground italic">Pas de stockage</span>
                                      )}
                                    </div>
                                  </div>

                                  <div className="space-y-3">
                                    <div className="bg-card border border-border/50 rounded-xl p-4 shadow-sm flex items-center justify-between">
                                      <div>
                                        <p className="text-sm font-medium text-muted-foreground">Revenus générés</p>
                                        <p className="text-2xl font-bold text-foreground mt-1">{formatCurrency(provider.totalRevenue)}</p>
                                      </div>
                                      <div className="bg-green-100 p-3 rounded-full">
                                        <Euro className="w-6 h-6 text-green-600" />
                                      </div>
                                    </div>
                                    <RatingEditor provider={provider} />
                                    {provider.equipmentPhoto && (
                                      <div className="bg-card border border-border/50 rounded-xl p-4 shadow-sm">
                                        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-2"><Car className="w-4 h-4" /> Photo matériel</p>
                                        <img src={provider.equipmentPhoto?.startsWith("http") ? provider.equipmentPhoto : `/api/storage/objects/${provider.equipmentPhoto?.startsWith("/objects/") ? provider.equipmentPhoto.slice("/objects/".length) : provider.equipmentPhoto}`} alt="Dépanneuse" className="w-full h-32 object-cover rounded-lg" />
                                      </div>
                                    )}
                                    {provider.insuranceDocument && (
                                      <div className="bg-card border border-border/50 rounded-xl p-4 shadow-sm">
                                        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Assurance</p>
                                        <a href={provider.insuranceDocument?.startsWith("http") ? provider.insuranceDocument : `/api/storage/objects/${provider.insuranceDocument?.startsWith("/objects/") ? provider.insuranceDocument.slice("/objects/".length) : provider.insuranceDocument}`} target="_blank" rel="noopener noreferrer" className="text-sm text-primary hover:underline">Voir le document</a>
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </motion.div>
                            </TableCell>
                          </TableRow>
                        )}
                      </AnimatePresence>
                    </React.Fragment>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </Card>
      </div>

      {/* Create/Edit Dialog */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="sm:max-w-[580px] p-0 rounded-2xl border-border/50 shadow-2xl max-h-[90vh] flex flex-col overflow-hidden">
          <DialogHeader className="p-6 pb-0">
            <DialogTitle className="text-2xl font-display">{selectedId ? "Modifier le couvreur" : "Nouveau couvreur"}</DialogTitle>
            <DialogDescription>
              {selectedId ? "Modifiez les informations du couvreur ci-dessous." : "Ajoutez un nouveau couvreur à votre réseau."}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="p-6 pt-4 space-y-4 overflow-y-auto flex-1">
              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="name" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Nom complet / Entreprise</FormLabel>
                    <FormControl><Input placeholder="Garage Dupont" {...field} className="rounded-xl" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="email" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl><Input placeholder="contact@garage.fr" type="email" {...field} className="rounded-xl" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="phone" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Téléphone</FormLabel>
                    <FormControl><Input placeholder="06 12 34 56 78" {...field} className="rounded-xl" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="zone" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Zone (Ville/Département)</FormLabel>
                    <FormControl><Input placeholder="Paris (75)" {...field} className="rounded-xl" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="status" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Statut</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl><SelectTrigger className="rounded-xl"><SelectValue placeholder="Sélectionnez" /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="active">Actif</SelectItem>
                        <SelectItem value="inactive">Inactif</SelectItem>
                        <SelectItem value="suspended">Suspendu</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="address" render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Adresse postale</FormLabel>
                    <FormControl><Input placeholder="123 rue de la mécanique..." {...field} className="rounded-xl" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              <CompanySearchSection form={form} />

              <div className="border border-border/50 rounded-xl p-4 space-y-4 bg-muted/20">
                <p className="text-sm font-semibold flex items-center gap-2">
                  <Building className="w-4 h-4 text-primary" /> Informations légales
                </p>
                <div className="grid grid-cols-2 gap-4">
                  <FormField control={form.control} name="companyName" render={({ field }) => (
                    <FormItem className="col-span-2">
                      <FormLabel>Raison sociale</FormLabel>
                      <FormControl><Input placeholder="Ex: SARL Couverture Dupont" {...field} className="rounded-xl" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="siret" render={({ field }) => (
                    <FormItem>
                      <FormLabel>SIRET</FormLabel>
                      <FormControl><Input placeholder="Ex: 123 456 789 00012" {...field} className="rounded-xl" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="tvaNumber" render={({ field }) => (
                    <FormItem>
                      <FormLabel>N° TVA intracommunautaire</FormLabel>
                      <FormControl><Input placeholder="Ex: FR12345678901" {...field} className="rounded-xl" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="isSubjectToTva" render={({ field }) => (
                    <FormItem className="col-span-2 flex items-center gap-3">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          className="rounded-md"
                        />
                      </FormControl>
                      <FormLabel className="!mt-0 cursor-pointer">Assujetti à la TVA</FormLabel>
                      <FormMessage />
                    </FormItem>
                  )} />
                </div>
              </div>

              {/* Specialties */}
              <FormField control={form.control} name="specialties" render={({ field }) => (
                <FormItem>
                  <div className="border border-border/50 rounded-xl p-4 space-y-4 bg-muted/20">
                    <div>
                      <p className="text-sm font-semibold flex items-center gap-2 mb-3">
                        <Wrench className="w-4 h-4 text-primary" /> Types d'intervention
                      </p>
                      <div className="grid grid-cols-2 gap-2">
                        {INTERVENTION_OPTIONS.map(opt => (
                          <label key={opt.value} className="flex items-center gap-2.5 cursor-pointer group">
                            <Checkbox
                              checked={field.value?.includes(opt.value)}
                              onCheckedChange={(checked) => {
                                const current = field.value || [];
                                field.onChange(
                                  checked ? [...current, opt.value] : current.filter(v => v !== opt.value)
                                );
                              }}
                              className="rounded-md"
                            />
                            <span className="text-sm group-hover:text-foreground transition-colors text-muted-foreground">{opt.label}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                    <div className="border-t border-border/40 pt-4">
                      <p className="text-sm font-semibold flex items-center gap-2 mb-3">
                        <Car className="w-4 h-4 text-primary" /> Types de véhicules pris en charge
                      </p>
                      <div className="grid grid-cols-2 gap-2">
                        {VEHICLE_OPTIONS.map(opt => (
                          <label key={opt.value} className="flex items-center gap-2.5 cursor-pointer group">
                            <Checkbox
                              checked={field.value?.includes(opt.value)}
                              onCheckedChange={(checked) => {
                                const current = field.value || [];
                                field.onChange(
                                  checked ? [...current, opt.value] : current.filter(v => v !== opt.value)
                                );
                              }}
                              className="rounded-md"
                            />
                            <span className="text-sm group-hover:text-foreground transition-colors text-muted-foreground">{opt.label}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                  <FormMessage />
                </FormItem>
              )} />
              
              {/* Payment methods */}
              <FormField control={form.control} name="acceptedPaymentMethods" render={({ field }) => (
                <FormItem>
                  <div className="border border-border/50 rounded-xl p-4 space-y-3 bg-muted/20">
                    <p className="text-sm font-semibold flex items-center gap-2">
                      <CreditCard className="w-4 h-4 text-primary" /> Modes de paiement acceptés
                    </p>
                    <div className="grid grid-cols-2 gap-2">
                      {PAYMENT_METHOD_OPTIONS.map(opt => (
                        <label key={opt.value} className="flex items-center gap-2.5 cursor-pointer group">
                          <Checkbox
                            checked={field.value?.includes(opt.value)}
                            onCheckedChange={(checked) => {
                              const current = field.value || [];
                              field.onChange(
                                checked ? [...current, opt.value] : current.filter(v => v !== opt.value)
                              );
                            }}
                            className="rounded-md"
                          />
                          <span className="text-sm group-hover:text-foreground transition-colors text-muted-foreground">{opt.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                  <FormMessage />
                </FormItem>
              )} />

              {/* Storage section */}
              <div className="border border-border/50 rounded-xl p-4 space-y-4 bg-muted/20">
                <p className="text-sm font-semibold flex items-center gap-2">
                  <Warehouse className="w-4 h-4 text-primary" /> Lieu de stockage
                </p>
                <FormField control={form.control} name="storageType" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Type de stockage</FormLabel>
                    <Select onValueChange={(v) => field.onChange(v === "aucun" ? null : v)} value={field.value ?? "aucun"}>
                      <FormControl>
                        <SelectTrigger className="rounded-xl">
                          <SelectValue placeholder="Aucun stockage" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="aucun">Aucun stockage</SelectItem>
                        <SelectItem value="interieur">Intérieur</SelectItem>
                        <SelectItem value="exterieur">Extérieur</SelectItem>
                        <SelectItem value="les_deux">Intérieur &amp; Extérieur</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                {form.watch("storageType") && (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField control={form.control} name="storageCapacity" render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nombre de places max.</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min={1}
                              placeholder="ex: 10"
                              className="rounded-xl"
                              value={field.value ?? ""}
                              onChange={(e) => field.onChange(e.target.value === "" ? null : Number(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />
                      <FormField control={form.control} name="storagePricePerDay" render={({ field }) => (
                        <FormItem>
                          <FormLabel>Prix / jour (€)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min={0}
                              step="0.01"
                              placeholder="ex: 25.00"
                              className="rounded-xl"
                              value={field.value ?? ""}
                              onChange={(e) => field.onChange(e.target.value === "" ? null : Number(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />
                    </div>
                    <FormField control={form.control} name="storageAddress" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Adresse du dépôt</FormLabel>
                        <FormControl>
                          <AddressAutocomplete
                            value={field.value || ""}
                            onChange={field.onChange}
                            placeholder="Adresse du lieu de stockage..."
                            className="rounded-xl"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )} />
                  </div>
                )}
              </div>

              <div className="pt-4 border-t border-border/40 mt-6 flex justify-end gap-3">
                <Button type="button" variant="outline" onClick={() => setIsFormOpen(false)} className="rounded-xl">Annuler</Button>
                <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending} className="bg-primary hover:bg-primary/90 text-white rounded-xl shadow-md shadow-primary/20">
                  {selectedId ? "Mettre à jour" : "Créer le couvreur"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <DialogContent className="sm:max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle>Confirmer la suppression</DialogTitle>
            <DialogDescription>
              Êtes-vous sûr de vouloir supprimer ce couvreur ? Cette action est irréversible et supprimera également son accès.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-6 flex gap-3 sm:justify-end">
            <Button variant="outline" onClick={() => setIsDeleteOpen(false)} className="rounded-xl">Annuler</Button>
            <Button variant="destructive" onClick={handleDelete} disabled={deleteMutation.isPending} className="rounded-xl shadow-md shadow-red-500/20">
              {deleteMutation.isPending ? "Suppression..." : "Oui, supprimer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Password Dialog */}
      <Dialog open={!!passwordProvider} onOpenChange={(open) => !open && setPasswordProvider(null)}>
        <DialogContent className="sm:max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <KeyRound className="w-5 h-5 text-amber-500" />
              Définir le mot de passe
            </DialogTitle>
            <DialogDescription>
              Nouveau mot de passe pour le couvreur <strong>{passwordProvider?.name}</strong>. Il sera utilisé pour se connecter à l'espace couvreur.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-2 space-y-4">
            {passwordProvider?.email && providers.filter(p => p.email === passwordProvider.email).length > 1 && (
              <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3 text-sm text-amber-700">
                <strong>Attention :</strong> L'email <strong>{passwordProvider.email}</strong> est partagé par {providers.filter(p => p.email === passwordProvider.email).length} prestataires. Chaque prestataire doit avoir un email unique pour pouvoir se connecter. Pensez à modifier l'email de ce couvreur.
              </div>
            )}
            <div className="relative">
              <Input
                type={showPassword ? "text" : "password"}
                placeholder="Nouveau mot de passe (min. 6 caractères)"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="rounded-xl pr-10"
                onKeyDown={(e) => e.key === "Enter" && handleSetPassword()}
              />
              <button
                type="button"
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
          <DialogFooter className="mt-4 flex gap-3 sm:justify-end">
            <Button variant="outline" onClick={() => setPasswordProvider(null)} className="rounded-xl">Annuler</Button>
            <Button
              onClick={handleSetPassword}
              disabled={isSettingPassword || !newPassword}
              className="bg-amber-500 hover:bg-amber-600 text-white rounded-xl shadow-md shadow-amber-500/20"
            >
              {isSettingPassword ? "Enregistrement..." : "Enregistrer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </Layout>
  );
}

function RatingEditor({ provider }: { provider: any }) {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(provider.rating?.toString() || "");
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const updateMutation = useUpdateProvider();

  const handleSave = async () => {
    const num = parseFloat(value);
    if (value && (isNaN(num) || num < 0 || num > 5)) {
      toast({ title: "Erreur", description: "La note doit être entre 0 et 5.", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await updateMutation.mutateAsync({ id: provider.id, data: { rating: value ? num : null } });
      toast({ title: "Succès", description: "Note mise à jour." });
      setEditing(false);
      queryClient.invalidateQueries({ queryKey: ["/api/providers"] });
    } catch {
      toast({ title: "Erreur", description: "Impossible de sauvegarder.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="bg-card border border-border/50 rounded-xl p-4 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Star className="w-5 h-5 fill-orange-400 text-orange-400" />
          <span className="text-sm font-semibold text-muted-foreground">Note</span>
        </div>
        {!editing ? (
          <div className="flex items-center gap-2">
            <span className="text-lg font-bold">{provider.rating?.toFixed(1) || "N/A"}</span>
            <span className="text-xs text-muted-foreground">/ 5</span>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => { setValue(provider.rating?.toString() || ""); setEditing(true); }}>
              <Pencil className="w-3 h-3 mr-1" /> Modifier
            </Button>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <Input
              type="number"
              step="0.1"
              min="0"
              max="5"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              className="w-20 h-8 text-sm rounded-lg"
              placeholder="0-5"
            />
            <Button size="sm" className="h-7 px-2 text-xs" onClick={handleSave} disabled={saving}>
              {saving ? "..." : "OK"}
            </Button>
            <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => setEditing(false)}>✕</Button>
          </div>
        )}
      </div>
    </div>
  );
}
