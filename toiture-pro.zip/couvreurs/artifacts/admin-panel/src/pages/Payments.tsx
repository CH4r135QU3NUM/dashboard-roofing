import { Layout } from "@/components/Layout";
import { useGetPayments, useGetPaymentSummary } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { formatCurrency, formatDateTime } from "@/lib/format";
import { Euro, Percent, Banknote, History, CreditCard, Eye, MapPin, Car, User, FileText, CheckCircle2, ImageIcon, Download } from "lucide-react";
import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

const PAYMENT_METHOD_LABELS: Record<string, string> = {
  cash: "Espèces",
  especes: "Espèces",
  virement: "Virement",
  carte_bancaire: "Carte bancaire",
  cheque: "Chèque",
  compensation: "Compensation",
  card: "Carte",
  stripe: "Stripe",
  paypal: "PayPal",
};

const PAYMENT_STATUS_OPTIONS = [
  { value: "pending", label: "En attente" },
  { value: "paid", label: "Payé" },
  { value: "failed", label: "Échoué" },
  { value: "refunded", label: "Remboursé" },
];

const COMMISSION_STATUS_OPTIONS = [
  { value: "pending", label: "À payer" },
  { value: "paid", label: "Réglée" },
];

export default function Payments() {
  const [searchTerm, setSearchTerm] = useState("");
  const [detailPayment, setDetailPayment] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: summary } = useGetPaymentSummary({}, {
    query: { refetchInterval: 30_000, refetchOnWindowFocus: true, staleTime: 0 },
  });
  const { data: paymentsData, isLoading } = useGetPayments({}, {
    query: { refetchInterval: 30_000, refetchOnWindowFocus: true, staleTime: 0 },
  });

  const payments = (paymentsData?.payments || []) as any[];
  const filtered = payments.filter((p: any) => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      (p.providerName || "").toLowerCase().includes(term) ||
      `#${p.missionId}`.includes(term) ||
      (p.reference || "").toLowerCase().includes(term)
    );
  });

  const totalCommission = payments.reduce((sum: number, p: any) => sum + (p.commissionAmount || 0), 0);
  const paidCommission = payments.filter((p: any) => p.commissionStatus === "paid").reduce((sum: number, p: any) => sum + (p.commissionAmount || 0), 0);
  const pendingCommission = totalCommission - paidCommission;

  const handleChangePaymentStatus = async (paymentId: number, status: string) => {
    try {
      const res = await fetch(`/api/payments/${paymentId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (!res.ok) throw new Error();
      toast({ title: "Statut mis à jour", description: `Paiement marqué comme "${PAYMENT_STATUS_OPTIONS.find(o => o.value === status)?.label}".` });
      queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
    } catch {
      toast({ title: "Erreur", description: "Impossible de modifier le statut.", variant: "destructive" });
    }
  };

  const handleChangeCommissionStatus = async (paymentId: number, commissionStatus: string) => {
    try {
      const res = await fetch(`/api/payments/${paymentId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ commissionStatus }),
      });
      if (!res.ok) throw new Error();
      toast({ title: "Commission mise à jour", description: `Commission marquée comme "${COMMISSION_STATUS_OPTIONS.find(o => o.value === commissionStatus)?.label}".` });
      queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/payments/summary"] });
    } catch {
      toast({ title: "Erreur", description: "Impossible de modifier le statut de la commission.", variant: "destructive" });
    }
  };

  const getStorageUrl = (path: string) => {
    if (!path) return "";
    const cleaned = path.startsWith("/objects/") ? path.slice("/objects/".length) : path;
    return `/api/storage/${cleaned}`;
  };

  return (
    <Layout>
      <div className="flex flex-col gap-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold">Paiements & Commissions</h1>
            <p className="text-muted-foreground mt-1">Suivi des commissions de 20% sur chaque dépannage terminé.</p>
          </div>
          <Button
            variant="outline"
            className="rounded-xl gap-2"
            onClick={() => {
              const now = new Date();
              const url = `/api/reports/admin/monthly?year=${now.getFullYear()}&month=${now.getMonth() + 1}`;
              window.open(url, "_blank");
            }}
          >
            <Download className="w-4 h-4" />
            Exporter rapport mensuel
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="rounded-2xl border-none shadow-lg shadow-black/5">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-3">
                <p className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Total Revenus</p>
                <div className="p-2 rounded-full bg-primary/10"><Euro className="w-5 h-5 text-primary" /></div>
              </div>
              <h3 className="text-3xl font-display font-bold">{formatCurrency(summary?.totalRevenue || 0)}</h3>
            </CardContent>
          </Card>
          <Card className="rounded-2xl border-none shadow-lg shadow-black/5">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-3">
                <p className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Commission Totale</p>
                <div className="p-2 rounded-full bg-red-500/10"><Percent className="w-5 h-5 text-red-500" /></div>
              </div>
              <h3 className="text-3xl font-display font-bold text-red-600">{formatCurrency(totalCommission)}</h3>
            </CardContent>
          </Card>
          <Card className="rounded-2xl border-none shadow-lg shadow-black/5">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-3">
                <p className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Commission Perçue</p>
                <div className="p-2 rounded-full bg-green-500/10"><Banknote className="w-5 h-5 text-green-500" /></div>
              </div>
              <h3 className="text-3xl font-display font-bold text-green-600">{formatCurrency(paidCommission)}</h3>
            </CardContent>
          </Card>
          <Card className="rounded-2xl border-none shadow-lg shadow-black/5">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-3">
                <p className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Commission En Attente</p>
                <div className="p-2 rounded-full bg-orange-500/10"><History className="w-5 h-5 text-orange-500" /></div>
              </div>
              <h3 className="text-3xl font-display font-bold text-orange-600">{formatCurrency(pendingCommission)}</h3>
            </CardContent>
          </Card>
        </div>

        <Card className="rounded-2xl border-border/50 shadow-lg shadow-black/5 overflow-hidden">
          <CardHeader className="bg-muted/30 border-b border-border/50">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <CardTitle className="flex items-center gap-2 text-lg">
                <CreditCard className="w-5 h-5 text-primary" />
                Détail des commissions
              </CardTitle>
              <div className="relative w-full sm:w-72">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Rechercher prestataire, mission..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 bg-background border-border/50 rounded-xl"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-8 space-y-4">
                {[1,2,3,4,5].map(i => <div key={i} className="h-12 bg-muted/40 animate-pulse rounded-lg"></div>)}
              </div>
            ) : filtered.length === 0 ? (
              <div className="p-12 text-center text-muted-foreground">Aucun paiement trouvé.</div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/10 hover:bg-muted/10">
                      <TableHead className="font-semibold text-foreground">Date</TableHead>
                      <TableHead className="font-semibold text-foreground">Prestataire</TableHead>
                      <TableHead className="font-semibold text-foreground">Mission</TableHead>
                      <TableHead className="font-semibold text-foreground">Méthode</TableHead>
                      <TableHead className="font-semibold text-foreground text-right">Montant</TableHead>
                      <TableHead className="font-semibold text-foreground text-right">Commission (20%)</TableHead>
                      <TableHead className="font-semibold text-foreground text-center">Statut Paiement</TableHead>
                      <TableHead className="font-semibold text-foreground text-center">Statut Commission</TableHead>
                      <TableHead className="font-semibold text-foreground text-center">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered.map((payment: any) => (
                      <TableRow key={payment.id} className="hover:bg-muted/30 transition-colors">
                        <TableCell className="text-muted-foreground whitespace-nowrap text-sm">
                          {formatDateTime(payment.createdAt)}
                        </TableCell>
                        <TableCell className="font-medium">{payment.providerName || "-"}</TableCell>
                        <TableCell>
                          {payment.missionId ? <span className="font-mono text-sm">#{payment.missionId}</span> : "-"}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-xs font-medium">
                            {PAYMENT_METHOD_LABELS[payment.method] || payment.method}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right font-bold">{formatCurrency(payment.amount)}</TableCell>
                        <TableCell className="text-right font-semibold text-red-600">
                          {payment.commissionAmount ? formatCurrency(payment.commissionAmount) : "-"}
                        </TableCell>
                        <TableCell className="text-center">
                          <Select
                            value={payment.status}
                            onValueChange={(val) => handleChangePaymentStatus(payment.id, val)}
                          >
                            <SelectTrigger className="h-7 w-[120px] mx-auto text-xs rounded-lg">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {PAYMENT_STATUS_OPTIONS.map(opt => (
                                <SelectItem key={opt.value} value={opt.value} className="text-xs">{opt.label}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell className="text-center">
                          <Select
                            value={payment.commissionStatus || "pending"}
                            onValueChange={(val) => handleChangeCommissionStatus(payment.id, val)}
                          >
                            <SelectTrigger className="h-7 w-[110px] mx-auto text-xs rounded-lg">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {COMMISSION_STATUS_OPTIONS.map(opt => (
                                <SelectItem key={opt.value} value={opt.value} className="text-xs">{opt.label}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell className="text-center">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => setDetailPayment(payment)}
                            title="Voir le détail"
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={!!detailPayment} onOpenChange={() => setDetailPayment(null)}>
        <DialogContent className="max-w-lg rounded-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" />
              Détail du paiement #{detailPayment?.id}
            </DialogTitle>
          </DialogHeader>
          {detailPayment && <PaymentDetailContent payment={detailPayment} getStorageUrl={getStorageUrl} />}
        </DialogContent>
      </Dialog>
    </Layout>
  );
}

function PaymentDetailContent({ payment, getStorageUrl }: { payment: any; getStorageUrl: (path: string) => string }) {
  const [missionDetail, setMissionDetail] = useState<any>(null);
  const [loadingMission, setLoadingMission] = useState(false);

  useEffect(() => {
    if (!payment.missionId) return;
    setLoadingMission(true);
    fetch(`/api/missions/${payment.missionId}`)
      .then(res => res.ok ? res.json() : null)
      .then(data => { if (data) setMissionDetail(data); })
      .catch(() => {})
      .finally(() => setLoadingMission(false));
  }, [payment.missionId]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Prestataire</p>
          <p className="font-semibold flex items-center gap-1.5"><User className="w-3.5 h-3.5 text-muted-foreground" /> {payment.providerName || "-"}</p>
        </div>
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Mission</p>
          <p className="font-mono font-semibold">#{payment.missionId || "-"}</p>
        </div>
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Montant</p>
          <p className="font-bold text-lg">{formatCurrency(payment.amount)}</p>
        </div>
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Commission (20%)</p>
          <p className="font-bold text-lg text-red-600">{payment.commissionAmount ? formatCurrency(payment.commissionAmount) : "-"}</p>
        </div>
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Méthode</p>
          <Badge variant="outline" className="text-xs">{PAYMENT_METHOD_LABELS[payment.method] || payment.method}</Badge>
        </div>
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Date</p>
          <p className="text-sm">{formatDateTime(payment.createdAt)}</p>
        </div>
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Statut paiement</p>
          <PaymentStatusBadge status={payment.status} />
        </div>
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Statut commission</p>
          <CommissionStatusBadge status={payment.commissionStatus} />
        </div>
      </div>

      {payment.commissionProof && (
        <div className="space-y-2 pt-2 border-t">
          <p className="text-xs text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
            <ImageIcon className="w-3.5 h-3.5" /> Justificatif de commission
          </p>
          <a
            href={getStorageUrl(payment.commissionProof)}
            target="_blank"
            rel="noopener noreferrer"
            className="block"
          >
            <img
              src={getStorageUrl(payment.commissionProof)}
              alt="Justificatif"
              className="max-h-48 rounded-lg border object-contain"
            />
          </a>
        </div>
      )}

      {missionDetail && (
        <div className="pt-2 border-t space-y-3">
          <p className="text-sm font-semibold flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-primary" /> Détail de la mission
          </p>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Client</p>
              <p className="font-medium flex items-center gap-1"><User className="w-3 h-3" /> {missionDetail.clientName}</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Téléphone</p>
              <p className="font-medium">{missionDetail.clientPhone}</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Véhicule</p>
              <p className="font-medium flex items-center gap-1"><Car className="w-3 h-3" /> {missionDetail.vehicleMake} {missionDetail.vehicleModel}</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Plaque</p>
              <p className="font-mono font-medium">{missionDetail.vehiclePlate}</p>
            </div>
            <div className="col-span-2 space-y-1">
              <p className="text-xs text-muted-foreground">Adresse</p>
              <p className="font-medium flex items-center gap-1"><MapPin className="w-3 h-3" /> {missionDetail.locationAddress}</p>
            </div>
            {missionDetail.deliveryAddress && (
              <div className="col-span-2 space-y-1">
                <p className="text-xs text-muted-foreground">Livraison</p>
                <p className="font-medium flex items-center gap-1"><MapPin className="w-3 h-3" /> {missionDetail.deliveryAddress}</p>
              </div>
            )}
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Statut</p>
              <Badge variant="outline" className="text-xs">{missionDetail.status}</Badge>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Type</p>
              <p className="font-medium capitalize">{missionDetail.interventionType?.replace(/_/g, " ")}</p>
            </div>
            {missionDetail.notes && (
              <div className="col-span-2 space-y-1">
                <p className="text-xs text-muted-foreground">Notes</p>
                <p className="text-sm bg-muted/30 rounded-lg p-2">{missionDetail.notes}</p>
              </div>
            )}
            {missionDetail.completedAt && (
              <div className="col-span-2 space-y-1">
                <p className="text-xs text-muted-foreground">Terminée le</p>
                <p className="text-sm flex items-center gap-1"><CheckCircle2 className="w-3 h-3 text-green-500" /> {formatDateTime(missionDetail.completedAt)}</p>
              </div>
            )}
          </div>
        </div>
      )}

      {loadingMission && (
        <div className="text-center py-4 text-muted-foreground text-sm">Chargement des détails de la mission...</div>
      )}
    </div>
  );
}

function PaymentStatusBadge({ status }: { status: string }) {
  switch (status) {
    case 'paid':
      return <Badge className="bg-green-500/10 text-green-700 hover:bg-green-500/20 border-green-500/20 font-medium">Payé</Badge>;
    case 'pending':
      return <Badge className="bg-orange-500/10 text-orange-700 hover:bg-orange-500/20 border-orange-500/20 font-medium">En attente</Badge>;
    case 'failed':
      return <Badge variant="destructive">Échoué</Badge>;
    case 'refunded':
      return <Badge variant="secondary">Remboursé</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
}

function CommissionStatusBadge({ status }: { status: string | null }) {
  if (!status) return <span className="text-muted-foreground text-xs">-</span>;
  switch (status) {
    case 'paid':
      return <Badge className="bg-green-500/10 text-green-700 hover:bg-green-500/20 border-green-500/20 text-xs">Réglée</Badge>;
    case 'pending':
      return <Badge className="bg-orange-500/10 text-orange-700 hover:bg-orange-500/20 border-orange-500/20 text-xs">À payer</Badge>;
    default:
      return <Badge variant="outline" className="text-xs">{status}</Badge>;
  }
}
