import { useState, useRef } from "react";
import { Layout } from "@/components/Layout";
import { useGetMissions, useCreateMission, useAssignMission, useUpdateMission, useGetProviders } from "@workspace/api-client-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MissionStatusBadge, MissionPriorityBadge, formatDateTime, InterventionIcon, getInterventionLabel, getRoofTypeLabel, formatCurrency } from "@/lib/format";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, MapPin, User, CalendarClock, ClipboardList, Pencil, CheckCircle2, Loader2, Radio, Copy, Check, Trash2, Eye, EyeOff, Calculator, MessageCircle, Home } from "lucide-react";
import { AddressAutocomplete } from "@/components/AddressAutocomplete";
import { FileUploadZone, type FileUploadZoneRef } from "@/components/FileUploadZone";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

const TABS = [
  { id: "all", label: "Tous" },
  { id: "pending", label: "En attente" },
  { id: "confirmed", label: "Confirmés" },
  { id: "in_progress", label: "En cours" },
  { id: "completed", label: "Terminés" },
  { id: "cancelled", label: "Annulés" },
];

const ROOF_TYPES = [
  { value: "tuiles_terre_cuite", label: "Tuiles terre cuite" },
  { value: "tuiles_beton",       label: "Tuiles béton" },
  { value: "ardoise",            label: "Ardoise" },
  { value: "zinc",               label: "Zinc" },
  { value: "bac_acier",          label: "Bac acier" },
  { value: "bitume",             label: "Bitume" },
  { value: "chaume",             label: "Chaume" },
  { value: "autre",              label: "Autre" },
];

const INTERVENTION_TYPES = [
  { value: "reparation_fuite",    label: "Réparation fuite" },
  { value: "remplacement_tuiles", label: "Remplacement tuiles" },
  { value: "renovation_complete", label: "Rénovation complète" },
  { value: "nettoyage_toiture",   label: "Nettoyage / traitement" },
  { value: "pose_velux",          label: "Pose Velux" },
  { value: "isolation_combles",   label: "Isolation combles" },
  { value: "autre",               label: "Autre" },
];

const CLIENT_PAYMENT_METHODS = [
  { value: "especes",        label: "Espèces" },
  { value: "virement",       label: "Virement" },
  { value: "carte_bancaire", label: "Carte bancaire" },
  { value: "cheque",         label: "Chèque" },
  { value: "acompte",        label: "Acompte" },
];

function isNonFrenchPhone(phone: string): boolean {
  const c = phone.replace(/\s+/g, "").replace(/-/g, "");
  if (c.startsWith("+33") || c.startsWith("0033")) return false;
  return c.startsWith("+") || c.startsWith("00");
}
function getWhatsAppUrl(phone: string): string {
  let c = phone.replace(/\s+/g, "").replace(/-/g, "");
  if (c.startsWith("+")) c = c.slice(1);
  if (c.startsWith("00")) c = c.slice(2);
  return `https://wa.me/${c}`;
}

const createSchema = z.object({
  clientName:          z.string().min(2, "Requis"),
  clientPhone:         z.string().min(8, "Requis"),
  roofType:            z.string().optional(),
  roofTypeOther:       z.string().optional(),
  roofSurface:         z.coerce.number().optional().or(z.literal("")),
  roofAge:             z.coerce.number().optional().or(z.literal("")),
  interventionType:    z.enum(["reparation_fuite","remplacement_tuiles","renovation_complete","nettoyage_toiture","pose_velux","isolation_combles","autre"]),
  description:         z.string().min(5, "Description requise"),
  locationAddress:     z.string().min(5, "Adresse requise"),
  priority:            z.enum(["low","normal","high","urgent"]),
  scheduledAt:         z.string().min(1, "Date requise"),
  amount:              z.coerce.number().optional().or(z.literal("")),
  clientPaymentMethod: z.string().optional(),
});

const editSchema = createSchema.extend({
  status: z.enum(["pending","confirmed","in_progress","completed","cancelled"]),
  notes:            z.string().optional(),
  estimatedDuration: z.coerce.number().optional(),
});

type EditFormValues = z.infer<typeof editSchema>;

function PriceSimulator({ onApply }: { onApply: (price: number) => void }) {
  const [surface, setSurface] = useState("");
  const [type, setType] = useState("reparation_fuite");
  const [result, setResult] = useState<{ priceMin: number; priceMax: number; priceAvg: number; label: string; unit: string } | null>(null);
  const [loading, setLoading] = useState(false);

  const calculate = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/missions/simulate-price", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ surfaceM2: Number(surface), interventionType: type }),
      });
      const data = await res.json();
      setResult(data);
    } catch {} finally { setLoading(false); }
  };

  return (
    <div className="bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800/50 rounded-xl p-4 space-y-3">
      <p className="text-sm font-semibold text-blue-700 dark:text-blue-400 flex items-center gap-2">
        <Calculator className="w-4 h-4" /> Estimation de prix
      </p>
      <div className="grid grid-cols-3 gap-3">
        <div>
          <label className="text-xs text-muted-foreground block mb-1">Surface (m² ou nb Velux)</label>
          <Input type="number" value={surface} onChange={e => setSurface(e.target.value)} placeholder="ex: 80" className="rounded-lg h-9 text-sm" />
        </div>
        <div>
          <label className="text-xs text-muted-foreground block mb-1">Type de travaux</label>
          <select value={type} onChange={e => setType(e.target.value)} className="w-full rounded-lg h-9 text-sm border border-input bg-background px-2">
            {INTERVENTION_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
          </select>
        </div>
        <div className="flex items-end">
          <Button type="button" size="sm" onClick={calculate} disabled={loading || !surface} className="w-full h-9 rounded-lg text-sm">
            {loading ? <Loader2 className="w-3 h-3 animate-spin" /> : "Estimer"}
          </Button>
        </div>
      </div>
      {result && (
        <div className="flex items-center justify-between bg-white dark:bg-background border border-blue-200 dark:border-blue-700 rounded-lg px-3 py-2">
          <div>
            <span className="text-sm font-bold text-blue-700">{result.priceMin.toLocaleString("fr-FR")}€ – {result.priceMax.toLocaleString("fr-FR")}€</span>
            <span className="text-xs text-muted-foreground ml-2">{result.label} ({result.unit})</span>
          </div>
          <Button type="button" size="sm" variant="outline" className="text-xs h-7 border-blue-300 text-blue-700 hover:bg-blue-100"
            onClick={() => onApply(result.priceAvg)}>
            Appliquer moy.
          </Button>
        </div>
      )}
    </div>
  );
}

function AssignProviderList({ providers, selectedProviderId, onSelect }: { providers: any[]; selectedProviderId: string; onSelect: (id: string) => void }) {
  const [searchTerm, setSearchTerm] = useState("");
  const filtered = providers.filter(p =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) || (p.zone || "").toLowerCase().includes(searchTerm.toLowerCase())
  );
  return (
    <div className="space-y-3">
      <input type="text" placeholder="Filtrer par nom ou zone..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)}
        className="w-full px-3 py-2.5 text-sm rounded-xl border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/40" />
      <div className="max-h-[280px] overflow-y-auto rounded-xl border border-border/50 divide-y divide-border/30">
        {filtered.length === 0 ? <div className="py-6 text-center text-sm text-muted-foreground">Aucun couvreur trouvé</div> : (
          filtered.map(p => (
            <button key={p.id} type="button" onClick={() => onSelect(p.id.toString())}
              className={`w-full flex items-center justify-between px-4 py-3 text-left transition-colors ${selectedProviderId === p.id.toString() ? "bg-primary/10 border-l-2 border-l-primary" : "hover:bg-muted/40"}`}>
              <div className="min-w-0">
                <p className={`text-sm font-medium truncate ${selectedProviderId === p.id.toString() ? "text-primary" : ""}`}>{p.name}</p>
                <p className="text-xs text-muted-foreground truncate">{p.zone || "Zone non définie"}</p>
              </div>
              <div className="flex items-center gap-2 ml-2 shrink-0">
                {p.isAvailable
                  ? <span className="text-[10px] bg-green-500/10 text-green-600 px-2 py-0.5 rounded-full font-medium">Disponible</span>
                  : <span className="text-[10px] bg-gray-500/10 text-gray-500 px-2 py-0.5 rounded-full font-medium">Indisponible</span>}
                {selectedProviderId === p.id.toString() && <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />}
              </div>
            </button>
          ))
        )}
      </div>
    </div>
  );
}

export default function Missions() {
  const [activeTab, setActiveTab] = useState("all");
  const [assignMissionId, setAssignMissionId] = useState<number | null>(null);
  const [selectedProviderId, setSelectedProviderId] = useState<string>("");
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editMission, setEditMission] = useState<any | null>(null);
  const [deleteMissionId, setDeleteMissionId] = useState<number | null>(null);
  const [deleteCode, setDeleteCode] = useState("");
  const [showDeleteCode, setShowDeleteCode] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const fileUploadRef = useRef<FileUploadZoneRef>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: missionsData, isLoading } = useGetMissions({ status: activeTab === "all" ? undefined : activeTab as any });
  const { data: providersData } = useGetProviders();
  const assignMutation = useAssignMission();
  const createMutation = useCreateMission();
  const updateMutation = useUpdateMission();
  const missions = missionsData?.missions || [];
  const providers = providersData?.providers.filter(p => p.status === "active") || [];

  const handleDeleteMission = async () => {
    if (!deleteMissionId || !deleteCode) return;
    setIsDeleting(true);
    try {
      const res = await fetch(`/api/missions/${deleteMissionId}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: deleteCode }),
      });
      const data = await res.json();
      if (!res.ok) { toast({ title: "Erreur", description: data.error || "Impossible de supprimer.", variant: "destructive" }); return; }
      toast({ title: "Chantier supprimé" });
      setDeleteMissionId(null); setDeleteCode("");
      queryClient.invalidateQueries({ queryKey: ["/api/missions"] });
    } catch { toast({ title: "Erreur", variant: "destructive" }); } finally { setIsDeleting(false); }
  };

  const handleAssign = async () => {
    if (!assignMissionId || !selectedProviderId) return;
    try {
      await assignMutation.mutateAsync({ id: assignMissionId, data: { providerId: parseInt(selectedProviderId) } });
      toast({ title: "Chantier assigné", description: "Le couvreur a été notifié." });
      setAssignMissionId(null); setSelectedProviderId("");
      queryClient.invalidateQueries({ queryKey: ["/api/missions"] });
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
  };

  const createForm = useForm<z.infer<typeof createSchema>>({
    resolver: zodResolver(createSchema),
    defaultValues: { clientName: "", clientPhone: "", roofType: "", roofTypeOther: "", roofSurface: "", roofAge: "",
      interventionType: "reparation_fuite", description: "", locationAddress: "", priority: "normal", scheduledAt: "", amount: "", clientPaymentMethod: "" },
  });

  const editForm = useForm<EditFormValues>({ resolver: zodResolver(editSchema) });
  const watchedRoofType = createForm.watch("roofType");
  const editWatchedRoofType = editForm.watch("roofType");

  const openEdit = (mission: any) => {
    setEditMission(mission);
    editForm.reset({
      status: mission.status, priority: mission.priority || "normal",
      clientName: mission.clientName || "", clientPhone: mission.clientPhone || "",
      roofType: mission.roofType || "", roofTypeOther: mission.roofTypeOther || "",
      roofSurface: mission.roofSurface ?? "", roofAge: mission.roofAge ?? "",
      interventionType: mission.interventionType || "reparation_fuite",
      description: mission.description || "",
      scheduledAt: mission.scheduledAt ? new Date(mission.scheduledAt).toISOString().slice(0, 16) : "",
      locationAddress: mission.locationAddress || "",
      notes: mission.notes || "", amount: mission.amount ?? "", estimatedDuration: mission.estimatedDuration || 480,
      clientPaymentMethod: mission.clientPaymentMethod || "",
    });
  };

  const onSubmitCreate = async (data: z.infer<typeof createSchema>) => {
    try {
      const created: any = await createMutation.mutateAsync({
        data: { ...data, estimatedDuration: 480,
          roofSurface: data.roofSurface !== "" ? Number(data.roofSurface) : undefined,
          roofAge: data.roofAge !== "" ? Number(data.roofAge) : undefined,
          amount: data.amount !== "" ? Number(data.amount) : undefined,
          roofType: data.roofType || undefined, roofTypeOther: data.roofTypeOther || undefined,
          clientPaymentMethod: data.clientPaymentMethod || undefined,
        } as any,
      });
      if (created?.id && fileUploadRef.current?.hasPendingFiles()) {
        const uploaded = await fileUploadRef.current.uploadStagedFiles();
        await Promise.all(uploaded.map(f => fetch(`/api/missions/${created.id}/attachments`, {
          method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(f),
        })));
      }
      toast({ title: "Chantier créé" }); setIsCreateOpen(false); createForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/missions"] });
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
  };

  const onSubmitEdit = async (data: EditFormValues) => {
    if (!editMission) return;
    try {
      await updateMutation.mutateAsync({
        id: editMission.id,
        data: { ...data, scheduledAt: data.scheduledAt,
          roofSurface: data.roofSurface !== "" ? Number(data.roofSurface) : undefined,
          roofAge: data.roofAge !== "" ? Number(data.roofAge) : undefined,
          amount: data.amount !== "" ? Number(data.amount) : undefined,
          roofType: data.roofType || undefined, roofTypeOther: data.roofTypeOther || undefined,
          clientPaymentMethod: data.clientPaymentMethod || undefined,
        } as any,
      });
      toast({ title: "Chantier modifié" }); setEditMission(null);
      queryClient.invalidateQueries({ queryKey: ["/api/missions"] });
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
  };

  return (
    <Layout>
      <div className="flex flex-col gap-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold">Chantiers</h1>
            <p className="text-muted-foreground mt-1">Supervisez l'ensemble des interventions couverture.</p>
          </div>
          <Button onClick={() => setIsCreateOpen(true)} className="bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/25 rounded-xl px-6">
            <Plus className="w-4 h-4 mr-2" /> Créer un chantier
          </Button>
        </div>

        <div className="flex overflow-x-auto pb-2 gap-2">
          {TABS.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 text-sm font-medium rounded-xl whitespace-nowrap transition-all duration-200 ${activeTab === tab.id ? "bg-foreground text-background shadow-md" : "bg-card text-muted-foreground hover:bg-muted border border-border/50"}`}>
              {tab.label}
            </button>
          ))}
        </div>

        <Card className="rounded-2xl border-border/50 shadow-md shadow-black/5 overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-muted/30">
                <TableRow className="hover:bg-transparent">
                  <TableHead className="w-[60px]">ID</TableHead>
                  <TableHead>Chantier</TableHead>
                  <TableHead>Adresse & Date</TableHead>
                  <TableHead>Couvreur</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead className="text-right">Montant</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i} className="animate-pulse">
                      {[...Array(7)].map((_, j) => <TableCell key={j}><div className="h-6 bg-muted/50 rounded" /></TableCell>)}
                    </TableRow>
                  ))
                ) : missions.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="h-48 text-center">
                      <div className="flex flex-col items-center justify-center text-muted-foreground">
                        <ClipboardList className="w-8 h-8 mb-2 opacity-20" />
                        <p>Aucun chantier pour ce filtre.</p>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  missions.map(mission => (
                    <TableRow key={mission.id} className="hover:bg-muted/20 transition-colors">
                      <TableCell className="font-mono text-muted-foreground text-xs">#{mission.id}</TableCell>
                      <TableCell>
                        <div className="flex gap-3 items-start">
                          <div className="bg-background border border-border/50 p-2 rounded-xl shadow-sm mt-0.5">
                            <InterventionIcon type={(mission as any).interventionType} className="w-5 h-5" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-semibold text-foreground">{getInterventionLabel((mission as any).interventionType)}</span>
                              <MissionPriorityBadge priority={mission.priority} />
                            </div>
                            <div className="text-xs text-muted-foreground flex flex-col gap-0.5">
                              <span className="flex items-center gap-1">
                                <User className="w-3 h-3" /> {mission.clientName}
                                {isNonFrenchPhone(mission.clientPhone) ? (
                                  <span className="inline-flex items-center gap-1">
                                    (<a href={`tel:${mission.clientPhone}`} className="hover:underline">{mission.clientPhone}</a>
                                    <a href={getWhatsAppUrl(mission.clientPhone)} target="_blank" rel="noopener noreferrer" className="text-green-600">
                                      <MessageCircle className="w-3.5 h-3.5" />
                                    </a>)
                                  </span>
                                ) : <span>(<a href={`tel:${mission.clientPhone}`} className="hover:underline">{mission.clientPhone}</a>)</span>}
                              </span>
                              {(mission as any).roofType && <span className="flex items-center gap-1"><Home className="w-3 h-3" /> {getRoofTypeLabel((mission as any).roofType)}</span>}
                              {(mission as any).roofSurface && <span>{(mission as any).roofSurface} m²</span>}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <p className="flex items-start gap-1.5 text-foreground mb-1">
                            <MapPin className="w-3.5 h-3.5 mt-0.5 text-primary shrink-0" />
                            <span className="line-clamp-2 max-w-[180px]">{mission.locationAddress}</span>
                          </p>
                          <p className="flex items-center gap-1.5 text-muted-foreground text-xs">
                            <CalendarClock className="w-3.5 h-3.5 text-orange-500" />
                            {formatDateTime(mission.scheduledAt)}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell>
                        {mission.providerName ? (
                          <div className="flex flex-col gap-1 items-start">
                            <span className="font-medium text-sm bg-secondary px-2 py-1 rounded-md border border-border/50">{mission.providerName}</span>
                            {["pending","confirmed"].includes(mission.status) && (
                              <button onClick={() => { setAssignMissionId(mission.id); setSelectedProviderId(""); }} className="text-[10px] text-primary hover:underline px-1">Réassigner</button>
                            )}
                          </div>
                        ) : (
                          <Button variant="outline" size="sm"
                            className="bg-orange-50 text-orange-600 border-orange-200 hover:bg-orange-100 h-8 rounded-lg text-xs"
                            onClick={() => { setAssignMissionId(mission.id); setSelectedProviderId(""); }}>
                            Assigner
                          </Button>
                        )}
                      </TableCell>
                      <TableCell><MissionStatusBadge status={mission.status} /></TableCell>
                      <TableCell className="text-right font-semibold">
                        {mission.amount ? <span className="text-green-600">{formatCurrency(mission.amount)}</span>
                          : <span className="text-muted-foreground font-normal text-sm">-</span>}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="icon" title="Modifier" className="h-8 w-8 text-blue-600 hover:bg-blue-50 rounded-lg" onClick={() => openEdit(mission)}>
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" title="Supprimer" className="h-8 w-8 text-red-500 hover:bg-red-50 rounded-lg"
                            onClick={() => { setDeleteMissionId(mission.id); setDeleteCode(""); setShowDeleteCode(false); }}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </Card>
      </div>

      {/* Edit Dialog */}
      <Dialog open={!!editMission} onOpenChange={open => !open && setEditMission(null)}>
        <DialogContent className="sm:max-w-[640px] rounded-2xl p-0 overflow-hidden flex flex-col max-h-[90vh]">
          <DialogHeader className="p-6 pb-4 border-b border-border/40 shrink-0">
            <DialogTitle className="text-xl font-display">Modifier le chantier #{editMission?.id}</DialogTitle>
            <DialogDescription>{editMission && `${getInterventionLabel(editMission.interventionType)} — ${editMission.clientName}`}</DialogDescription>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onSubmitEdit)} className="flex flex-col flex-1 overflow-hidden">
              <div className="flex-1 overflow-y-auto p-6 space-y-5">
                <div className="grid grid-cols-2 gap-4">
                  <FormField control={editForm.control} name="status" render={({ field }) => (
                    <FormItem><FormLabel>Statut</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl><SelectTrigger className="rounded-xl h-10"><SelectValue /></SelectTrigger></FormControl>
                        <SelectContent>
                          <SelectItem value="pending">En attente</SelectItem><SelectItem value="confirmed">Confirmé</SelectItem>
                          <SelectItem value="in_progress">En cours</SelectItem><SelectItem value="completed">Terminé</SelectItem>
                          <SelectItem value="cancelled">Annulé</SelectItem>
                        </SelectContent>
                      </Select><FormMessage /></FormItem>
                  )} />
                  <FormField control={editForm.control} name="priority" render={({ field }) => (
                    <FormItem><FormLabel>Priorité</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl><SelectTrigger className="rounded-xl h-10"><SelectValue /></SelectTrigger></FormControl>
                        <SelectContent>
                          <SelectItem value="low">Basse</SelectItem><SelectItem value="normal">Normale</SelectItem>
                          <SelectItem value="high">Haute</SelectItem><SelectItem value="urgent">Urgente</SelectItem>
                        </SelectContent>
                      </Select><FormMessage /></FormItem>
                  )} />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <FormField control={editForm.control} name="clientName" render={({ field }) => (
                    <FormItem><FormLabel>Nom client</FormLabel><FormControl><Input {...field} className="rounded-xl" /></FormControl><FormMessage /></FormItem>
                  )} />
                  <FormField control={editForm.control} name="clientPhone" render={({ field }) => (
                    <FormItem><FormLabel>Téléphone</FormLabel><FormControl><Input {...field} className="rounded-xl" /></FormControl><FormMessage /></FormItem>
                  )} />
                </div>

                <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Toiture</p>
                <div className="grid grid-cols-2 gap-4">
                  <FormField control={editForm.control} name="roofType" render={({ field }) => (
                    <FormItem><FormLabel>Matériau</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || ""}>
                        <FormControl><SelectTrigger className="rounded-xl h-10"><SelectValue placeholder="Sélectionner..." /></SelectTrigger></FormControl>
                        <SelectContent>{ROOF_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
                      </Select><FormMessage /></FormItem>
                  )} />
                  {editWatchedRoofType === "autre" && (
                    <FormField control={editForm.control} name="roofTypeOther" render={({ field }) => (
                      <FormItem><FormLabel>Préciser</FormLabel><FormControl><Input {...field} className="rounded-xl" placeholder="Ex: polycarbonate" /></FormControl></FormItem>
                    )} />
                  )}
                  <FormField control={editForm.control} name="roofSurface" render={({ field }) => (
                    <FormItem><FormLabel>Surface (m²)</FormLabel><FormControl><Input type="number" {...field} value={field.value ?? ""} className="rounded-xl" placeholder="ex: 80" /></FormControl></FormItem>
                  )} />
                  <FormField control={editForm.control} name="roofAge" render={({ field }) => (
                    <FormItem><FormLabel>Âge toiture (ans)</FormLabel><FormControl><Input type="number" {...field} value={field.value ?? ""} className="rounded-xl" placeholder="ex: 15" /></FormControl></FormItem>
                  )} />
                </div>

                <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Intervention</p>
                <div className="grid grid-cols-2 gap-4">
                  <FormField control={editForm.control} name="interventionType" render={({ field }) => (
                    <FormItem><FormLabel>Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl><SelectTrigger className="rounded-xl h-10"><SelectValue /></SelectTrigger></FormControl>
                        <SelectContent>{INTERVENTION_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
                      </Select><FormMessage /></FormItem>
                  )} />
                  <FormField control={editForm.control} name="scheduledAt" render={({ field }) => (
                    <FormItem><FormLabel>Date planifiée</FormLabel><FormControl><Input type="datetime-local" {...field} className="rounded-xl" /></FormControl><FormMessage /></FormItem>
                  )} />
                </div>
                <FormField control={editForm.control} name="description" render={({ field }) => (
                  <FormItem><FormLabel>Description</FormLabel><FormControl><Textarea rows={2} {...field} className="rounded-xl resize-none" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={editForm.control} name="locationAddress" render={({ field }) => (
                  <FormItem><FormLabel>Adresse du chantier</FormLabel><FormControl>
                    <AddressAutocomplete value={field.value} onChange={field.onChange} placeholder="Adresse de la toiture" className="rounded-xl" />
                  </FormControl><FormMessage /></FormItem>
                )} />

                <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Facturation</p>
                <PriceSimulator onApply={price => editForm.setValue("amount", price)} />
                <div className="grid grid-cols-3 gap-4">
                  <FormField control={editForm.control} name="amount" render={({ field }) => (
                    <FormItem><FormLabel>Montant (€)</FormLabel><FormControl>
                      <Input type="number" step="0.01" {...field} value={field.value ?? ""} className="rounded-xl" />
                    </FormControl><FormMessage /></FormItem>
                  )} />
                  <FormField control={editForm.control} name="clientPaymentMethod" render={({ field }) => (
                    <FormItem><FormLabel>Paiement client</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || ""}>
                        <FormControl><SelectTrigger className="rounded-xl h-10"><SelectValue placeholder="Méthode..." /></SelectTrigger></FormControl>
                        <SelectContent>{CLIENT_PAYMENT_METHODS.map(m => <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>)}</SelectContent>
                      </Select></FormItem>
                  )} />
                  <FormField control={editForm.control} name="estimatedDuration" render={({ field }) => (
                    <FormItem><FormLabel>Durée estimée (min)</FormLabel><FormControl>
                      <Input type="number" {...field} value={field.value ?? ""} className="rounded-xl" placeholder="ex: 480" />
                    </FormControl></FormItem>
                  )} />
                </div>
                <FormField control={editForm.control} name="notes" render={({ field }) => (
                  <FormItem><FormLabel>Notes internes</FormLabel><FormControl>
                    <Textarea rows={2} {...field} className="rounded-xl resize-none" placeholder="Observations, contraintes d'accès..." />
                  </FormControl></FormItem>
                )} />
              </div>
              <div className="shrink-0 px-6 py-4 border-t border-border/40 flex justify-end gap-3 bg-background">
                <Button type="button" variant="outline" onClick={() => setEditMission(null)} className="rounded-xl">Annuler</Button>
                <Button type="submit" disabled={updateMutation.isPending} className="bg-primary text-white rounded-xl">
                  {updateMutation.isPending ? "Enregistrement..." : "Enregistrer"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Assign Dialog */}
      <Dialog open={!!assignMissionId} onOpenChange={open => !open && setAssignMissionId(null)}>
        <DialogContent className="sm:max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle>Assigner un couvreur</DialogTitle>
            <DialogDescription>Sélectionnez un couvreur actif pour ce chantier.</DialogDescription>
          </DialogHeader>
          <div className="py-4"><AssignProviderList providers={providers} selectedProviderId={selectedProviderId} onSelect={setSelectedProviderId} /></div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAssignMissionId(null)} className="rounded-xl">Annuler</Button>
            <Button onClick={handleAssign} disabled={!selectedProviderId || assignMutation.isPending} className="bg-primary text-white rounded-xl">
              {assignMutation.isPending ? "Assignation..." : "Confirmer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create Dialog */}
      <Dialog open={isCreateOpen} onOpenChange={open => { setIsCreateOpen(open); if (!open) createForm.reset(); }}>
        <DialogContent className="sm:max-w-[600px] p-0 overflow-hidden rounded-2xl">
          <DialogHeader className="p-6 pb-0">
            <DialogTitle className="text-2xl font-display">Créer un chantier</DialogTitle>
            <DialogDescription>Remplissez les informations du nouveau chantier de couverture.</DialogDescription>
          </DialogHeader>
          <Form {...createForm}>
            <form onSubmit={createForm.handleSubmit(onSubmitCreate)} className="p-6 pt-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider border-b pb-2">Client</h4>
              <div className="grid grid-cols-2 gap-4">
                <FormField control={createForm.control} name="clientName" render={({ field }) => (
                  <FormItem><FormLabel>Nom</FormLabel><FormControl><Input {...field} className="rounded-xl" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={createForm.control} name="clientPhone" render={({ field }) => (
                  <FormItem><FormLabel>Téléphone</FormLabel><FormControl><Input {...field} className="rounded-xl" /></FormControl><FormMessage /></FormItem>
                )} />
              </div>

              <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider border-b pb-2 mt-2">Toiture</h4>
              <div className="grid grid-cols-2 gap-4">
                <FormField control={createForm.control} name="roofType" render={({ field }) => (
                  <FormItem><FormLabel>Matériau</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || ""}>
                      <FormControl><SelectTrigger className="rounded-xl"><SelectValue placeholder="Sélectionner..." /></SelectTrigger></FormControl>
                      <SelectContent>{ROOF_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
                    </Select></FormItem>
                )} />
                {watchedRoofType === "autre" && (
                  <FormField control={createForm.control} name="roofTypeOther" render={({ field }) => (
                    <FormItem><FormLabel>Préciser</FormLabel><FormControl><Input {...field} className="rounded-xl" placeholder="Ex: polycarbonate" /></FormControl></FormItem>
                  )} />
                )}
                <FormField control={createForm.control} name="roofSurface" render={({ field }) => (
                  <FormItem><FormLabel>Surface (m²)</FormLabel><FormControl><Input type="number" {...field} value={field.value ?? ""} className="rounded-xl" placeholder="ex: 80" /></FormControl></FormItem>
                )} />
                <FormField control={createForm.control} name="roofAge" render={({ field }) => (
                  <FormItem><FormLabel>Âge toiture (ans)</FormLabel><FormControl><Input type="number" {...field} value={field.value ?? ""} className="rounded-xl" placeholder="ex: 15" /></FormControl></FormItem>
                )} />
              </div>

              <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider border-b pb-2 mt-2">Intervention</h4>
              <div className="grid grid-cols-2 gap-4">
                <FormField control={createForm.control} name="interventionType" render={({ field }) => (
                  <FormItem><FormLabel>Type</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>{INTERVENTION_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
                    </Select><FormMessage /></FormItem>
                )} />
                <FormField control={createForm.control} name="priority" render={({ field }) => (
                  <FormItem><FormLabel>Priorité</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl><SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="low">Basse</SelectItem><SelectItem value="normal">Normale</SelectItem>
                        <SelectItem value="high">Haute</SelectItem><SelectItem value="urgent">Urgente</SelectItem>
                      </SelectContent>
                    </Select></FormItem>
                )} />
                <FormField control={createForm.control} name="scheduledAt" render={({ field }) => (
                  <FormItem><FormLabel>Date prévue</FormLabel><FormControl><Input type="datetime-local" {...field} className="rounded-xl" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={createForm.control} name="clientPaymentMethod" render={({ field }) => (
                  <FormItem><FormLabel>Paiement client</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || ""}>
                      <FormControl><SelectTrigger className="rounded-xl"><SelectValue placeholder="Méthode..." /></SelectTrigger></FormControl>
                      <SelectContent>{CLIENT_PAYMENT_METHODS.map(m => <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>)}</SelectContent>
                    </Select></FormItem>
                )} />
              </div>
              <FormField control={createForm.control} name="locationAddress" render={({ field }) => (
                <FormItem><FormLabel>Adresse du chantier <span className="text-destructive">*</span></FormLabel><FormControl>
                  <AddressAutocomplete value={field.value} onChange={field.onChange} placeholder="ex: 12 rue des Chênes, 76000 Rouen" />
                </FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={createForm.control} name="description" render={({ field }) => (
                <FormItem><FormLabel>Description détaillée</FormLabel><FormControl><Textarea rows={3} {...field} className="rounded-xl resize-none" /></FormControl><FormMessage /></FormItem>
              )} />

              <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider border-b pb-2 mt-2">Tarification</h4>
              <PriceSimulator onApply={price => createForm.setValue("amount", price)} />
              <FormField control={createForm.control} name="amount" render={({ field }) => (
                <FormItem><FormLabel>Montant (€) <span className="text-muted-foreground text-xs font-normal">(optionnel)</span></FormLabel>
                  <FormControl><Input type="number" step="0.01" placeholder="ex: 2500.00" {...field} value={field.value ?? ""} className="rounded-xl" /></FormControl><FormMessage /></FormItem>
              )} />

              <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider border-b pb-2 mt-2">Photos</h4>
              <FileUploadZone ref={fileUploadRef} />

              <div className="pt-4 border-t flex justify-end gap-3">
                <Button type="button" variant="outline" onClick={() => setIsCreateOpen(false)} className="rounded-xl">Annuler</Button>
                <Button type="submit" disabled={createMutation.isPending} className="bg-primary text-white rounded-xl">
                  {createMutation.isPending ? "Création..." : "Créer le chantier"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <Dialog open={!!deleteMissionId} onOpenChange={open => !open && setDeleteMissionId(null)}>
        <DialogContent className="sm:max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive"><Trash2 className="w-5 h-5" /> Supprimer le chantier</DialogTitle>
            <DialogDescription>Cette action est <strong>irréversible</strong>. Entrez le code de suppression.</DialogDescription>
          </DialogHeader>
          <div className="mt-2 relative">
            <Input type={showDeleteCode ? "text" : "password"} placeholder="Code de suppression" value={deleteCode}
              onChange={e => setDeleteCode(e.target.value)} className="rounded-xl pr-10 font-mono" autoFocus
              onKeyDown={e => e.key === "Enter" && handleDeleteMission()} />
            <button type="button" className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              onClick={() => setShowDeleteCode(!showDeleteCode)}>
              {showDeleteCode ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          <DialogFooter className="mt-4 flex gap-3 sm:justify-end">
            <Button variant="outline" onClick={() => setDeleteMissionId(null)} className="rounded-xl">Annuler</Button>
            <Button variant="destructive" onClick={handleDeleteMission} disabled={isDeleting || !deleteCode} className="rounded-xl">
              {isDeleting ? "Suppression..." : "Supprimer définitivement"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
