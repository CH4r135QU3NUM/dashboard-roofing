import { useState } from "react";
import { Layout } from "@/components/Layout";
import { useGetClients, useCreateClient, useUpdateClient, useDeleteClient } from "@workspace/api-client-react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Search, Plus, Pencil, Trash2, Mail, Phone, Calendar } from "lucide-react";
import { formatDateTime } from "@/lib/format";

const clientSchema = z.object({
  firstName: z.string().min(2, "Prénom requis"),
  lastName: z.string().min(2, "Nom requis"),
  email: z.string().email("Email invalide").optional().or(z.literal("")),
  phone: z.string().min(8, "Téléphone requis"),
  address: z.string().optional().or(z.literal("")),
});

export default function Clients() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [selectedId, setSelectedId] = useState<number | null>(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: response, isLoading } = useGetClients();
  const createMutation = useCreateClient();
  const updateMutation = useUpdateClient();
  const deleteMutation = useDeleteClient();

  const clients = response?.clients || [];
  
  const filteredClients = clients.filter(c => 
    `${c.firstName} ${c.lastName}`.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.phone.includes(searchTerm) ||
    (c.email && c.email.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const form = useForm<z.infer<typeof clientSchema>>({
    resolver: zodResolver(clientSchema),
    defaultValues: { firstName: "", lastName: "", email: "", phone: "", address: "" }
  });

  const openCreate = () => {
    setSelectedId(null);
    form.reset({ firstName: "", lastName: "", email: "", phone: "", address: "" });
    setIsFormOpen(true);
  };

  const openEdit = (client: any) => {
    setSelectedId(client.id);
    form.reset({
      firstName: client.firstName,
      lastName: client.lastName,
      email: client.email || "",
      phone: client.phone,
      address: client.address || "",
    });
    setIsFormOpen(true);
  };

  const onSubmit = async (data: z.infer<typeof clientSchema>) => {
    try {
      if (selectedId) {
        await updateMutation.mutateAsync({ id: selectedId, data });
        toast({ title: "Client mis à jour" });
      } else {
        await createMutation.mutateAsync({ data });
        toast({ title: "Client ajouté" });
      }
      setIsFormOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
    } catch {
      toast({ title: "Erreur", variant: "destructive" });
    }
  };

  const handleDelete = async () => {
    if (!selectedId) return;
    try {
      await deleteMutation.mutateAsync({ id: selectedId });
      toast({ title: "Client supprimé" });
      setIsDeleteOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
    } catch {
      toast({ title: "Erreur", variant: "destructive" });
    }
  };

  return (
    <Layout>
      <div className="flex flex-col gap-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold">Base Clients</h1>
            <p className="text-muted-foreground mt-1">Gérez le répertoire des clients du service.</p>
          </div>
          <Button onClick={openCreate} className="bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/25 rounded-xl px-6">
            <Plus className="w-4 h-4 mr-2" /> Ajouter un client
          </Button>
        </div>

        <Card className="rounded-2xl border-border/50 shadow-md shadow-black/5 overflow-hidden">
          <div className="p-4 border-b border-border/40 bg-muted/10">
            <div className="relative w-full max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Rechercher par nom, téléphone, email..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 bg-background border-border/50 rounded-xl"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-muted/30">
                <TableRow className="hover:bg-transparent">
                  <TableHead className="font-semibold">Client</TableHead>
                  <TableHead className="font-semibold">Contact</TableHead>
                  <TableHead className="font-semibold text-center">Missions</TableHead>
                  <TableHead className="font-semibold">Inscription</TableHead>
                  <TableHead className="text-right font-semibold">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow><TableCell colSpan={5} className="h-24 text-center">Chargement...</TableCell></TableRow>
                ) : filteredClients.length === 0 ? (
                  <TableRow><TableCell colSpan={5} className="h-32 text-center text-muted-foreground">Aucun client trouvé.</TableCell></TableRow>
                ) : (
                  filteredClients.map((client) => (
                    <TableRow key={client.id} className="hover:bg-muted/20">
                      <TableCell>
                        <div className="font-medium text-foreground">{client.firstName} {client.lastName}</div>
                        {client.address && <div className="text-xs text-muted-foreground mt-0.5 max-w-[200px] truncate">{client.address}</div>}
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col gap-1 text-sm">
                          <span className="flex items-center text-muted-foreground"><Phone className="w-3 h-3 mr-2 text-primary/70" />{client.phone}</span>
                          {client.email && <span className="flex items-center text-muted-foreground"><Mail className="w-3 h-3 mr-2 text-primary/70" />{client.email}</span>}
                        </div>
                      </TableCell>
                      <TableCell className="text-center">
                        <span className="inline-flex items-center justify-center bg-secondary text-secondary-foreground font-semibold h-7 w-7 rounded-full text-xs border border-border/50">
                          {client.totalMissions}
                        </span>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        <div className="flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5" />
                          {formatDateTime(client.createdAt).split(',')[0]}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg" onClick={() => openEdit(client)}>
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg" onClick={() => { setSelectedId(client.id); setIsDeleteOpen(true); }}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </Card>
      </div>

      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="sm:max-w-[500px] rounded-2xl">
          <DialogHeader>
            <DialogTitle>{selectedId ? "Modifier le client" : "Nouveau client"}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="firstName" render={({ field }) => (
                  <FormItem><FormLabel>Prénom</FormLabel><FormControl><Input {...field} className="rounded-xl" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="lastName" render={({ field }) => (
                  <FormItem><FormLabel>Nom</FormLabel><FormControl><Input {...field} className="rounded-xl" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="phone" render={({ field }) => (
                  <FormItem className="col-span-2"><FormLabel>Téléphone</FormLabel><FormControl><Input {...field} className="rounded-xl" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="email" render={({ field }) => (
                  <FormItem className="col-span-2"><FormLabel>Email (optionnel)</FormLabel><FormControl><Input type="email" {...field} className="rounded-xl" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="address" render={({ field }) => (
                  <FormItem className="col-span-2"><FormLabel>Adresse (optionnelle)</FormLabel><FormControl><Input {...field} className="rounded-xl" /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <DialogFooter className="pt-4 mt-2">
                <Button type="button" variant="outline" onClick={() => setIsFormOpen(false)} className="rounded-xl">Annuler</Button>
                <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending} className="rounded-xl">Enregistrer</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <DialogContent className="sm:max-w-md rounded-2xl">
          <DialogHeader><DialogTitle>Supprimer le client ?</DialogTitle></DialogHeader>
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={() => setIsDeleteOpen(false)} className="rounded-xl">Annuler</Button>
            <Button variant="destructive" onClick={handleDelete} disabled={deleteMutation.isPending} className="rounded-xl">Confirmer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
