import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Users, 
  ClipboardList, 
  CreditCard,
  UserCheck, 
  Home, 
  ShieldAlert,
  ExternalLink,
  Settings
} from "lucide-react";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent,
  SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem,
  SidebarHeader, SidebarSeparator,
} from "@/components/ui/sidebar";

const adminItems = [
  { title: "Tableau de bord",  url: "/",              icon: LayoutDashboard },
  { title: "Couvreurs",        url: "/prestataires",  icon: Users },
  { title: "Chantiers",        url: "/missions",      icon: ClipboardList },
  { title: "Paiements",        url: "/paiements",     icon: CreditCard },
  { title: "Clients",          url: "/clients",       icon: UserCheck },
  { title: "Biens & Toitures", url: "/vehicules",     icon: Home },
  { title: "Réglages",         url: "/reglages",      icon: Settings },
];

export function AppSidebar() {
  const [location] = useLocation();

  return (
    <Sidebar variant="inset" className="border-r-0">
      <SidebarHeader className="bg-sidebar p-4 pt-6">
        <div className="flex items-center gap-3 px-2">
          <div className="bg-primary/20 p-2 rounded-lg text-primary">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div className="flex flex-col">
            <span className="font-display font-bold text-lg leading-tight text-sidebar-foreground">Admin</span>
            <span className="text-xs text-sidebar-foreground/60 font-medium">ToiturePro</span>
          </div>
        </div>
      </SidebarHeader>
      
      <SidebarContent className="bg-sidebar">
        <SidebarGroup>
          <SidebarGroupLabel className="text-sidebar-foreground/50 text-xs font-semibold tracking-wider uppercase mt-4 mb-2">
            Gestion Globale
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {adminItems.map((item) => {
                const isActive = location === item.url;
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild tooltip={item.title} isActive={isActive}>
                      <Link href={item.url} className="flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200">
                        <item.icon className="w-5 h-5" />
                        <span className="font-medium">{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarSeparator className="mx-4 my-4 bg-sidebar-border" />

        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton asChild tooltip="Espace Couvreur">
                  <a href="/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sidebar-foreground/70 hover:text-sidebar-foreground transition-colors">
                    <ExternalLink className="w-5 h-5" />
                    <span className="font-medium">Espace Couvreur</span>
                  </a>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
