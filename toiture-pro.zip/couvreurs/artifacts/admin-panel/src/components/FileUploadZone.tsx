import { useState, useRef, useCallback, useImperativeHandle, forwardRef } from "react";
import { Paperclip, X, FileText, Video, Image as ImageIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export interface UploadedFile {
  objectPath: string;
  originalName: string;
  mimeType: string;
  fileSize: number;
}

export interface FileUploadZoneRef {
  uploadStagedFiles: () => Promise<UploadedFile[]>;
  hasPendingFiles: () => boolean;
}

interface FileUploadZoneProps {
  disabled?: boolean;
  maxFiles?: number;
  className?: string;
}

const ACCEPTED = "image/*,video/*,application/pdf";
const MAX_SIZE_MB = 50;

function FilePreview({ file, preview }: { file: File; preview?: string }) {
  if (file.type.startsWith("image/") && preview) {
    return <img src={preview} alt="" className="w-full h-full object-cover" />;
  }
  if (file.type.startsWith("video/")) return <Video className="w-5 h-5 text-blue-400" />;
  if (file.type === "application/pdf") return <FileText className="w-5 h-5 text-red-400" />;
  return <ImageIcon className="w-5 h-5 text-slate-400" />;
}

export const FileUploadZone = forwardRef<FileUploadZoneRef, FileUploadZoneProps>(
  function FileUploadZone({ disabled, maxFiles = 10, className }, ref) {
    const [staged, setStaged] = useState<{ id: string; file: File; preview?: string }[]>([]);
    const [isDragging, setIsDragging] = useState(false);
    const inputRef = useRef<HTMLInputElement>(null);

    useImperativeHandle(ref, () => ({
      hasPendingFiles: () => staged.length > 0,
      uploadStagedFiles: async (): Promise<UploadedFile[]> => {
        const results: UploadedFile[] = [];
        for (const { file } of staged) {
          const urlRes = await fetch("/api/storage/uploads/request-url", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name: file.name, size: file.size, contentType: file.type }),
          });
          if (!urlRes.ok) throw new Error(`Erreur préparation: ${file.name}`);
          const { uploadURL, objectPath } = await urlRes.json();
          const putRes = await fetch(uploadURL, {
            method: "PUT",
            headers: { "Content-Type": file.type },
            body: file,
          });
          if (!putRes.ok) throw new Error(`Erreur upload: ${file.name}`);
          results.push({ objectPath, originalName: file.name, mimeType: file.type, fileSize: file.size });
        }
        setStaged([]);
        return results;
      },
    }), [staged]);

    const addFiles = useCallback((files: FileList | File[]) => {
      const arr = Array.from(files).filter(f => f.size <= MAX_SIZE_MB * 1024 * 1024);
      const newItems = arr.slice(0, maxFiles - staged.length).map(f => ({
        id: `${Date.now()}-${Math.random()}`,
        file: f,
        preview: f.type.startsWith("image/") ? URL.createObjectURL(f) : undefined,
      }));
      setStaged(prev => [...prev, ...newItems]);
    }, [staged.length, maxFiles]);

    const removeFile = (id: string) => {
      setStaged(prev => {
        const item = prev.find(p => p.id === id);
        if (item?.preview) URL.revokeObjectURL(item.preview);
        return prev.filter(p => p.id !== id);
      });
    };

    const handleDrop = (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      if (e.dataTransfer.files) addFiles(e.dataTransfer.files);
    };

    return (
      <div className={cn("space-y-2", className)}>
        <div
          onDrop={handleDrop}
          onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
          onDragLeave={() => setIsDragging(false)}
          onClick={() => !disabled && inputRef.current?.click()}
          className={cn(
            "border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-colors",
            isDragging ? "border-primary bg-primary/5" : "border-border hover:border-primary/40 hover:bg-muted/20",
            disabled && "opacity-50 cursor-not-allowed"
          )}
        >
          <input
            ref={inputRef}
            type="file"
            multiple
            accept={ACCEPTED}
            className="hidden"
            disabled={disabled}
            onChange={(e) => e.target.files && addFiles(e.target.files)}
          />
          <div className="flex items-center justify-center gap-2 text-muted-foreground">
            <Paperclip className="w-4 h-4" />
            <span className="text-sm">Glissez ou cliquez — photos, vidéos, PDF (max {MAX_SIZE_MB} Mo)</span>
          </div>
        </div>

        {staged.length > 0 && (
          <div className="grid grid-cols-2 gap-2">
            {staged.map((p) => (
              <div key={p.id} className="relative flex items-center gap-2 bg-muted/40 border border-border/40 rounded-lg p-2 pr-7 group">
                <div className="w-9 h-9 shrink-0 flex items-center justify-center bg-background rounded overflow-hidden border border-border/30">
                  <FilePreview file={p.file} preview={p.preview} />
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-medium truncate leading-tight">{p.file.name}</p>
                  <p className="text-xs text-muted-foreground">{(p.file.size / 1024 / 1024).toFixed(1)} Mo</p>
                </div>
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); removeFile(p.id); }}
                  className="absolute right-1 top-1 w-5 h-5 rounded-full bg-destructive/10 hover:bg-destructive/20 text-destructive flex items-center justify-center"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }
);
