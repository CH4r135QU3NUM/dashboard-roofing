import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "./AppSidebar";
import { Bell, Search, UserCircle, CheckCheck, BellOff, Wrench, CreditCard, RefreshCw, Info, LogOut } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useGetNotifications, useMarkNotificationRead, useMarkAllNotificationsRead, getGetNotificationsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import { fr } from "date-fns/locale";

const NOTIF_ICONS: Record<string, React.ReactNode> = {
  new_mission: <Wrench className="w-4 h-4 text-primary" />,
  mission_update: <RefreshCw className="w-4 h-4 text-blue-500" />,
  payment_received: <CreditCard className="w-4 h-4 text-green-500" />,
  system: <Info className="w-4 h-4 text-muted-foreground" />,
};

export function Layout({ children }: { children: React.ReactNode }) {
  const queryClient = useQueryClient();
  const { data: notificationsData } = useGetNotifications();
  const notifications = notificationsData?.notifications || [];
  const unreadCount = notificationsData?.unreadCount || 0;

  const refreshNotifications = () =>
    queryClient.invalidateQueries({ queryKey: getGetNotificationsQueryKey(), refetchType: "all" });

  const markRead = useMarkNotificationRead({
    mutation: { onSuccess: refreshNotifications }
  });
  const markAll = useMarkAllNotificationsRead({
    mutation: { onSuccess: refreshNotifications }
  });

  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "4rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex min-h-screen w-full bg-background/50">
        <AppSidebar />
        <div className="flex flex-col flex-1 w-full relative">
          <header className="sticky top-0 z-50 flex items-center justify-between px-6 py-4 bg-background/80 backdrop-blur-md border-b border-border/40">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="md:hidden" />
              <div className="relative hidden sm:block w-64 lg:w-96">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Recherche globale..."
                  className="pl-10 bg-muted/50 border-transparent focus-visible:bg-background focus-visible:border-primary/50 focus-visible:ring-primary/20 rounded-full h-10 transition-all duration-300"
                />
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="ghost" size="icon" className="relative text-muted-foreground hover:text-foreground rounded-full">
                    <Bell className="w-5 h-5" />
                    {unreadCount > 0 && (
                      <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-destructive text-white border-2 border-background rounded-full text-[10px]">
                        {unreadCount > 99 ? '99+' : unreadCount}
                      </Badge>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent align="end" className="w-80 p-0 rounded-2xl shadow-xl border-border/50 overflow-hidden">
                  <div className="flex items-center justify-between px-4 py-3 border-b border-border/50 bg-muted/30">
                    <h3 className="font-semibold text-sm">Notifications</h3>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs text-primary hover:text-primary h-auto py-1 px-2 gap-1 disabled:opacity-40"
                      onClick={() => markAll.mutate()}
                      disabled={markAll.isPending || unreadCount === 0}
                    >
                      <CheckCheck className="w-3.5 h-3.5" />
                      Tout marquer lu
                    </Button>
                  </div>
                  <div className="max-h-[380px] overflow-y-auto divide-y divide-border/40">
                    {notifications.length === 0 ? (
                      <div className="flex flex-col items-center justify-center py-10 text-muted-foreground gap-2">
                        <BellOff className="w-8 h-8 opacity-40" />
                        <p className="text-sm">Aucune notification</p>
                      </div>
                    ) : (
                      notifications.map((n) => (
                        <button
                          key={n.id}
                          className={`w-full text-left flex items-start gap-3 px-4 py-3 hover:bg-muted/50 transition-colors ${!n.isRead ? 'bg-primary/5' : ''}`}
                          onClick={() => !n.isRead && markRead.mutate({ id: n.id })}
                        >
                          <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0 mt-0.5">
                            {NOTIF_ICONS[n.type] || <Info className="w-4 h-4" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className={`text-sm leading-tight ${!n.isRead ? 'font-semibold' : 'font-medium'}`}>{n.title}</p>
                            <p className="text-xs text-muted-foreground mt-0.5 leading-snug">{n.message}</p>
                            <p className="text-[10px] text-muted-foreground/60 mt-1">
                              {formatDistanceToNow(new Date(n.createdAt), { addSuffix: true, locale: fr })}
                            </p>
                          </div>
                          {!n.isRead && <span className="w-2 h-2 rounded-full bg-primary flex-shrink-0 mt-1.5" />}
                        </button>
                      ))
                    )}
                  </div>
                </PopoverContent>
              </Popover>

              <div className="h-8 w-[1px] bg-border/60 mx-1 hidden sm:block"></div>
              <AuthUserButton />
            </div>
          </header>

          <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-auto max-w-7xl mx-auto w-full">
            {children}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function AuthUserButton() {
  const { user, logout } = useAuth();
  return (
    <div className="hidden sm:flex items-center gap-1">
      <div className="flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-full">
        <UserCircle className="w-7 h-7 text-primary" />
        <div className="flex flex-col items-start text-left">
          <span className="text-sm font-semibold leading-none">{user?.name || "Admin"}</span>
          <span className="text-[10px] text-muted-foreground leading-none mt-1">{user?.email}</span>
        </div>
      </div>
      <Button
        variant="ghost"
        size="icon"
        title="Se déconnecter"
        className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-full"
        onClick={logout}
      >
        <LogOut className="w-4 h-4" />
      </Button>
    </div>
  );
}
